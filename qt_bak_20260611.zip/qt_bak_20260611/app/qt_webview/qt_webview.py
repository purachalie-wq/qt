import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text
from datetime import datetime

# --- 1. 数据库配置 ---
DB_URI = "mysql+pymysql://qt:M6HRcZAasYTjhmWr@127.0.0.1:3306/qt"
engine = create_engine(DB_URI, pool_recycle=3600)

# --- 2. 数据获取逻辑 ---

@st.cache_data(ttl=5) # 行情数据刷新频率设为 5 秒
def get_full_data():
    """
    整合逻辑：
    1. 扫描物理表 (70+ 币种)
    2. 获取 strategy_recommendations (策略配置)
    3. 获取 market_metrics (实时行情: 价格, 交易额, 持仓)
    """
    try:
        with engine.connect() as conn:
            # 1. 获取物理币种列表
            show_tables_query = text("SHOW TABLES LIKE 'arb_5s_TREND_%'")
            table_rows = conn.execute(show_tables_query).fetchall()
            all_symbols = [r[0].replace('arb_5s_TREND_', '') for r in table_rows]
            if not all_symbols: return pd.DataFrame()

            # 2. 获取最新策略配置 (修复时间戳转换)
            config_query = text("""
                SELECT 
                    sr.symbol, sr.open_bp, sr.close_bp, sr.cnt, 
                    sr.avg_open, sr.avg_close, sr.ts_created
                FROM strategy_recommendations sr
                INNER JOIN (
                    SELECT symbol, MAX(id) as max_id
                    FROM strategy_recommendations
                    GROUP BY symbol
                ) latest ON sr.id = latest.max_id
            """)
            config_df = pd.read_sql(config_query, conn)

            # 3. 获取市场行情数据 (来自 market_metrics 表)
            market_query = text("""
                SELECT 
                    symbol, 
                    last_price as price_idx, 
                    volume_24h, 
                    turnover_24h
                FROM market_metrics
            """)
            market_df = pd.read_sql(market_query, conn)

            # 4. 数据合并
            base_df = pd.DataFrame({'symbol': all_symbols})
            df = pd.merge(base_df, config_df, on='symbol', how='left')
            df = pd.merge(df, market_df, on='symbol', how='left')

            # --- 数据清洗与格式化 ---
            
            # A. 时间戳转换 (ms -> datetime)
            def format_ts(ts):
                if pd.isna(ts) or ts == 0: return "未计算"
                try:
                    return datetime.fromtimestamp(int(ts)/1000).strftime('%Y-%m-%d %H:%M:%S')
                except: return "格式错误"
            
            df['最后计算时间'] = df['ts_created'].apply(format_ts)

            # B. 合并推荐配置 (O/C)
            df['推荐配置(开/平)'] = df.apply(
                lambda x: f"{int(x.open_bp)} / {int(x.close_bp)}" if pd.notnull(x.open_bp) else "0 / 0", axis=1
            )

            # C. 合并深度统计 (O/C)
            df['深度统计(开/平)'] = df.apply(
                lambda x: f"{x.avg_open:.2f} / {x.avg_close:.2f}" if pd.notnull(x.avg_open) else "0.0 / 0.0", axis=1
            )

            # D. 其他字段填充
            df['统计点数'] = df['cnt'].fillna(0).astype(int)
            df['价格指数'] = df['price_idx'].fillna(0.0)
            df['24h交易额'] = df['volume_24h'].fillna(0.0)
            df['现有持仓'] = df['turnover_24h'].fillna(0.0) # 假设 turnover 作为持仓参考，或根据实际字段调整

            return df.sort_values(by='统计点数', ascending=False)
            
    except Exception as e:
        st.error(f"数据加载失败: {e}")
        return pd.DataFrame()

# --- 3. 界面渲染 ---

def main():
    st.set_page_config(page_title="QT 综合监控系统", layout="wide")
    
    df = get_full_data()
    
    # 侧边栏
    st.sidebar.title(f"🔍 币种导航 ({len(df)})")
    if not df.empty:
        page = st.sidebar.radio("切换页面", ["📊 全量看板"] + df['symbol'].tolist())
    else:
        page = "📊 全量看板"

    if page == "📊 全量看板":
        render_dashboard(df)
    else:
        render_detail(page)

def render_dashboard(df):
    st.title("📊 策略与市场行情全景 (70+ 币种)")
    
    if df.empty:
        st.warning("暂无数据，请确认数据库表及字段。")
        return

    # 准备最终展示的 DataFrame
    display_df = df[[
        'symbol', '推荐配置(开/平)', '统计点数', '深度统计(开/平)', 
        '价格指数', '24h交易额', '现有持仓', '最后计算时间'
    ]].copy()
    
    display_df.columns = [
        '币种', '推荐配置(开/平)', '统计点数', '深度统计(开/平)', 
        '价格指数', '24h交易额', '现有持仓', '最后计算时间'
    ]

    # 计算高度，确保 70 行数据完全平铺展开
    # 每行约 35px，加上表头和边距
    dynamic_height = (len(df) + 1) * 35 + 50

    st.dataframe(
        display_df.style.apply(
            lambda x: ['background-color: #331111' if x['最后计算时间'] == '未计算' else '' for _ in x], 
            axis=1
        ).format({
            '价格指数': '{:.4f}',
            '24h交易额': '{:,.2f}',
            '现有持仓': '{:,.2f}'
        }),
        height=dynamic_height,
        use_container_width=True,
        hide_index=True
    )

def render_detail(symbol):
    st.title(f"🪙 {symbol} 详情分析")
    st.info("详情页功能正常，正在调取趋势表数据...")
    # 这里接入你原有的趋势图表逻辑即可

if __name__ == "__main__":
    main()