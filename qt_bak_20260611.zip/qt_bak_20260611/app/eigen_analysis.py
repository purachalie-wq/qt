import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from sqlalchemy import create_engine, text
import time

# --- 1. 数据库配置 ---
DB_URI = "mysql+pymysql://qt:M6HRcZAasYTjhmWr@127.0.0.1:3306/qt"
engine = create_engine(DB_URI)

# --- 2. 核心数据获取逻辑 ---
@st.cache_data(ttl=60)
def get_all_symbols():
    """获取数据库中所有的表名（币种）"""
    with engine.connect() as conn:
        # 这里假设表名格式是 arb_5s_TREND_XXXX
        query = text("SHOW TABLES LIKE 'arb_5s_TREND_%'")
        result = conn.execute(query).fetchall()
        return [r[0].replace('arb_5s_TREND_', '') for r in result]

@st.cache_data(ttl=60)
def get_processed_data(symbol, hours):
    """预处理单币种数据"""
    ts_limit = int((time.time() - (hours * 3600)) * 1000)
    table_name = f"arb_5s_TREND_{symbol}"
    
    query = text(f"""
        SELECT side, ROUND(bp_avg) as bp, COUNT(*) as cnt, SUM(depth_avg) as sum_depth
        FROM {table_name} 
        WHERE ts >= :ts AND bp_avg BETWEEN -20 AND 100
        GROUP BY side, ROUND(bp_avg)
    """)
    
    try:
        with engine.connect() as conn:
            df = pd.read_sql(query, conn, params={"ts": ts_limit})
        if df.empty: return None

        bp_range = range(-20, 101)
        c_sum = {1: {b: 0 for b in bp_range}, 2: {b: 0 for b in bp_range}}
        c_depth_sum = {1: {b: 0.0 for b in bp_range}, 2: {b: 0.0 for b in bp_range}}
        
        for side in [1, 2]:
            side_df = df[df['side'] == side].set_index('bp')
            accum_cnt, accum_depth = 0, 0.0
            for b in sorted(bp_range, reverse=True):
                accum_cnt += side_df.loc[b, 'cnt'] if b in side_df.index else 0
                accum_depth += float(side_df.loc[b, 'sum_depth']) if b in side_df.index else 0
                c_sum[side][b], c_depth_sum[side][b] = accum_cnt, accum_depth
        return c_sum, c_depth_sum
    except:
        return None

def solve_axis(c_sum, c_depth_sum, target_s):
    """计算特定 A+B 值下的最优对等点"""
    best_a, min_diff = None, float('inf')
    for a in range(-10, target_s + 11):
        b = target_s - a
        if a not in c_sum[1] or b not in c_sum[2]: continue
        cnt1, cnt2 = c_sum[1][a], c_sum[2][b]
        if cnt1 == 0 and cnt2 == 0: continue
        diff = abs(cnt1 - cnt2)
        if diff < min_diff:
            min_diff, best_a = diff, a
        elif diff == min_diff and cnt1 > c_sum[1].get(best_a, -1):
            best_a = a
    
    if best_a is not None:
        fb = target_s - best_a
        ca, cb = c_sum[1][best_a], c_sum[2][fb]
        return {
            "open_bp": best_a, "close_bp": fb,
            "cnt": ca, "avg_open": round(c_depth_sum[1][best_a]/ca, 2) if ca > 0 else 0,
            "avg_close": round(c_depth_sum[2][fb]/cb, 2) if cb > 0 else 0
        }
    return None

# --- 3. 页面渲染逻辑 ---
def main():
    st.set_page_config(page_title="EIGEN 全币种量化筛选", layout="wide")
    symbols = get_all_symbols()
    
    # 预加载概览数据（24小时，A+B=30）用于排序
    overview_list = []
    for s in symbols:
        data = get_processed_data(s, 24)
        if data:
            res = solve_axis(data[0], data[1], 30)
            if res:
                res['symbol'] = s
                overview_list.append(res)
    
    # 排序：累计点数降序，名称升序
    overview_df = pd.DataFrame(overview_list)
    if not overview_df.empty:
        overview_df = overview_df.sort_values(by=['cnt', 'symbol'], ascending=[False, True])
        sorted_symbols = overview_df['symbol'].tolist()
    else:
        sorted_symbols = sorted(symbols)

    # --- 左侧导航栏 ---
    st.sidebar.title("🔍 量化导航")
    page = st.sidebar.radio("页面选择", ["📊 全币种概览"] + sorted_symbols)

    if page == "📊 全币种概览":
        render_overview(overview_df)
    else:
        render_symbol_page(page)

# --- 概览页渲染 ---
def render_overview(df):
    st.title("📊 全币种概览 (A+B=30, 最近24h)")
    if df.empty:
        st.warning("暂无满足条件的币种数据")
        return
    
    # 格式化输出
    display_df = pd.DataFrame({
        "币种": df['symbol'],
        "推荐配置 (Open/Close)": df.apply(lambda r: f"{int(r['open_bp'])} / {int(r['close_bp'])}", axis=1),
        "平均深度 (Open/Close)": df.apply(lambda r: f"{r['avg_open']} / {r['avg_close']}", axis=1),
        "累计点数 (Open/Close)": df.apply(lambda r: f"{int(r['cnt'])} / {int(r['cnt'])}", axis=1)
    })
    st.table(display_df)

# --- 币种详情页渲染 ---
def render_symbol_page(symbol):
    st.title(f"🪙 {symbol}")

    # --- 5 & 6. 交互组件移至标题下方 ---
    col_t, col_s = st.columns([1, 1])
    with col_t:
        time_label = st.selectbox("时间范围", ["最近3小时", "最近24小时", "最近7天"], index=1)
    with col_s:
        # 手工输入 A+B
        target_sum = st.number_input("A+B 强度锚点设定 (0-100)", min_value=0, max_value=100, value=30)
    
    time_map = {"最近3小时": 3, "最近24小时": 24, "最近7天": 168}
    data_pack = get_processed_data(symbol, time_map[time_label])
    
    if not data_pack:
        st.warning(f"币种 {symbol} 在此时间段内无数据")
        return

    c_sum, c_depth_sum = data_pack
    
    # 全量轴计算用于绘图
    all_results = []
    for s in range(10, 101):
        res = solve_axis(c_sum, c_depth_sum, s)
        if res:
            res['sum_val'] = s
            all_results.append(res)
    df_axis = pd.DataFrame(all_results)

    # 当前锚点数据
    anchor_res = solve_axis(c_sum, c_depth_sum, target_sum)
    
    if anchor_res:
        m1, m2, m3 = st.columns(3)
        m1.metric("推荐配置", f"Open: {int(anchor_res['open_bp'])} / Close: {int(anchor_res['close_bp'])}")
        m2.metric("累计点数", f"≈ {int(anchor_res['cnt'])} 次")
        m3.metric("平均深度", f"O:{anchor_res['avg_open']} / C:{anchor_res['avg_close']}")

    # --- 图形绘制 ---
    fig = go.Figure()
    if not df_axis.empty:
        # Open (Side 1)
        fig.add_trace(go.Scatter(
            x=df_axis['sum_val'], y=df_axis['open_bp'], mode='lines+markers', name='Open (A)',
            line=dict(color='#FF4136', width=3),
            customdata=np.stack((df_axis['cnt'], df_axis['avg_open']), axis=-1),
            hovertemplate="总和: %{x}<br>阈值: %{y} BP<br>点数: %{customdata[0]}<extra></extra>"
        ))
        # Close (Side 2)
        fig.add_trace(go.Scatter(
            x=df_axis['sum_val'], y=-df_axis['close_bp'], mode='lines+markers', name='Close (B)',
            line=dict(color='#2ECC40', width=3),
            customdata=np.stack((df_axis['cnt'], df_axis['avg_close']), axis=-1),
            hovertemplate="总和: %{x}<br>阈值: %{y} BP<br>点数: %{customdata[0]}<extra></extra>"
        ))

        # 动态标记线
        fig.add_vline(x=target_sum, line_width=2, line_dash="dash", line_color="white", opacity=0.8)
        
        fig.update_layout(template="plotly_dark", height=600, hovermode="x unified",
                          xaxis=dict(title="A + B 总和强度"), 
                          yaxis=dict(title="BP 设定 (Open正 / Close负)"))
        st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()