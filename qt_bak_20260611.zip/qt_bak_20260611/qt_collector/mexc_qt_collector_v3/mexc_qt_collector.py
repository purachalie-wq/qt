# -*- coding: UTF-8 -*-
import asyncio
import ccxt.pro as ccxt
import time
import logging
import traceback
import sys
from collections import defaultdict
import requests  # 移植老代码所需的 HTTP 库
from db_manager import db_srv  
from symbol_bucket import SymbolBucket  

# --- 1. 基础配置与日志系统 ---
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
    stream=sys.stdout  # 确保 Linux 环境下日志即时无延迟刷新刷新
)

buckets = defaultdict(dict)  # 全局秒级聚合容器：{symbol: {side: SymbolBucket}}

# --- 2. 🔍 动态双向币种发现引擎 (完整自老代码老逻辑移植) ---

def discover_mexc_pairs():
    """自动发现 MEXC 全量双向套利币种 (精准匹配 state=0)"""
    logging.info("Step [1/5] 🔍 [发现引擎] 开始扫描 MEXC 市场全量币种...")
    try:
        # 1. 请求 MEXC 永续合约全量信息接口
        url = "https://contract.mexc.com/api/v1/contract/detail"
        logging.info(f"👉 发起 HTTP 请求 -> {url}")
        res = requests.get(url, timeout=10).json()
        
        status_code = res.get('code')
        # 🎯 核心修复：MEXC 成功代码为 0 或 200，全面放开拦截避免误判
        if status_code not in [0, 200, '0', '200'] and not res.get('success'): 
            raise Exception(f"MEXC API 请求失败: {res.get('message') or res.get('msg')}")
        
        raw_contracts = res.get('data', [])
        # 防御某些格式包裹在 data.list 里的情况
        if isinstance(raw_contracts, dict) and 'list' in raw_contracts:
            raw_contracts = raw_contracts['list']
            
        logging.info(f"✅ 成功接收 MEXC 数据，全网合约总计 {len(raw_contracts)} 个。")
        
        usdt_set = set()
        usdc_set = set()
        
        # 2. 遍历并分类提取 USDT 和 USDC 结算的正常币种
        for item in raw_contracts:
            # 🎯 根据样本精准匹配：state == 0 代表正常运营交易的合约，且 apiAllowed 为 True
            if item.get('state') == 0 and item.get('apiAllowed') is True:
                base_coin = item.get('baseCoin')
                settle_coin = item.get('settleCoin', '').upper()
                
                if not base_coin:
                    continue
                    
                if settle_coin == 'USDT':
                    usdt_set.add(base_coin)
                elif settle_coin == 'USDC':
                    usdc_set.add(base_coin)
        
        logging.info(f"DEBUG - 过滤后合规的 🥞 USDT 标的数: {len(usdt_set)}, 🥞 USDC 标的数: {len(usdc_set)}")
        
        # 3. 取交集：找出同时拥有 USDT 永续和 USDC 永续的产品
        common_bases = usdt_set.intersection(usdc_set)
        
        valid_pairs = []
        for base in common_bases:
            # 保持标准 CCXT 统一命名格式
            u_sym = f"{base}/USDT:USDT"
            c_sym = f"{base}/USDC:USDC"
            
            valid_pairs.append({"name": base, "usdt": u_sym, "usdc": c_sym})
            
            # 初始化双向阶梯 Bucket（兼容你的本地全局变量）
            if 'buckets' in globals() or 'buckets' in locals():
                buckets[base][1] = SymbolBucket(base, 1)
                buckets[base][2] = SymbolBucket(base, 2)
            
        logging.info(f"✅ MEXC 扫描完毕。全量运营共发现 {len(valid_pairs)} 个双向套利对: {[p['name'] for p in valid_pairs]}")
        return valid_pairs
        
    except Exception as e:
        logging.error(f"❌ MEXC 币种扫描崩溃: {e}", exc_info=True)
        return []

# --- 3. 🦾 生产级全量运营多连接池管理器 (完全适配 MEXC 限制) ---

class mexcWSManager:
    def __init__(self, valid_pairs):
        self.valid_pairs = valid_pairs
        
        # 建立标准 CCXT 符号反查映射，完美兼容动态扫描出的所有资产
        self.sym_to_base = {}
        all_symbols = []
        for p in valid_pairs:
            self.sym_to_base[p['usdt']] = p['name']
            self.sym_to_base[p['usdc']] = p['name']
            all_symbols.append((p['usdt'], True))   # (symbol, is_usdt)
            all_symbols.append((p['usdc'], False))  # (symbol, is_usdt)
            
        self.cache = defaultdict(lambda: {'usdt': None, 'usdc': None})
        
        # 🎯 根据单个连接最多 30 个 Streams 的硬性限制，对全量交易对进行分切
        self.connection_groups = []
        MAX_STREAMS_PER_CONN = 30
        
        for i in range(0, len(all_symbols), MAX_STREAMS_PER_CONN):
            group = all_symbols[i:i + MAX_STREAMS_PER_CONN]
            self.connection_groups.append(group)
            
        # 存储所有初始化好的单独 ccxt.mexc 实例和任务
        self.exchanges = []
        self.heartbeat_tasks = []
        self.listener_tasks = []

    def create_mexc_instance(self, group_index):
        """为每个订阅组独立创建专属的 ccxt.mexc 客户端物理连接驱动"""
        exchange = ccxt.mexc({
            'enableRateLimit': True,
            'rateLimit': 20, # 强制设定 CCXT 内部限制速率，防止高频拥堵
            'options': {
                'ws': {
                    'heartbeat': False, # 关闭默认心跳，由我们专属的独立协程进行盲发
                },
                # 🎯 核心修改：强行注入基于组索引的独立物理标识
                # 迫使 CCXT 认为它们是完全不同的实例，在底层内存中彻底隔离成 5 个独立的连接池
                'connectionElementId': f"mexc_conn_element_g{group_index}"
            }
        })
        # 附加自定义属性，方便后续心跳包识别
        setattr(exchange, 'group_id', f"mexc_conn_g{group_index}")
        return exchange

    async def send_heartbeat_loop(self, exchange):
        """完全对齐 MEXC 生产环境：每 30 秒向单独物理物理连接盲发纯文本 'ping'"""
        while True:
            try:
                await asyncio.sleep(30)
                # 遍历当前驱动底层的所有活跃物理客户端套接字
                if hasattr(exchange, 'clients') and exchange.clients:
                    for client_id, client in exchange.clients.items():
                        if hasattr(client, 'send'):
                            logging.info(f"⚡ [Heartbeat] 正在向连接组 [{getattr(exchange, 'group_id')}] - 物理链路 [{client_id}] 盲发文本 'ping'...")
                            await client.send("ping")
            except Exception as e:
                logging.error(f"🚨 [Heartbeat] 组 [{getattr(exchange, 'group_id')}] 心跳盲发异常: {e}")

    async def watch_single_symbol_loop(self, exchange, symbol, is_usdt):
        """单个动态资产行情流常驻监听协程 (强化防御空值版)"""
        while True:
            try:
                # 🎯 核心修复：用 watch_order_book(limit=1) 彻底替代别扭的 watch_ticker
                # 名正言顺索要 1档 深度流，彻底复活真实的盘口挂单量，告别 1.0 虚假数据 Bug
                order_book = await exchange.watch_order_book(symbol, limit=1)
                ts_sec = int(time.time())

                if not order_book or not order_book.get('asks') or not order_book.get('bids'):
                    continue

                # 🎯 核心匹配：严格提取买一卖一第一档的价格与真实数量
                ask_val = order_book['asks'][0][0]
                ask_vol = order_book['asks'][0][1]
                bid_val = order_book['bids'][0][0]
                bid_vol = order_book['bids'][0][1]
                
                if ask_val is None or bid_val is None:
                    # 仅作为低级别 warning 打印，防止刷屏，不抛出异常
                    logging.warning(f"⚠️ [{symbol}] 盘口暂无有效买卖单 (ask: {ask_val}, bid: {bid_val})，跳过本轮...")
                    continue

                base = self.sym_to_base.get(symbol)
                if not base: 
                    continue
                
                # 提取深度量并做 None 防御（继承你原本的安全规则）
                ask_vol = float(ask_vol) if ask_vol is not None else 1.0
                bid_vol = float(bid_vol) if bid_vol is not None else 1.0

                # 将标准结构转换为内存统一对齐盘口格式
                ob_data = {
                    'asks': [[float(ask_val), ask_vol]],
                    'bids': [[float(bid_val), bid_vol]]
                }
                
                if is_usdt: 
                    self.cache[base]['usdt'] = ob_data
                else: 
                    self.cache[base]['usdc'] = ob_data
                    
                # --- 🧠 双侧交叉对齐与核心 BP 价差统计计算 ---
                c_pair = self.cache[base]
                if c_pair['usdt'] and c_pair['usdc']:
                    ut, uc = c_pair['usdt'], c_pair['usdc']
                    
                    if not (ut['asks'] and ut['bids'] and uc['asks'] and uc['bids']):
                        continue
                
                    if ut['asks'][0][0] <= 0 or uc['asks'][0][0] <= 0: 
                        continue
                
                    # 基点 (BP) 价差公式计算
                    bp_open = (uc['bids'][0][0] - ut['asks'][0][0]) / ut['asks'][0][0] * 10000
                    bp_close = (ut['bids'][0][0] - uc['asks'][0][0]) / uc['asks'][0][0] * 10000
                    
                    depth_open = uc['bids'][0][1]
                    depth_close = uc['asks'][0][1]
                
                    # 压入秒级统计分桶
                    buckets[base][1].add_data(ts_sec, bp_open, depth_open)
                    buckets[base][2].add_data(ts_sec, bp_close, depth_close)

            except ccxt.BaseError as ce:
                logging.warning(f"⚠️ [{symbol}] MEXC 流协议层异常: {ce}。5秒后自动重连...")
                await asyncio.sleep(5)
            except Exception as e:
                logging.error(f"❌ [{symbol}] 业务处理流发生非预期异常: {e}。堆栈:\n{traceback.format_exc()}")
                await asyncio.sleep(5)

    async def start(self):
        logging.info(f"🚀 [全量运营模式] 检测到共需订阅 {len(self.sym_to_base)} 个流通道。")
        logging.info(f"🧱 [分流机制] 成功切分为 {len(self.connection_groups)} 个独立物理物理连接组 (每组最多 30 个 Streams 限制)。")

        # 错峰并行或串行处理每一个分配组
        for g_idx, group in enumerate(self.connection_groups):
            logging.info(f"📡 Step [3/5] 正在初始化并错峰激活第 [{g_idx + 1}/{len(self.connection_groups)}] 个物理连接组...")
            
            # 1. 创建该组专属的独立物理底层实例
            exchange_inst = self.create_mexc_instance(g_idx)
            self.exchanges.append(exchange_inst)
            
            # 2. 为该独立连接驱动开启专属心跳维护盲发协程
            hb_task = asyncio.create_task(self.send_heartbeat_loop(exchange_inst))
            self.heartbeat_tasks.append(hb_task)
            
            # 3. 错峰部署本组内的所有 Streams 订阅通道任务（限制发送频率，防止触发 100次/s 阈值）
            for symbol, is_usdt in group:
                task = asyncio.create_task(self.watch_single_symbol_loop(exchange_inst, symbol, is_usdt))
                self.listener_tasks.append(task)
                await asyncio.sleep(0.2)
                
                # 🔥 终极生产安全阀：每建立一个 Stream 强行休眠 0.15 秒 (相当于每秒约 6 次订阅，极其安全地处于 100次/s 的限制下)
                await asyncio.sleep(1)
            
            # 物理组之间额外增加 1.5 秒冷却平滑，确保建立握手不集中挤压
            await asyncio.sleep(1.5)

        logging.info(f"🎯 MEXC 全量 {len(self.listener_tasks)} 个流监控管道已经全部通过连接池分组错峰就绪！开始执行全局套利监控。")
        
        # 汇总合并执行
        all_tasks = self.listener_tasks + self.heartbeat_tasks
        await asyncio.gather(*all_tasks, return_exceptions=True)


# --- 4. 📊 5秒时钟聚合引擎 (保持原落库机制不变) ---

async def aggregator_engine():
    """每5秒掐点聚合全量对齐数据，并向 DB 异步队列推送"""
    logging.info("Step [4/5] 📊 [聚合时钟] 核心聚合时钟引擎调度就绪。")
    last_5sec_processed = -1
    while True:
        await asyncio.sleep(1.0 - (time.time() % 1.0))
        now_ts = int(time.time())
        last_sec = now_ts - 1
        curr_5sec_start = (last_sec // 5) * 5

        if last_sec % 5 == 2 and curr_5sec_start != last_5sec_processed:
            last_5sec_processed = curr_5sec_start
            target_5sec = curr_5sec_start - 5 
            
            active_write_count = 0
            for symbol, sides in buckets.items():
                for side, bucket in sides.items():
                    m_res = bucket.pop_5sec_stats(target_5sec)
                    if m_res:
                        mbp_max, mbp_min, mbp_avg, md_max, md_min, md_avg = m_res
                        
                        # 🎯 2. 【核心优化点】在这里拦截平均基点 (bp_avg)
                        # 如果这 5 秒内统计出来的平均价差低于 -10 BP，说明不具备套利观测价值，直接丢弃，不入库
                        if mbp_avg < -10.0:
                            continue
                        
                        db_srv.write_queue.put({
                            "t_type": "TRE", "symbol": symbol, "ts": target_5sec * 1000,
                            "side": side, 
                            "bp_max": mbp_max, "bp_min": mbp_min, "bp_avg": mbp_avg,
                            "depth_max": md_max, "depth_min": md_min, "depth_avg": md_avg 
                        })
                        active_write_count += 1
            if active_write_count > 0:
                logging.info(f"💾 [聚合时钟] 周期 {target_5sec} 全量处理完毕，向 DB 队列批量推送了 {active_write_count} 条统计记录。")

# --- 5. 🚀 全量主运行控制入口 ---

async def main():
    logging.info("Step [0/5] 🛡️ [初始化] 正在建立全局核心依赖关系及启动序列校验...")
    
    # 1. 扫描全市场可用双向币种
    valid_pairs = discover_mexc_pairs() 
    if not valid_pairs:
        logging.error("❌ 未动态扫描到可用的双向套利资产，全量运营中止。")
        return
    
    # 2. 全量表结构初始化检查
    logging.info("Step [2/5] 💾 [数据库] 开始同步检查并初始化本地资产库表结构...")
    all_names = [p['name'] for p in valid_pairs]
    db_srv.sync_init_all_tables(all_names)
    logging.info("  -> 本地数据表同步挂载完成。")
    
    # 3. 启动全量生产核心引擎阵列（已无缝替换为 mexcWSManager）
    tasks = [
        asyncio.create_task(aggregator_engine()),
        asyncio.create_task(mexcWSManager(valid_pairs).start())
    ]
    
    logging.info("Step [5/5] 🎉 [主调度环] 全网协同异步常驻监控任务注入完毕，正全速运转中。")
    try:
        await asyncio.gather(*tasks)
    except Exception as main_e:
        logging.critical(f"🛑 生产主调度环致命崩溃: {main_e}", exc_info=True)

if __name__ == "__main__":
    print(">>> [🛡️ 强制初始化监控] 正在执行 Python 底层编译器及模块导入完整性校验...", flush=True)
    asyncio.run(main())