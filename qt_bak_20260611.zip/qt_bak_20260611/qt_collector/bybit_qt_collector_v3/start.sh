#!/bin/bash
nohup python3 bybit_qt_collector.py > log/bybit_qt_collector.log 2>&1 &
echo "🚀 采集器和API服务已在后台启动！"
