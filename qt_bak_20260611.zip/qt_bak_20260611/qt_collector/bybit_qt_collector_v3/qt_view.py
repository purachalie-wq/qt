# -*- coding: UTF-8 -*-
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from sqlalchemy import create_engine, text
from datetime import datetime, timedelta
import time

# 假设这几个函数在 comm.py 里没问题
from comm import get_symbol_realtime_metrics, get_funding_arbitrage_stats

# --- 1. 基础配置与数据库连接 ---
st.set_page_config(page_title="Arbitrage Monitor Pro", layout="wide")
DB_URI = "mysql+pymysql://qt:M6HRcZAasYTjhmWr@127.0.0.1:3306/qt"
engine = create_engine(DB_URI)

# --- 2. 注入样式 ---
st.markdown("""
<style>
    .stApp { background-color: #000000 !important; color: #FFFFFF !important; }
    [data-testid="stSidebar"] { background-color: #050505 !important; border-right: 1px solid #222 !important; }
    [data-testid="stSidebar"] div, [data-testid="stSidebar"] label, [data-testid="stSidebar"] span, [data-testid="stSidebar"] p { 
        color: #e0e0e0 !important; font-weight: 500 !important; 
    }
    [data-testid="stWidgetLabel"] p { color: #AAAAAA !important; }
    div[data-testid="stRadio"] label p { color: #FFFFFF !important; }
    [data-testid="stMetricValue"] { color: #FFFFFF !important; font-weight: 800 !important; }
    header { visibility: hidden; }
    footer { visibility: hidden; }
</style>
""", unsafe_allow_html=True)

# --- 3. 数据处理核心函数 (必须放在调用者前面) ---

def get_sorted_symbols():
    """计算最近 24 小时每个币种的最大利差分值"""
    stats = []
    now_ms = int(time.time() * 1000)
    ts_limit = now_ms - (24 * 60 * 60 * 1000)
    
    print(f"\n{'='*60}")
    print(f"后台任务：开始刷新 24 小时数据统计 (阈值: {ts_limit})")
    
    try:
        with engine.connect() as conn:
            result = conn.execute(text("SHOW TABLES LIKE 'arb_5s_TREND_%'"))
            tables = [row[0] for row in result]
            
            for t in tables:
                sym = t.replace('arb_5s_TREND_', '')
                
                # 显式拆分 Side 计算，防止 MAX 被 ELSE 0 干扰
                q_s1 = text(f"SELECT MAX(bp_avg) FROM {t} WHERE side = 1 AND ts >= :ts_limit")
                q_s2 = text(f"SELECT MAX(bp_avg) FROM {t} WHERE side = 2 AND ts >= :ts_limit")
                
                res1 = conn.execute(q_s1, {"ts_limit": ts_limit}).scalar()
                res2 = conn.execute(q_s2, {"ts_limit": ts_limit}).scalar()
                
                v1 = float(res1) if res1 is not None else 0.0
                v2 = float(res2) if res2 is not None else 0.0
                score = v1 + v2
                
                # 日志埋点
                if sym == "EIGEN":
                    print(f"[DEBUG EIGEN] Side1: {v1} | Side2: {v2} | Total: {score}")
                
                stats.append({"symbol": sym, "score": score})
                
        print(f"后台任务：计算完毕")
        return sorted(stats, key=lambda x: x['score'], reverse=True)
    except Exception as e:
        print(f"!!! 后台任务计算错误: {e}")
        return []

@st.cache_resource
def get_static_symbols_with_tags():
    """初始化侧边栏列表，只在启动或手动刷新时运行"""
    # 这一行之前报错是因为 get_sorted_symbols 定义在了后面
    raw_stats = get_sorted_symbols() 
    
    final_stats = []
    try:
        for item in raw_stats:
            sym = item['symbol']
            score = item['score']
            
            # 成交额打标
            m = get_symbol_realtime_metrics(sym)
            vol = m.get('volume_24h_usdc', 0) if m.get('status') == 'success' else 0
            
            tag = ""
            if 10000 <= vol < 20000: tag = "⭐"
            elif 20000 <= vol < 50000: tag = "⭐⭐"
            elif vol >= 50000: tag = "⭐⭐⭐"
            
            final_stats.append({
                "symbol": sym, 
                "score": score, 
                "tag": tag,
                "display_name": f"{sym} ({score:.2f}{tag})"
            })
        return final_stats
    except Exception as e:
        st.error(f"初始化打标失败: {e}")
        return []

# --- 4. 数据加载逻辑 ---

if 'all_symbols_data' not in st.session_state:
    with st.spinner("🚀 正在同步数据库，请稍候..."):
        st.session_state.all_symbols_data = get_static_symbols_with_tags()

def get_raw_data(symbol, hours):
    table = f"arb_5s_TREND_{symbol.upper()}"
    start_ts = int((datetime.now() - timedelta(hours=hours)).timestamp() * 1000)
    try:
        query = f"SELECT ts, side, bp_max, bp_min, bp_avg, depth_avg FROM {table} WHERE ts >= {start_ts}"
        df = pd.read_sql(query, engine)
        if not df.empty:
            df['time'] = pd.to_datetime(df['ts'], unit='ms') + timedelta(hours=8)
        return df
    except: return pd.DataFrame()

# --- 5. 侧边栏渲染 ---
with st.sidebar:
    st.markdown("### 🪙 币种列表")
    data_list = st.session_state.get('all_symbols_data', [])
    
    if data_list:
        options = [s['symbol'] for s in data_list]
        display_map = {s['symbol']: s['display_name'] for s in data_list}
        
        selected_symbol = st.radio(
            "选择监控目标",
            options,
            format_func=lambda x: display_map.get(x, x),
            label_visibility="collapsed",
            key="symbol_selector"
        )
        
        if st.button("🔄 强制刷新数据 (清除缓存)"):
            st.cache_resource.clear()
            # 清除 state 强制重新执行 get_static_symbols_with_tags
            if 'all_symbols_data' in st.session_state:
                del st.session_state.all_symbols_data
            st.rerun()
    else:
        st.warning("暂无数据，请检查数据库")
        st.stop()

# --- 6. 主页面图表 ---
if selected_symbol:
    st.markdown(f"## 📊 {selected_symbol} 实时监控")
    
    # 顶部指标卡
    rt_metrics = get_symbol_realtime_metrics(selected_symbol)
    arb_stats = get_funding_arbitrage_stats(selected_symbol)
    if rt_metrics.get("status") == "success":
        m1, m2, m3, m4, m5, m6 = st.columns(6)
        with m1: st.metric("指数价格", f"${rt_metrics['price']:,.4f}")
        with m2: st.metric("24H成交额", f"${rt_metrics['volume_24h_usdc']/10000:,.1f}W")
        with m3: st.metric("现有持仓", f"${rt_metrics['oi_value_usdc']/10000:,.1f}W")
        with m4: st.metric("实时费率", f"{rt_metrics['current_funding_rate']*100:.4f}%")
        if "err" not in arb_stats:
            with m5: st.metric("26年利差", f"{arb_stats['apr_2026_diff']:.2%}")
            with m6: st.metric("30天利差", f"{arb_stats['apr_30d_diff']:.2%}")

    c_v, c_t = st.columns([1, 1])
    with c_v: view_mode = st.radio("视图切换", ["up", "down", "UP-OPEN", "UP-CLOSE"], horizontal=True)
    with c_t: time_range = st.radio("时间范围", ["3小时", "24小时", "7天"], index=1, horizontal=True)

    h_map = {"3小时": 3, "24小时": 24, "7天": 168}
    df_raw = get_raw_data(selected_symbol, h_map[time_range])

    if not df_raw.empty:
        fig = go.Figure()
        def add_trace_points(side, y_col, name, flip=False, filter_pos=True, show_colorbar=False):
            mask = (df_raw['side'] == side)
            if filter_pos: mask &= (df_raw['bp_avg'] >= 0)
            sub = df_raw[mask].copy()
            if sub.empty: return
            y_vals = -sub[y_col] if flip else sub[y_col]
            fig.add_trace(go.Scattergl(
                x=sub['time'], y=y_vals,
                mode='markers', name=name,
                showlegend=False,
                marker=dict(
                    size=16, color=sub['depth_avg'], colorscale="Turbo", 
                    showscale=show_colorbar, opacity=1.0, line=dict(width=0),
                    colorbar=dict(title="Depth", thickness=15, x=1.02, tickfont=dict(color="white")) if show_colorbar else None
                ),
                customdata=np.stack((sub['bp_max'], sub['bp_min'], sub['depth_avg']), axis=-1),
                hovertemplate="时间: %{x}<br>价差: %{y:.2f}<br>Depth: %{customdata[2]:.2f}<extra></extra>"
            ))

        if view_mode == "up":
            add_trace_points(1, 'bp_avg', "Open", show_colorbar=True)
            add_trace_points(2, 'bp_avg', "Close", flip=True)
        elif view_mode == "down":
            add_trace_points(2, 'bp_avg', "Close", show_colorbar=True)
            add_trace_points(1, 'bp_avg', "Open", flip=True)
        elif view_mode == "UP-OPEN":
            add_trace_points(1, 'bp_avg', "Open Only", filter_pos=False, show_colorbar=True)
        elif view_mode == "UP-CLOSE":
            add_trace_points(2, 'bp_avg', "Close Only", filter_pos=False, show_colorbar=True)

        fig.update_layout(
            template="plotly_dark", height=550, paper_bgcolor="#000000", plot_bgcolor="#000000",
            margin=dict(l=20, r=80, t=20, b=20),
            xaxis=dict(showgrid=False, tickformat="%H:%M", linecolor="#333", zeroline=False),
            yaxis=dict(gridcolor="rgba(255,255,255,0.05)", zerolinecolor="#FFFFFF", zerolinewidth=1, title="价差 (BP)"),
            hovermode="closest"
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("该范围内暂无数据")