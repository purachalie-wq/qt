# -*- coding: UTF-8 -*-
import pymysql
from dbutils.pooled_db import PooledDB
import threading
import queue
import re
import logging

# 日志配置
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "qt",
    "password": "sT36Hc2CwPbN8txY",
    "database": "qt",
    "charset": "utf8mb4"
}

POOL = PooledDB(
    creator=pymysql, 
    maxconnections=30, 
    blocking=True, 
    ping=1, 
    **DB_CONFIG
)

class DBManager:
    def __init__(self):
        self.write_queue = queue.Queue()
        self.initialized_tables = set()
        self.writer_thread = threading.Thread(target=self._batch_writer, daemon=True)
        self.writer_thread.start()
        logging.info("✅ [DB] 异步批量写入线程已启动 (极简硬核版)")

        
    def sync_init_all_tables(self, symbol_list):
        """
        [启动时调用] 传入所有币种列表，一次性完成同步建表
        """
        logging.info(f"🚀 [DB] 开始初始化 {len(symbol_list)} 个币种的数据库表...")
        conn = POOL.connection()
        try:
            with conn.cursor() as cursor:
                for raw_symbol in symbol_list:
                    
                    safe_symbol = re.sub(r'[^a-zA-Z0-9]', '_', raw_symbol).upper()
                   
                    # --- 2. 趋势表 (分钟级记录) ---
                    cursor.execute(f"""
                        CREATE TABLE IF NOT EXISTS arb_5s_TREND_{safe_symbol} (
                            ts BIGINT, 
                            side TINYINT,
                            bp_max DECIMAL(10, 2), 
                            bp_min DECIMAL(10, 2), 
                            bp_avg DECIMAL(10, 2),
                            depth_max DECIMAL(16, 4),
                            depth_min DECIMAL(16, 4),
                            depth_avg DECIMAL(16, 4),
                            PRIMARY KEY (ts, side)
                        ) ENGINE=InnoDB;
                    """)
                    self.initialized_tables.add(safe_symbol)
            conn.commit()
            logging.info("✅ [DB] 所有币种表初始化检查完成")
        finally:
            conn.close()

    def _batch_writer(self):
        """异步批量写入逻辑"""
        while True:
            batch = []
            try:
                # 累积 200 条或等待 3 秒执行一次写入
                while len(batch) < 200:
                    item = self.write_queue.get(timeout=3)
                    batch.append(item)
            except queue.Empty:
                pass

            if not batch:
                continue

            conn = POOL.connection()
            try:
                with conn.cursor() as cursor:
                    for item in batch:
                        # 1. 【修改点】用 get 取值，绝对不污染、不破坏原字典
                        t_type = item.get('t_type')
                        raw_symbol = item.get('symbol')
                        
                        # 2. 【必须解开注释】否则下一行会报错 safe_symbol 未定义
                        safe_symbol = re.sub(r'[^a-zA-Z0-9]', '_', raw_symbol).upper()
                        table_name = f"arb_5s_TREND_{safe_symbol}"
                        
                        # 3. 【新增】因为没用 pop，字典里还有 t_type 和 symbol，必须过滤掉再拼 SQL
                        data = {k: v for k, v in item.items() if k not in ['t_type', 'symbol']}
                        
                        # 4. 动态构建 SQL (注意这里改成用 data)
                        cols = ", ".join(data.keys())
                        placeholders = ", ".join(["%s"] * len(data))
                        sql = f"INSERT IGNORE INTO {table_name} ({cols}) VALUES ({placeholders})"
                        
                        # 5. 执行时传入 data.values()
                        cursor.execute(sql, list(data.values()))
                conn.commit()
            except Exception as e:
                logging.error(f"❌ [DB Error] 批量写入失败: {e}")
            finally:
                conn.close()

db_srv = DBManager()