# -*- coding: UTF-8 -*-
import asyncio
import ccxt.pro as ccxt
import time
import logging
from collections import defaultdict
from db_manager import db_srv  # 假设你的数据库写入服务已就绪
from symbol_bucket import SymbolBucket
import requests

# --- 基础配置 ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
SYMBOL_CONFIGS = {"DEFAULT": {"threshold": 10.0}}
buckets = defaultdict(dict)  # 全局容器：{symbol: {side: SymbolBucket}}

def discover_bybit_pairs():
    """功能一：自动发现全量双向套利币种"""
    logging.info("🔍 正在扫描 Bybit 市场币种...")
    try:
        # 获取所有线性合约信息
        url = "https://api.bybit.com/v5/market/instruments-info?category=linear&limit=1000"
        data = requests.get(url, timeout=10).json()
        if data['retCode'] != 0: raise Exception("API请求失败")
        
        raw_list = data['result']['list']
        usdt_set = {i['baseCoin'] for i in raw_list if i['quoteCoin'] == 'USDT'}
        usdc_set = {i['baseCoin'] for i in raw_list if i['quoteCoin'] == 'USDC'}
        
        # 取交集：必须同时有 USDT 和 USDC 对
        common_bases = usdt_set.intersection(usdc_set)
        
        only_usdt = usdt_set - usdc_set
        logging.info(f"仅有 USDT 对的币种数量: {len(only_usdt)}")
        logging.info(f"仅有 USDT 的前 5 个: {list(only_usdt)[:5]}")
        
        valid_pairs = []
        for base in common_bases:
            # 找到具体的 symbol 名 (例如 BTCUSDT)
            u_sym = next(i['symbol'] for i in raw_list if i['baseCoin'] == base and i['quoteCoin'] == 'USDT')
            c_sym = next(i['symbol'] for i in raw_list if i['baseCoin'] == base and i['quoteCoin'] == 'USDC')
            valid_pairs.append({"name": base, "usdt": u_sym, "usdc": c_sym})
            
            # 功能二：初始化双向 Bucket (每一路 2 张表在 db_manager 自动处理)
            buckets[base][1] = SymbolBucket(base, 1)
            buckets[base][2] = SymbolBucket(base, 2)
            
        logging.info(f"✅ 发现 {len(valid_pairs)} 个双向对: {[p['name'] for p in valid_pairs]}")
        return valid_pairs
    except Exception as e:
        logging.error(f"❌ 币种扫描崩溃: {e}")
        return []
        
# --- 2. 采集引擎 (源头分桶) ---

async def collect_ob(pair, exchange):
    """单个币种采集协程：秒级分桶"""
    base = pair['name']
    cache = {'usdt': None, 'usdc': None}

    async def watch_side(symbol, is_usdt):
        while True:
            try:
                ob = await exchange.watch_order_book(symbol, limit=1)
                ts_sec = int(time.time()) # 取整秒时间戳作为 Key
                
                if is_usdt: cache['usdt'] = ob
                else: cache['usdc'] = ob
                
                if cache['usdt'] and cache['usdc']:
                    ut, uc = cache['usdt'], cache['usdc']
                    if not (ut['asks'] and uc['bids']): continue
                
                    if ut['asks'][0][0] <= 0 or uc['asks'][0][0] <= 0: continue
    
                    # 计算 BP
                    bp_open = (uc['bids'][0][0] - ut['asks'][0][0]) / ut['asks'][0][0] * 10000
                    bp_close = (ut['bids'][0][0] - uc['asks'][0][0]) / uc['asks'][0][0] * 10000
                    
                    # 提取 USDC 深度 (Amount)
                    # Side 1: 开仓时看 USDC 的 Bids (你要卖给买家)
                    # Side 2: 平仓时看 USDC 的 Asks (你要从卖家买回)
                    depth_open = uc['bids'][0][1]
                    depth_close = uc['asks'][0][1]
                
                    # 调用更新后的 add_data
                    buckets[base][1].add_data(ts_sec, bp_open, depth_open)
                    buckets[base][2].add_data(ts_sec, bp_close, depth_close)
                    
                    # 存入类实例
                    #buckets[base][1].add_bp(ts_sec, bp_open)
                    #buckets[base][2].add_bp(ts_sec, bp_close)

            except Exception as e:
                await asyncio.sleep(5)

    await asyncio.gather(watch_side(pair['usdt'], True), watch_side(pair['usdc'], False))

# --- 3. 聚合引擎 (掐点聚合) ---

async def aggregator_engine():
    """
    1. SIG 表：仅存超过阈值的秒聚合数据。
    2. TRE 表：每5秒存储全量对齐数据。
    """
    # 1. 变量名改为记录上一个处理的 5秒周期
    last_5sec_processed = -1 
    
    while True:
        await asyncio.sleep(1.0 - (time.time() % 1.0)) # 依然保持1秒的物理对齐，防止时间漂移
        
        now_ts = int(time.time())
        last_sec = now_ts - 1
        
        # 2. 计算当前秒所在的 5秒周期 起始时间戳
        # 例如 last_sec 是 13，那么 13//5 = 2，2*5 = 10
        curr_5sec_start = (last_sec // 5) * 5

        # 3. 触发条件：当前秒刚好是5的倍数（如 10, 15, 20），且这个周期没被处理过
        if last_sec % 5 == 2 and curr_5sec_start != last_5sec_processed:
            
            last_5sec_processed = curr_5sec_start

            target_5sec = curr_5sec_start - 5
            
            for symbol, sides in buckets.items():
                conf = SYMBOL_CONFIGS.get(symbol, SYMBOL_CONFIGS["DEFAULT"])
                for side, bucket in sides.items():

                    # --- B. 写入趋势表 (TRE)：5秒全量 ---
                    # 5. 【注意】这里调用的方法需要你在 bucket 类中实现或修改
                    m_res = bucket.pop_5sec_stats(target_5sec) 
                    if m_res:
                        mbp_max, mbp_min, mbp_avg, md_max, md_min, md_avg = m_res
                        
                        # 🎯 2. 【核心优化点】在这里拦截平均基点 (bp_avg)
                        # 如果这 5 秒内统计出来的平均价差低于 -10 BP，说明不具备套利观测价值，直接丢弃，不入库
                        if mbp_avg < -10.0:
                            continue
                        
                        db_srv.write_queue.put({
                            "t_type": "TRE", "symbol": symbol, "ts": target_5sec * 1000,
                            "side": side, 
                            "bp_max": mbp_max, "bp_min": mbp_min, "bp_avg": mbp_avg,
                            "depth_max": md_max, "depth_min": md_min, "depth_avg": md_avg 
                        })

# --- 4. 启动逻辑 ---

async def main():
    # 假设这里是你的币种初始化逻辑
    #valid_pairs = [{"name": "BTC", "usdt": "BTCUSDT", "usdc": "BTCUSDC"}] 
    valid_pairs = discover_bybit_pairs() # 调用你的全量扫描
    if not valid_pairs:
        logging.error("❌ 未发现任何交易对，程序退出")
        return
    
    # 2. 【核心优化】立即进行数据库同步初始化[cite: 1]
    all_names = [p['name'] for p in valid_pairs]
    db_srv.sync_init_all_tables(all_names)
    
    #for p in valid_pairs:
        #buckets[p['name']][1] = SymbolBucket(p['name'], 1)
        #buckets[p['name']][2] = SymbolBucket(p['name'], 2)

    exchange = ccxt.bybit({'enableRateLimit': True})
    
    tasks = [asyncio.create_task(aggregator_engine())]
    for p in valid_pairs:
        tasks.append(asyncio.create_task(collect_ob(p, exchange)))
    
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())