#!/bin/bash

APP_CMD="streamlit run qt_view.py"
LOG_DIR="log"
LOG_FILE="${LOG_DIR}/qt_view.log"

# 检查是否正在运行
is_running() {
    pgrep -f "$APP_CMD" > /dev/null 2>&1
}

# 启动
start() {
    if is_running; then
        echo "[INFO] $APP_CMD 已经在运行中。PID: $(pgrep -f "$APP_CMD")"
        return 1
    fi
    
    echo "[INFO] 正在启动 $APP_CMD ..."
    mkdir -p "$LOG_DIR"
    nohup $APP_CMD --server.port 8502 > "$LOG_FILE" 2>&1 &
    sleep 1
    
    if is_running; then
        echo "[INFO] 启动成功。日志文件: $LOG_FILE"
    else
        echo "[ERROR] 启动失败，请查看日志: $LOG_FILE"
        return 1
    fi
}

# 停止
stop() {
    if ! is_running; then
        echo "[INFO] $APP_CMD 未在运行。"
        return 0
    fi
    
    local pids=$(pgrep -f "$APP_CMD")
    echo "[INFO] 正在停止 $APP_CMD (PIDs: $pids)..."
    
    # 先尝试优雅关闭
    pkill -f "$APP_CMD"
    sleep 2
    
    # 如果还没死，强杀
    if is_running; then
        echo "[WARN] 进程未响应，正在强制杀死..."
        pkill -9 -f "$APP_CMD"
    fi
    
    echo "[INFO] 已停止。"
}

# 重启
restart() {
    echo "[INFO] 正在重启 $APP_CMD ..."
    stop
    sleep 1
    start
}

# 根据输入参数执行对应函数
case "$1" in
    start)   start   ;;
    stop)    stop    ;;
    restart) restart ;;
    *)
        echo "用法: $0 {start|stop|restart}"
        exit 1
        ;;
esac
