# -*- coding: UTF-8 -*-
import asyncio
import ccxt.pro as ccxt
import time
import logging
import traceback
import os
import json
from collections import defaultdict
from db_manager import db_srv  
from symbol_bucket import SymbolBucket  

# --- 1. 基础配置与全局状态看板 ---
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s'
)

# 全局秒级聚合容器：{symbol: {side: SymbolBucket}}
buckets = defaultdict(dict)  

# 引入币种层级的消息高频计数器看板，用于5秒周期双向熔断筛查
global_msg_counters = defaultdict(lambda: {"usdt": 0, "usdc": 0})

# 动态调试全局变量：保存当前需要显微镜捕捉打印的币种名称（如 "BCH"）
CURRENT_CHECKPOINT = None  
CONFIG_FILE_PATH = "config.json"

# --- 2. 🔍 动态双向币种发现引擎 (利用 CCXT 市场元数据进行交叉过滤) ---

async def discover_bitget_pairs_via_ccxt(exchange):
    """
    通过 CCXT 市场元数据自动、精准发现全量双向套利币种。
    """
    logging.info("🔍 正在通过 CCXT 元数据扫描 Bitget 市场全量币种...")
    try:
        markets = await exchange.load_markets()
        
        usdt_perp_map = {}  # {base: symbol}
        usdc_perp_map = {}  # {base: symbol}
        
        for symbol, market in markets.items():
            if not market.get('active', True):
                continue
                
            # 必须是线性永续合约 (swap)
            if not market.get('linear') or market.get('type') != 'swap':
                continue
                
            base = market.get('base')
            quote = market.get('quote')
            
            if quote == 'USDT':
                usdt_perp_map[base] = symbol
            elif quote == 'USDC':
                usdc_perp_map[base] = symbol

        # 取交集
        common_bases = set(usdt_perp_map.keys()).intersection(set(usdc_perp_map.keys()))
        
        valid_pairs = []
        for base in sorted(list(common_bases)):
            valid_pairs.append({
                "name": base,
                "usdt": usdt_perp_map[base],
                "usdc": usdc_perp_map[base]
            })
            
        logging.info(f"✅ 扫描完毕！成功提炼出 {len(valid_pairs)} 个同时具备 USDT 和 USDC 永续的双向套利币种。")
        return valid_pairs
    except Exception as e:
        logging.error(f"❌ 扫描 Bitget 市场元数据遭遇致命异常: {e}")
        return []

# --- 3. 🎯 10秒轮询：配置文件 coin_checkpoint 动态读取协程 ---

async def load_config_loop():
    """每10秒读取一次配置文件，动态更新需要全量打印数据的调试币种"""
    global CURRENT_CHECKPOINT
    while True:
        try:
            if os.path.exists(CONFIG_FILE_PATH):
                with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
                    config_data = json.load(f)
                    new_checkpoint = config_data.get("coin_checkpoint")
                    if new_checkpoint:
                        new_checkpoint = str(new_checkpoint).strip().upper()
                    
                    if new_checkpoint != CURRENT_CHECKPOINT:
                        CURRENT_CHECKPOINT = new_checkpoint
                        logging.info(f"🔬 [动态配置] 监测到 coin_checkpoint 变更为: [{CURRENT_CHECKPOINT}]，开启全流程桶日志追踪。")
            else:
                default_config = {"coin_checkpoint": ""}
                with open(CONFIG_FILE_PATH, 'w', encoding='utf-8') as f:
                    json.dump(default_config, f, indent=4)
        except Exception as e:
            logging.warning(f"⚠️ [动态配置] 读取配置文件失败: {e}")
        
        await asyncio.sleep(10.0)

# --- 4. 🌐 Bitget 独立 WebSocket 流水线集群管理器 ---

class BitgetWSManager:
    def __init__(self, chunk_pairs, exchange, cluster_id):
        self.valid_pairs = chunk_pairs    # 当前集群分得的套利对切片
        self.exchange = exchange          # 当前集群专属的物理 CCXT 实例
        self.cluster_id = cluster_id      # 集群编号
        self.listener_tasks = []
        self.heartbeat_task = None
        
        # 建立快速反查表：通过交易所推送的底层 symbol，直接秒回对应的标准 base 币种名
        self.sym_to_base = {}
        for p in self.valid_pairs:
            self.sym_to_base[p['usdt']] = p['name']
            self.sym_to_base[p['usdc']] = p['name']
            
        # 针对每个币种独立设计单侧行情时间戳和最新缓存
        self.cache = defaultdict(lambda: {'usdt': None, 'usdc': None})

    async def send_heartbeat_loop(self):
        """当前物理连接专属的 30秒 盲发纯文本 Ping 心跳协程"""
        while True:
            await asyncio.sleep(30.0)
            try:
                if hasattr(self.exchange, 'clients') and self.exchange.clients:
                    for url, client in list(self.exchange.clients.items()):
                        is_connected = getattr(client, 'connected', False) or getattr(client, 'isOpen', False)
                        if is_connected and hasattr(client, 'send'):
                            await client.send("ping")
            except Exception as e:
                logging.warning(f"⚠️ [Cluster {self.cluster_id}] 底层网络网络帧心跳发送失败: {e}")

    async def watch_single_symbol_loop(self, symbol, is_usdt):
        """单个动态资产行情流常驻监听协程"""
        base = self.sym_to_base.get(symbol)
        side_key = 'usdt' if is_usdt else 'usdc'
        
        while True:
            try:
                # 强卡官方最高频 books1 单档深度流
                order_book = await self.exchange.watch_order_book(symbol, limit=1)
                
                if not order_book or not order_book.get('asks') or not order_book.get('bids'):
                    continue
                
                # 🎯【对齐 Bybit 1】：取当前整秒时间戳作为分桶 Key
                ts_sec = int(time.time()) 

                # 🔬 【调试打印一：全量流量接收拦截】
                if CURRENT_CHECKPOINT and base == CURRENT_CHECKPOINT:
                    ask_price, bid_price = float(order_book['asks'][0][0]), float(order_book['bids'][0][0])
                    logging.info(
                        f"🔬 [DEBUG_FLOW] 币种: {base} | 市场: {side_key.upper()} | "
                        f"接收本地时间戳: {ts_sec} | 买一: {bid_price} | 卖一: {ask_price}"
                    )

                # 🎯【对齐 Bybit 2】：直接缓存原生 orderbook，不组装 ob_data
                self.cache[base][side_key] = order_book

                # 每次收到行情，累加币种维度的全局独立计数器（用于 5秒周期 双向一票否决熔断）
                global_msg_counters[base][side_key] += 1

                # --- 🧠 双侧跨侧交叉实时配对计算 ---
                c_pair = self.cache[base]
                
                if c_pair['usdt'] and c_pair['usdc']:
                    ut, uc = c_pair['usdt'], c_pair['usdc']
                    
                    # 🎯【对齐 Bybit 3】：去掉 2 秒时序盾牌，只做基本的有效性检查
                    # 补全了 Bybit 漏掉的 ut['bids'] 和 uc['asks'] 的非空判断，防止 IndexError
                    if not (ut['asks'] and ut['bids'] and uc['asks'] and uc['bids']):
                        continue
                    
                    # 🎯【对齐 Bybit 4】：增加价格合法性校验，防止除零错误
                    if ut['asks'][0][0] <= 0 or uc['asks'][0][0] <= 0:
                        continue
                        
                    # 精准执行双侧盘口交叉基点利差 (BP) 计算
                    bp_open = (uc['bids'][0][0] - ut['asks'][0][0]) / ut['asks'][0][0] * 10000
                    bp_close = (ut['bids'][0][0] - uc['asks'][0][0]) / uc['asks'][0][0] * 10000
                    
                    depth_open = uc['bids'][0][1]
                    depth_close = uc['asks'][0][1]
                    
                    # 确保分桶安全
                    if not buckets[base].get(1): buckets[base][1] = SymbolBucket(base, 1)
                    if not buckets[base].get(2): buckets[base][2] = SymbolBucket(base, 2)
                    
                    # 🎯【对齐 Bybit 5】：直接用当前秒 ts_sec 压桶，不用 max(ut, uc)
                    buckets[base][1].add_data(ts_sec, bp_open, depth_open)
                    buckets[base][2].add_data(ts_sec, bp_close, depth_close)

                    # 🔬 【调试打印四：成功压入分桶状态报告】
                    if CURRENT_CHECKPOINT and base == CURRENT_CHECKPOINT:
                        logging.info(
                            f"📥 [DEBUG_BUCKET] 币种 {base} 成功完成双侧配对并压入秒级分桶! "
                            f"对齐时间锚点: {ts_sec} | 开仓利差BP: {bp_open:.2f} | 平仓利差BP: {bp_close:.2f}"
                        )

            except ccxt.BaseError as ce:
                logging.warning(f"⚠️ [Cluster {self.cluster_id}][{symbol}] 协议层断线或限频异常: {ce}。5秒后断线重连...")
                if base in self.cache:
                    self.cache[base] = {'usdt': None, 'usdc': None}
                await asyncio.sleep(5)
            except Exception as e:
                logging.error(f"❌ [Cluster {self.cluster_id}][{symbol}] 业务层未预期严重异常: {e}。")
                await asyncio.sleep(5)


    async def start(self):
        """激活当前集群的一组常驻长连接流"""
        self.heartbeat_task = asyncio.create_task(self.send_heartbeat_loop())
        for p in self.valid_pairs:
            self.listener_tasks.append(asyncio.create_task(self.watch_single_symbol_loop(p['usdt'], is_usdt=True)))
            await asyncio.sleep(0.1)
            self.listener_tasks.append(asyncio.create_task(self.watch_single_symbol_loop(p['usdc'], is_usdt=False)))
            await asyncio.sleep(0.1)
        logging.info(f"✅ [Cluster {self.cluster_id}] 集群部署就绪。")
        await asyncio.gather(*self.listener_tasks, return_exceptions=True)

# --- 5. ⏰ 核心引擎：5秒时钟聚合与双向数据硬熔断清洗 ---

async def aggregator_engine():
    """全局唯一的5秒硬掐点聚合时钟，核心控制一票否决权"""
    logging.info("⏰ [聚合时钟] 全局统计落库引擎启动成功。")
    while True:
        now = time.time()
        sleep_time = 5.0 - (now % 5.0)
        await asyncio.sleep(sleep_time)
        
        target_5sec = int(time.time() // 5) * 5 - 5  

        active_write_count = 0
        current_symbols = list(buckets.keys())
        
        for symbol in current_symbols:
            usdt_count = global_msg_counters[symbol]["usdt"]
            usdc_count = global_msg_counters[symbol]["usdc"]
            
            # 🔬 【调试打印五：时钟周期到达，打印双向高频熔断看板计数】
            if CURRENT_CHECKPOINT and symbol == CURRENT_CHECKPOINT:
                logging.info(
                    f"⏰ [DEBUG_CLOCK] === 5秒截点结算触发 === | 目标周期时间戳: {target_5sec} |\n"
                    f"   币种: {symbol} | 本周期累计收到报文数 -> USDT市场: {usdt_count} 条，USDC市场: {usdc_count} 条"
                )
            
            # 🚨【一票否决制数据拦截】
            if usdt_count == 0 or usdc_count == 0:
                # 🔬 【调试打印六：触发一票否决死流倒桶报告】
                if CURRENT_CHECKPOINT and symbol == CURRENT_CHECKPOINT:
                    logging.warning(f"🚨 [DEBUG_CLOCK] 币种 {symbol} 由于单侧产生僵尸死流(计数为0)，强行触发一票否决熔断，清空并倒掉当前周期分桶！")
                
                if buckets[symbol].get(1): buckets[symbol][1].pop_5sec_stats(target_5sec)
                if buckets[symbol].get(2): buckets[symbol][2].pop_5sec_stats(target_5sec)
                global_msg_counters[symbol]["usdt"] = 0
                global_msg_counters[symbol]["usdc"] = 0
                continue
            
            for side in [1, 2]:
                bucket = buckets[symbol].get(side)
                if not bucket:
                    continue
                
                # 从分桶中提取结果
                stats_res = bucket.pop_5sec_stats(target_5sec)
                
                # 🔬 【调试打印七：分桶 pop 出来的真实结果透视】
                if CURRENT_CHECKPOINT and symbol == CURRENT_CHECKPOINT:
                    logging.info(f"📊 [DEBUG_CLOCK] 币种 {symbol} 方向(Side): {side} 从原始分桶中 pop 出的均值统计结果为: {stats_res}")

                if stats_res:
                    mbp_max, mbp_min, mbp_avg, md_max, md_min, md_avg = stats_res
                    
                    if mbp_avg < -20.0:
                        continue
                    
                    db_srv.write_queue.put({
                        "t_type": "TRE", "symbol": symbol, "ts": target_5sec * 1000,
                        "side": side, 
                        "bp_max": mbp_max, "bp_min": mbp_min, "bp_avg": mbp_avg,
                        "depth_max": md_max, "depth_min": md_min, "depth_avg": md_avg 
                    })
                    active_write_count += 1
            
            global_msg_counters[symbol]["usdt"] = 0
            global_msg_counters[symbol]["usdc"] = 0
                    
        if active_write_count > 0:
            logging.info(f"💾 [聚合时钟] 周期 {target_5sec} 数据拦截验证全部通过，向 DB 队列推送了 {active_write_count} 条利差记录。")

# --- 6. 🚀 系统集群总控入口 ---

async def main():
    exchange = ccxt.bitget({
        'enableRateLimit': True,
        'options': {
            'ws': {'heartbeat': False},  
            'watchOrderBook': {'channel': 'books1'} 
        }
    })
    logging.info("🔌 [System] CCXT 异步底层网关核心参数装配成功。")

    valid_pairs = await discover_bitget_pairs_via_ccxt(exchange)
    if not valid_pairs:
        logging.error("❌ 未能动态扫描到满足交集要求的双向套利底层资产，全量采集终止。")
        await exchange.close()
        return
        
    all_names = [p['name'] for p in valid_pairs]
    db_srv.sync_init_all_tables(all_names)
    
    # 显式初始化全局分桶（严格使用你原版的参数定义）
    for base in all_names:
        buckets[base][1] = SymbolBucket(base, 1)
        buckets[base][2] = SymbolBucket(base, 2)
        global_msg_counters[base]["usdt"] = 0
        global_msg_counters[base]["usdc"] = 0

    # 切片连接池逻辑（严禁改动业务）
    TOTAL_CLUSTERS = 4
    chunk_size = (len(valid_pairs) + TOTAL_CLUSTERS - 1) // TOTAL_CLUSTERS
    pair_chunks = [valid_pairs[i:i + chunk_size] for i in range(0, len(valid_pairs), chunk_size)]
    
    tasks = [
        asyncio.create_task(aggregator_engine()),  
        asyncio.create_task(load_config_loop())    
    ]
    
    cluster_exchanges = []
    for idx, chunk in enumerate(pair_chunks):
        if not chunk: continue
        
        exch = ccxt.bitget({
            'enableRateLimit': True,
            'options': {
                'ws': {'heartbeat': False},  
                'watchOrderBook': {'channel': 'books1'} 
            }
        })
        cluster_exchanges.append(exch)
        
        manager = BitgetWSManager(chunk, exch, cluster_id=idx+1)
        tasks.append(asyncio.create_task(manager.start()))
        await asyncio.sleep(2.0)
        
    logging.info(f"🚀 [System] 4路高速物理独立 WebSocket 池部署完毕，开始全流程诊断监听...")
    
    try:
        await asyncio.gather(*tasks)
    except KeyboardInterrupt:
        logging.info("🛑 接收到系统强制中断指令...")
    finally:
        for exch in cluster_exchanges:
            await exch.close()
        await exchange.close()
        logging.info("🏁 程序安全退出。")

if __name__ == '__main__':
    asyncio.run(main())