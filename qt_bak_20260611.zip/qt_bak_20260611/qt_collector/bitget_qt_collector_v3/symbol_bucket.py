# symbol_bucket.py 建议修改后的核心代码
class SymbolBucket:
    def __init__(self, symbol, side):
        self.symbol = symbol
        self.side = side
        # 结构：{ts: {'bp': [val1, val2], 'depth': [val1, val2]}}
        self.sec_buckets = {} 

    def add_data(self, ts, bp, depth):
        """同时存入价差和深度"""
        if ts not in self.sec_buckets:
            self.sec_buckets[ts] = {'bp': [], 'depth': []}
        self.sec_buckets[ts]['bp'].append(bp)
        self.sec_buckets[ts]['depth'].append(depth)

    def get_sec_stats(self, ts):
        """秒级聚合：获取该秒内 bp 和 depth 的 Max/Min/Avg"""
        data = self.sec_buckets.get(ts)
        if not data or not data['bp']: 
            return None
        
        bps, dps = data['bp'], data['depth']
        return (
            max(bps), min(bps), sum(bps)/len(bps),  # BP 三值
            max(dps), min(dps), sum(dps)/len(dps)   # Depth 三值
        )

    # --- 核心修改点在这里 ---
    def pop_5sec_stats(self, start_ts):
        """5秒聚合：提取过去 5 秒所有采样点进行全量计算"""
        all_bps, all_dps = [], []
        # 1. 遍历该 5 秒窗口内的 5 个秒桶 (原来是 +60)
        for t in range(start_ts, start_ts + 5):
            if t in self.sec_buckets:
                all_bps.extend(self.sec_buckets[t]['bp'])
                all_dps.extend(self.sec_buckets[t]['depth'])

        # --- 清理内存 ---
        expired = [t for t in self.sec_buckets if t < start_ts + 5]
        for k in expired: 
            self.sec_buckets.pop(k, None)
        
        if not all_bps: 
            return None
        
        res = (
            max(all_bps), min(all_bps), sum(all_bps)/len(all_bps),
            max(all_dps), min(all_dps), sum(all_dps)/len(all_dps)
        )
        
            
        return res