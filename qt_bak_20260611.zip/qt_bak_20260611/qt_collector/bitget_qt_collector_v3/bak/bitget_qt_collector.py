# -*- coding: UTF-8 -*-
import asyncio
import ccxt.pro as ccxt
import time
import logging
import traceback
from collections import defaultdict
from db_manager import db_srv  
from symbol_bucket import SymbolBucket  

# --- 1. 基础配置与日志系统 ---
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s'
)

buckets = defaultdict(dict)  # 全局秒级聚合容器：{symbol: {side: SymbolBucket}}

# --- 2. 🔍 动态双向币种发现引擎 (完美利用 CCXT 本地市场元数据进行交叉过滤) ---

async def discover_bitget_pairs_via_ccxt(exchange):
    """
    通过 CCXT 市场元数据自动、精准发现全量双向套利币种。
    不需要任何外部 requests，100% 保证符号能被 watch_ticker 识别。
    """
    logging.info("🔍 正在通过 CCXT 元数据扫描 Bitget 市场全量币种...")
    try:
        # 加载市场数据
        markets = await exchange.load_markets()
        
        # 分离出状态正常的 USDT 永续和 USDC 永续
        usdt_perp_map = {}  # {base: symbol}
        usdc_perp_map = {}  # {base: symbol}
        
        for symbol, market in markets.items():
            # 过滤非激活状态的合约
            if not market.get('active', True):
                continue
                
            # 必须是合约类型 (linear 永续)
            if not market.get('linear', False):
                continue
                
            base = market['base']
            settle = market['settle']
            
            if settle == 'USDT':
                usdt_perp_map[base] = symbol
            elif settle == 'USDC':
                usdc_perp_map[base] = symbol
                
        # 取交集：找出两条产品线同时存在的 base 币种
        common_bases = set(usdt_perp_map.keys()).intersection(set(usdc_perp_map.keys()))
        
        valid_pairs = []
        for base in common_bases:
            u_sym = usdt_perp_map[base]
            c_sym = usdc_perp_map[base]
            
            valid_pairs.append({"name": base, "usdt": u_sym, "usdc": c_sym})
            
            # 初始化双向阶梯 Bucket
            buckets[base][1] = SymbolBucket(base, 1)
            buckets[base][2] = SymbolBucket(base, 2)
            
        logging.info(f"✅ 扫描完毕。通过 CCXT 共发现 {len(valid_pairs)} 个完美对齐的双向套利对: {[p['name'] for p in valid_pairs]}")
        return valid_pairs
    except Exception as e:
        logging.error(f"❌ CCXT 币种扫描过滤引擎崩溃: {e}", exc_info=True)
        return []

# --- 3. 🦾 生产级全量运营单连接管理器 ---

class BitgetWSManager:
    def __init__(self, valid_pairs, exchange):
        self.valid_pairs = valid_pairs
        self.exchange = exchange
        self.heartbeat_task = None
        self.listener_tasks = []
        
        # 建立标准 CCXT 符号反查映射
        self.sym_to_base = {}
        for p in valid_pairs:
            self.sym_to_base[p['usdt']] = p['name']
            self.sym_to_base[p['usdc']] = p['name']
            
        self.cache = defaultdict(lambda: {'usdt': None, 'usdc': None})

    async def send_heartbeat_loop(self):
        """完全对齐生产环境，每 30 秒向物理 WS 连接盲发纯文本 'ping'，绝不干涉/处理任何回应"""
        while True:
            try:
                await asyncio.sleep(30)
                
                # 遍历底层所有活跃的物理连接，直接强行注入 "ping" 文本
                for client_id, client in self.exchange.clients.items():
                    if hasattr(client, 'send'):
                        logging.info(f"⚡ [Heartbeat] 正在向底层连接 [{client_id}] 盲发文本 'ping'...")
                        await client.send("ping")
                        
            except Exception as e:
                logging.error(f"🚨 [Heartbeat] 心跳盲发遭遇异常: {e}")

    async def watch_single_symbol_loop(self, symbol, is_usdt):
        """单个动态资产行情流常驻监听协程"""
        while True:
            try:
                # 订阅 1档 盘口（通过 options 配置，底层实际向 Bitget 网关要的就是 books1）
                ticker_data = await self.exchange.watch_ticker(symbol)
                ts_sec = int(time.time())

                if not ticker_data or 'ask' not in ticker_data or 'bid' not in ticker_data:
                    continue

                base = self.sym_to_base.get(symbol)
                if not base: 
                    continue
                
                # 将标准结构转换为内存统一对齐盘口格式
                ob_data = {
                    'asks': [[float(ticker_data['ask']), float(ticker_data.get('askVolume', 1.0))]],
                    'bids': [[float(ticker_data['bid']), float(ticker_data.get('bidVolume', 1.0))]]
                }
                
                if is_usdt: 
                    self.cache[base]['usdt'] = ob_data
                else: 
                    self.cache[base]['usdc'] = ob_data
                    
                # --- 🧠 双侧交叉对齐与核心 BP 价差统计计算 ---
                c_pair = self.cache[base]
                if c_pair['usdt'] and c_pair['usdc']:
                    ut, uc = c_pair['usdt'], c_pair['usdc']
                    
                    if not (ut['asks'] and ut['bids'] and uc['asks'] and uc['bids']):
                        continue
                
                    if ut['asks'][0][0] <= 0 or uc['asks'][0][0] <= 0: 
                        continue
                
                    # 基点 (BP) 价差公式计算
                    bp_open = (uc['bids'][0][0] - ut['asks'][0][0]) / ut['asks'][0][0] * 10000
                    bp_close = (ut['bids'][0][0] - uc['asks'][0][0]) / uc['asks'][0][0] * 10000
                    
                    depth_open = uc['bids'][0][1]
                    depth_close = uc['asks'][0][1]
                
                    # 压入秒级统计分桶
                    buckets[base][1].add_data(ts_sec, bp_open, depth_open)
                    buckets[base][2].add_data(ts_sec, bp_close, depth_close)

            except ccxt.BaseError as ce:
                logging.warning(f"⚠️ [{symbol}] CCXT 全量流协议层异常: {ce}。5秒后自动重连...")
                await asyncio.sleep(5)
            except Exception as e:
                logging.error(f"❌ [{symbol}] 业务处理流发生非预期异常: {e}。堆栈:\n{traceback.format_exc()}")
                await asyncio.sleep(5)

    async def start(self):
        # 1. 启动盲发心跳守护进程
        self.heartbeat_task = asyncio.create_task(self.send_heartbeat_loop())

        # 2. 提取全量运营下的各个产品线符号数组
        usdt_symbols = [p['usdt'] for p in self.valid_pairs]
        usdc_symbols = [p['usdc'] for p in self.valid_pairs]

        logging.info(f"🚀 [全量运营模式] 开始错峰建立全量 {len(self.valid_pairs) * 2} 个 books1 专属 WebSocket 订阅流...")

        # 错峰订阅全量 USDT 永续
        for sym in usdt_symbols:
            task = asyncio.create_task(self.watch_single_symbol_loop(sym, is_usdt=True))
            self.listener_tasks.append(task)
            # 生产安全阀门：每订阅一个流强行休眠 0.5 秒，平滑连接压力，防封 IP
            await asyncio.sleep(0.5)

        # 错峰订阅全量 USDC 永续
        for sym in usdc_symbols:
            task = asyncio.create_task(self.watch_single_symbol_loop(sym, is_usdt=False))
            self.listener_tasks.append(task)
            await asyncio.sleep(0.5)

        logging.info(f"🎯 全量 {len(self.listener_tasks)} 个监控流管道已错峰全部就绪，开始执行大规模套利数据抓取。")
        await asyncio.gather(*self.listener_tasks, return_exceptions=True)


# --- 4. 📊 5秒时钟聚合引擎 (保持原落库机制不变) ---

async def aggregator_engine():
    """每5秒掐点聚合全量对齐数据，并向 DB 异步队列推送"""
    last_5sec_processed = -1
    while True:
        await asyncio.sleep(1.0 - (time.time() % 1.0))
        now_ts = int(time.time())
        last_sec = now_ts - 1
        curr_5sec_start = (last_sec // 5) * 5

        if last_sec % 5 == 2 and curr_5sec_start != last_5sec_processed:
            last_5sec_processed = curr_5sec_start
            target_5sec = curr_5sec_start - 5 
            
            active_write_count = 0
            for symbol, sides in buckets.items():
                for side, bucket in sides.items():
                    m_res = bucket.pop_5sec_stats(target_5sec)
                    if m_res:
                        mbp_max, mbp_min, mbp_avg, md_max, md_min, md_avg = m_res
                        
                        # 如果这 5 秒内统计出来的平均价差低于 -10 BP，说明不具备套利观测价值，丢弃，不入库
                        if mbp_avg < -20.0:
                            continue
                        
                        db_srv.write_queue.put({
                            "t_type": "TRE", "symbol": symbol, "ts": target_5sec * 1000,
                            "side": side, 
                            "bp_max": mbp_max, "bp_min": mbp_min, "bp_avg": mbp_avg,
                            "depth_max": md_max, "depth_min": md_min, "depth_avg": md_avg 
                        })
                        active_write_count += 1
            if active_write_count > 0:
                logging.info(f"💾 [聚合时钟] 周期 {target_5sec} 全量处理完毕，向 DB 队列批量推送了 {active_write_count} 条统计记录。")

# --- 5. 🚀 全量主运行控制入口 ---

async def main():
    # 先行初始化 CCXT 实例
    exchange = ccxt.bitget({
        'enableRateLimit': True,
        'options': {
            'ws': {
                'heartbeat': False,  # 彻底关闭 CCXT 默认心跳，由独立协程自主盲发
            },
            'watchTicker': {
                'channel': 'books1',  # 强绑定至官方 books1 极简流
            }
        }
    })
    logging.info("🔌 [System] CCXT 异步客户端基础参数配置成功。")

    # 1. 直接通过 CCXT 市场数据寻找完全兼容的交集套利币种
    valid_pairs = await discover_bitget_pairs_via_ccxt(exchange) 
    if not valid_pairs:
        logging.error("❌ 未动态扫描到可用的双向套利资产，全量运营中止。")
        await exchange.close()
        return
    
    # 2. 全量表结构初始化检查
    all_names = [p['name'] for p in valid_pairs]
    db_srv.sync_init_all_tables(all_names)
    
    # 3. 启动全量生产核心引擎阵列
    tasks = [
        asyncio.create_task(aggregator_engine()),
        asyncio.create_task(BitgetWSManager(valid_pairs, exchange).start())
    ]
    
    try:
        await asyncio.gather(*tasks)
    except Exception as main_e:
        logging.critical(f"🛑 生产主调度环致命崩溃: {main_e}", exc_info=True)
    finally:
        await exchange.close()

if __name__ == "__main__":
    asyncio.run(main())