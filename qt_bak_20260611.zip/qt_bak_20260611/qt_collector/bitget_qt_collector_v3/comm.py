# -*- coding: UTF-8 -*-
import streamlit as st  # <--- 必须添加，否则无法识别 @st.cache_resource
import pandas as pd
import pymysql
from sqlalchemy import create_engine, text
from datetime import datetime, timedelta
import ccxt

# --- 数据库配置（根据你的 fr_app_v1.py 提取） ---
DB_URI = "mysql+pymysql://FundingRate:sT36Hc2CwPbN8txY@localhost/fundingrate?charset=utf8mb4"
engine = create_engine(DB_URI, pool_recycle=3600)

@st.cache_resource
def get_exchange_client(plat='bybit'):
    """缓存交易所客户端对象，避免重复初始化"""
    clients = {
        'binance': ccxt.binance(),
        'bybit': ccxt.bybit(),
        'okx': ccxt.okx(),
        'bitget': ccxt.bitget()
    }
    return clients.get(plat, ccxt.bybit())

def get_symbol_realtime_metrics(coin, plat='bybit'):
    """
    功能 1: 查询价格指数、24h交易量、现有持仓(USDC)和资金费率
    """
    try:
        client = get_exchange_client(plat)
        symbol = f"{coin}/USDC:USDC" 
        
        ticker = client.fetch_ticker(symbol)
        last_price = ticker['last']
        volume_24h = ticker['quoteVolume'] 
        
        oi_data = client.fetch_open_interest(symbol)
        oi_value_usdc = (oi_data['openInterestAmount'] * last_price) if oi_data['openInterestAmount'] else 0
        
        funding_data = client.fetch_funding_rate(symbol)
        current_funding_rate = funding_data['fundingRate']
        
        return {
            "symbol": symbol,
            "price": last_price,
            "volume_24h_usdc": volume_24h,
            "oi_value_usdc": oi_value_usdc,
            "current_funding_rate": current_funding_rate,
            "status": "success"
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}

@st.cache_data(ttl=300) # 缓存5分钟，避免高频刷新数据库
def get_funding_arbitrage_stats(coin, plat='binance'):
    """
    严格按照 fr_app_v1.py 逻辑修正的利差计算
    """
    # 时间戳定义
    ts_2026_start = 1767225600 
    last_30d_start = int((datetime.now() - timedelta(days=30)).timestamp())

    # 查询包含 30天 和 2026年 范围内的数据
    query = f"""
        SELECT ct_type, value, fr_date, fr_timestamp 
        FROM `{plat}` 
        WHERE coin = :coin AND fr_timestamp >= :min_ts
    """
    
    try:
        with engine.connect() as conn:
            df = pd.read_sql(text(query), conn, params={
                "coin": coin, 
                "min_ts": min(ts_2026_start, last_30d_start)
            })
        
        if df.empty: return {"err": "No data"}

        # 数据预处理
        df['ct_type'] = df['ct_type'].str.lower()
        df['fr_date'] = pd.to_datetime(df['fr_date']).dt.date
        df['value'] = df['value'].astype(float)

        def calculate_apr_v2(target_df):
            """复刻原脚本的计算公式"""
            if target_df.empty: return 0
            # 原版逻辑：(总和 / 唯一天数) * 365
            total_value = target_df['value'].sum()
            unique_days = target_df['fr_date'].nunique()
            if unique_days == 0: return 0
            return (total_value / unique_days) * 365

        # --- 2026 年利差 ---
        df_26 = df[df['fr_timestamp'] >= ts_2026_start]
        u_26 = df_26[df_26['ct_type'].isin(['uc', 'usdc'])]
        t_26 = df_26[df_26['ct_type'].isin(['ut', 'usdt'])]
        apr_26_diff = calculate_apr_v2(u_26) - calculate_apr_v2(t_26)

        # --- 近 30 天利差 ---
        df_30 = df[df['fr_timestamp'] >= last_30d_start]
        u_30 = df_30[df_30['ct_type'].isin(['uc', 'usdc'])]
        t_30 = df_30[df_30['ct_type'].isin(['ut', 'usdt'])]
        apr_30_diff = calculate_apr_v2(u_30) - calculate_apr_v2(t_30)

        return {
            "apr_2026_diff": apr_26_diff,
            "apr_30d_diff": apr_30_diff
        }
    except Exception as e:
        return {"err": str(e)}