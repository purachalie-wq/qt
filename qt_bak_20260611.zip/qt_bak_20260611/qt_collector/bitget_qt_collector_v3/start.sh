#!/bin/bash
nohup python3 bitget_qt_collector.py > log/bitget_collector.log 2>&1 &
echo "🚀 采集器和API服务已在后台启动！"
