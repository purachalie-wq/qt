#!/bin/bash

# 定义要停止的脚本名称
COLLECTOR="bitget_qt_collector.py"

echo "停止服务中..."

# 查找并杀死进程
# grep -v grep 是为了排除掉 ps 命令本身的搜索进程
PID_COLLECTOR=$(ps -ef | grep "$COLLECTOR" | grep -v grep | awk '{print $2}')

if [ -n "$PID_COLLECTOR" ]; then
    kill $PID_COLLECTOR
    echo "✅ 已停止 $COLLECTOR (PID: $PID_COLLECTOR)"
else
    echo "ℹ️ $COLLECTOR 未在运行"
fi


echo "⏹ 所有服务已尝试关闭。"