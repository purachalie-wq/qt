#!/bin/bash

# --- 配置区 ---
APP_NAME="qt_ms_svc.py"
LOG_FILE="log/qt_ms_svc.log"
PYTHON_BIN="python3"

echo "-----------------------------------------------"
echo "正在检查 $APP_NAME 运行状态..."

# 1. 查找并杀掉旧进程
# 使用 pgrep -f 匹配完整的命令行，避免杀错
PIDS=$(pgrep -f $APP_NAME)

if [ -z "$PIDS" ]; then
    echo "未发现正在运行的进程。"
else
    echo "发现正在运行的 PID: $PIDS，准备强制中止..."
    echo $PIDS | xargs kill -9
    sleep 2
    echo "旧进程已清理。"
fi

# 2. 检查日志目录是否存在
if [ ! -d "log" ]; then
    mkdir log
fi

# 3. 启动新进程
echo "正在启动 $APP_NAME..."
# 使用 nohup 后台运行，并将输出重定向到日志文件
nohup $PYTHON_BIN $APP_NAME > /dev/null 2>&1 &

# 4. 确认是否启动成功
sleep 2
NEW_PID=$(pgrep -f $APP_NAME)

if [ -z "$NEW_PID" ]; then
    echo "❌ 启动失败！请检查代码是否有语法错误。"
else
    echo "✅ 启动成功！当前 PID: $NEW_PID"
    echo "正在进入实时日志追踪 (按 Ctrl+C 退出日志查看，不影响程序运行)..."
    echo "-----------------------------------------------"
fi
