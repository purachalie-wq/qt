# -*- coding: UTF-8 -*-
import logging
import sys
import os
import signal
from apscheduler.schedulers.blocking import BlockingScheduler
from sqlalchemy import text

# 导入数据库句柄和任务模块
from common.db_handler import qt_db, fr_db, bitget_db
# 修复：补全 task_bitget_market 的导入
from tasks import task_bybit_strategy, task_bybit_market, task_bybit_db_cleanup, task_bitget_strategy, task_bitget_market,task_bitget_db_cleanup

# 1. 配置日志
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("./log/monitor_service.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("qt_ms_svc")

ctx = {
    'qt_db': qt_db,
    'fr_db': fr_db,
    'bitget_db': bitget_db,
    'logger': logger
}

# --- 暴力退出机制 ---
def force_exit_handler(signum, frame):
    print("\n\n<<<< 收到强制退出指令 (Ctrl+C)，进程已立即终止 >>>>")
    os._exit(0)

signal.signal(signal.SIGINT, force_exit_handler)
signal.signal(signal.SIGTERM, force_exit_handler)

def startup_check(ctx):
    """
    全量启动自检：如果对应的结果表没有数据，则立即触发对应的计算/采集任务
    """
    qt_db = ctx['qt_db']
    fr_db = ctx['fr_db']
    bitget_db = ctx['bitget_db']
    logger.info("🚀 启动数据完整性自检...")
    
    try:
        # --- 检查任务 1: Bybit策略推荐数据 ---
        with qt_db.engine.connect() as conn:
            table_s = conn.execute(text("SHOW TABLES LIKE 'strategy_recommendations'")).scalar()
            if table_s:
                s_count = conn.execute(text("SELECT COUNT(*) FROM strategy_recommendations")).scalar()
                if s_count == 0:
                    logger.info("📊 [自检] strategy_recommendations 为空，触发 Bybit 策略扫描...")
                    task_bybit_strategy.run(ctx)
                else:
                    logger.info("Bybit策略数据ok")
            else:
                logger.warning("⚠️ 表 strategy_recommendations 缺失，跳过 Bybit 策略自检（请手动建表）")

        # --- 检查任务 2: Bybit行情快照数据 ---
        with qt_db.engine.connect() as conn:
            table_m = conn.execute(text("SHOW TABLES LIKE 'market_metrics'")).scalar()
            if table_m:
                m_count = conn.execute(text("SELECT COUNT(*) FROM market_metrics")).scalar()
                if m_count == 0:
                    logger.info("📊 [自检] market_metrics 为空，触发 Bybit 行情采集...")
                    task_bybit_market.run(ctx)
                else:
                    logger.info("Bybit行情快照数据ok")
            else:
                logger.warning("⚠️ 表 market_metrics 缺失，跳过 Bybit 行情自检（请手动建表）")

        # --- 检查任务 3: Bitget策略推荐数据 ---
        with bitget_db.engine.connect() as conn:
            table_t3 = conn.execute(text("SHOW TABLES LIKE 'strategy_recommendations'")).scalar()
            if table_t3:
                t3_count = conn.execute(text("SELECT COUNT(*) FROM strategy_recommendations")).scalar()
                if t3_count == 0:
                    logger.info("📊 [自检] bitget strategy_recommendations 为空，触发 Bitget 策略扫描...")
                    task_bitget_strategy.run(ctx)
                else:
                    logger.info("Bitget策略数据ok")
            else:
                logger.warning("⚠️ 表 strategy_recommendations 缺失，跳过 Bitget 策略自检（请手动建表）")

        # --- 检查任务 4: Bitget行情快照数据 (新增) ---
        with bitget_db.engine.connect() as conn:
            table_bm = conn.execute(text("SHOW TABLES LIKE 'market_metrics'")).scalar()
            if table_bm:
                bm_count = conn.execute(text("SELECT COUNT(*) FROM market_metrics")).scalar()
                if bm_count == 0:
                    logger.info("📊 [自检] bitget market_metrics 为空，触发 Bitget 行情采集...")
                    task_bitget_market.run(ctx)
                else:
                    logger.info("Bitget行情快照数据ok")
            else:
                logger.warning("⚠️ 表 market_metrics 缺失，跳过 Bitget 行情自检（请手动建表）")

        # --- 任务 5: 数据清理 ---
        # 清理任务不查行数，启动时直接跑一次确保数据库清理逻辑正常运行
        logger.info("🧪 [自检] 执行bybit数据库过期数据清理...")
        task_bybit_db_cleanup.run(ctx) # 修复：将 t4_qt_db_cleanup 改为 task_bybit_db_cleanup
        
        logger.info("🧪 [自检] 执行bitget数据库过期数据清理...")
        task_bitget_db_cleanup.run(ctx) # 修复：将 t4_qt_db_cleanup 改为 task_bybit_db_cleanup
        
        
        logger.info("✅ 启动自检流程结束。")
                
    except Exception as e:
        logger.error(f"❌ 自检过程中发生异常: {str(e)}", exc_info=True)

if __name__ == "__main__":
    startup_check(ctx)
    
    scheduler = BlockingScheduler()

    # bybit的任务
    scheduler.add_job(task_bybit_market.run, 'interval', minutes=30, args=[ctx], id='bybit_market_snapshot')
    scheduler.add_job(task_bybit_strategy.run, 'interval', minutes=60, args=[ctx], id='bybit_strategy_scan')
    scheduler.add_job(task_bybit_db_cleanup.run, 'cron', hour=1, minute=0, args=[ctx], id='bybit_data_cleanup') 
    
    #bitget的任务
    scheduler.add_job(task_bitget_market.run, 'interval', minutes=35, args=[ctx], id='bitget_market_snapshot') # 
    scheduler.add_job(task_bitget_strategy.run, 'interval', minutes=65, args=[ctx], id='bitget_strategy_scan')
    scheduler.add_job(task_bitget_db_cleanup.run, 'cron', hour=2, minute=0, args=[ctx], id='bitget_data_cleanup') 


    logger.info("=== 实时监控服务已进入调度模式，按 Ctrl+C 可立即停止 ===")
    
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        os._exit(0)  
