# -*- coding: UTF-8 -*-
import configparser
from sqlalchemy import create_engine

class DBManager:
    def __init__(self, section):
        config = configparser.ConfigParser()
        config.read('config.ini', encoding='utf-8')
        
        # 从指定 section 读取配置[cite: 3, 8]
        user = config.get(section, 'user')
        password = config.get(section, 'password')
        host = config.get(section, 'host')
        port = config.getint(section, 'port')
        dbname = config.get(section, 'database')
        
        db_url = f"mysql+pymysql://{user}:{password}@{host}:{port}/{dbname}?charset=utf8mb4"
        self.engine = create_engine(db_url, pool_recycle=3600)

# 实例化两个独立的数据库句柄[cite: 8, 9]
qt_db = DBManager('qt_db')           # Task 1, 2, 4 使用
fr_db = DBManager('fundingrate_db')  # Task 3.1, 3.2 使用
bitget_db = DBManager('bitget_db')  # Task 3.1, 3.2 使用