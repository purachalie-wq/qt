# -*- coding: UTF-8 -*-
import logging
import os

def setup_custom_logger(name):
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        
        # 输出到控制台
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        # 如果需要文件，可以取消下面注释
        # if not os.path.exists('logs'): os.makedirs('logs')
        # file_h = logging.FileHandler(f'logs/{name}.log')
        # file_h.setFormatter(formatter)
        # logger.addHandler(file_h)
        
    return logger