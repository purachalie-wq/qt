import pymysql
import time
from datetime import datetime, timedelta

REMOTE_DB = {
    'host': '43.163.193.63', 'port': 53817,
    'user': 'readonlyuser', 'password': '0CHFu+4L.7*a4AP0',
    'database': 'mydb', 'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}
LOCAL_DB = {
    'host': 'localhost', 'user': 'FundingRate',
    'password': 'sT36Hc2CwPbN8txY', 'database': 'fundingrate',
    'charset': 'utf8mb4', 'cursorclass': pymysql.cursors.DictCursor
}

def run(ctx):
    logger = ctx['logger']
    days = 2 # 每天自动执行时同步最近2天[cite: 4]
    logger.info(f"Task 3.1: 开始同步最近 {days} 天数据")
    
    r_conn = pymysql.connect(**REMOTE_DB)
    l_conn = pymysql.connect(**LOCAL_DB)
    try:
        platforms = ['binance', 'bybit', 'okx', 'bitget']
        with r_conn.cursor() as r_cur, l_conn.cursor() as l_cur:
            for plat in platforms:
                target_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
                where = f"WHERE plat = '{plat}' AND fr_date >= '{target_date}'"
                
                r_cur.execute(f"SELECT * FROM fr_data {where}")
                rows = r_cur.fetchall()
                if rows:
                    sql = f"REPLACE INTO `{plat}` (id, fr_ms_timestamp, fr_timestamp, fr_month, fr_date, plat, coin, symbol, value, ct_type, label) VALUES (%(id)s, %(fr_ms_timestamp)s, %(fr_timestamp)s, %(fr_month)s, %(fr_date)s, %(plat)s, %(coin)s, %(symbol)s, %(value)s, %(ct_type)s, %(label)s)"
                    l_cur.executemany(sql, rows)
                    l_conn.commit()
        logger.info("Task 3.1: 同步完成")
    finally:
        r_conn.close()
        l_conn.close()