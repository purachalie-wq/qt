# -*- coding: UTF-8 -*-
import time
from sqlalchemy import text
from pybit.unified_trading import HTTP

def run(ctx):
    logger = ctx['logger']
    db = ctx['qt_db'] 
    
    logger.info("🚀 [T2] 批量采集（USDC全量 + 联动USDT资金费率）开始...")
    start_time = time.perf_counter()
    
    try:
        session = HTTP(testnet=False)
        response = session.get_tickers(category="linear")
        tickers = response.get('result', {}).get('list', [])
        
        if not tickers:
            logger.warning("⚠️ [T2] 未获取到任何 Ticker 数据。")
            return

        # 用于存储最终合并数据的字典
        merged_data = {}
        now_ts = int(time.time() * 1000) 
        
        # ==========================================
        # 🔄 第一步：只采集 PERP (USDC) 基础数据
        # ==========================================
        for item in tickers:
            raw_symbol = item.get('symbol', '')
            if not raw_symbol:
                continue
            if raw_symbol.endswith('PERP'):
                clean_symbol = raw_symbol.replace('PERP', '')
                
                # 初始化并填充完整的 USDC 数据
                merged_data[clean_symbol] = {
                    'symbol': clean_symbol,
                    'price': float(item.get('lastPrice', 0) or 0),
                    'volume_24h_usdc': float(item.get('turnover24h', 0) or 0),
                    'oi_value_usdc': float(item.get('openInterestValue', 0) or 0),
                    'current_funding_rate': float(item.get('fundingRate', 0) or 0),
                    'usdt_funding_rate': 0.0, # 先赋默认值，等待第二步补充
                    'ts': now_ts
                }

        # 如果这一批数据里没有任何 PERP 币种，直接结束，不采集任何 USDT 合约
        if not merged_data:
            logger.warning("⚠️ [T2] 本批次未发现任何 PERP (USDC) 币种数据，放弃后续 USDT 采集。")
            return

        # ==========================================
        # 🔄 第二步：补充 USDT 合约的资金费率
        # ==========================================
        for item in tickers:
            raw_symbol = item.get('symbol', '')
            if raw_symbol.endswith('USDT'):
                clean_symbol = raw_symbol.replace('USDT', '')
                
                # 【核心拦截】只有第一步存在 PERP 数据时，才补充 USDT 费率
                if clean_symbol in merged_data:
                    merged_data[clean_symbol]['usdt_funding_rate'] = float(item.get('fundingRate', 0) or 0)

        # 转换为 SQLAlchemy 批量列表
        metrics_list = list(merged_data.values())

        if metrics_list:
            insert_sql = text("""
                INSERT INTO market_metrics 
                (symbol, price, volume_24h_usdc, oi_value_usdc, current_funding_rate, usdt_funding_rate, ts) 
                VALUES (:symbol, :price, :volume_24h_usdc, :oi_value_usdc, :current_funding_rate, :usdt_funding_rate, :ts)
            """)
            
            conn = db.engine.connect()
            try:
                logger.info(f"📦 [T2] 准备一次性批量 INSERT {len(metrics_list)} 条合并后的币种数据...")
                conn.execute(insert_sql, metrics_list)
                
                logger.info(f"⏳ [T2] 批量执行完毕，准备 COMMIT...")
                conn.commit()
                
                logger.info(f"✅ [T2] 批量实验成功！总耗时: {time.perf_counter() - start_time:.2f}s")
            except Exception as e:
                logger.error(f"❌ [T2] 批量实验失败: {str(e)}", exc_info=True)
            finally:
                conn.close()
        else:
            logger.warning("⚠️ [T2] 无符合条件数据。")

    except Exception as e:
        logger.error(f"❌ [T2] 崩溃: {str(e)}", exc_info=True)