# -*- coding: UTF-8 -*-
import pandas as pd
from sqlalchemy import text
import time

def run(ctx):
    logger = ctx['logger']
    db = ctx['bitget_db']
    
    logger.info("📢 [T3] 启动：开始执行 Bitget 全币种量化筛选计算...")
    start_total = time.perf_counter()
    ts_limit = int((time.time() - (24 * 3600)) * 1000)
    target_s = 30
    bp_range = range(-20, 101)

    try:
        with db.engine.connect() as conn:
            res_tables = conn.execute(text("SHOW TABLES LIKE 'arb_5s_TREND_%'")).fetchall()
            symbols = [r[0].replace('arb_5s_TREND_', '') for r in res_tables]
            logger.info(f"🔎 [T3] 找到 {len(symbols)} 个表，开始逐个计算...")
            
            recommendations = []

            for s in symbols:
                table_name = f"arb_5s_TREND_{s}"
                
                # 【兼容 5.7 的核心改动】：去掉 WITH 和 OVER，只用基础聚合 + 溢出桶
                query = text(f"""
                    SELECT side, 
                           LEAST(100, ROUND(bp_avg)) as bp, 
                           COUNT(*) as cnt, 
                           SUM(depth_avg) as sum_depth
                    FROM `{table_name}`
                    WHERE ts >= :ts AND bp_avg >= -20
                    GROUP BY side, LEAST(100, ROUND(bp_avg))
                """)
                
                # 拉取聚合后的少量数据到 Python
                df = pd.read_sql(query, conn, params={"ts": ts_limit})

                if df.empty:
                    continue

                c_sum = {1: {b: 0 for b in bp_range}, 2: {b: 0 for b in bp_range}}
                c_depth_sum = {1: {b: 0.0 for b in bp_range}, 2: {b: 0.0 for b in bp_range}}

                # 降序累加计算
                for side in [1, 2]:
                    side_df = df[df['side'] == side].set_index('bp')
                    accum_cnt, accum_depth = 0, 0.0
                    for b in sorted(bp_range, reverse=True):
                        accum_cnt += int(side_df.loc[b, 'cnt']) if b in side_df.index else 0
                        accum_depth += float(side_df.loc[b, 'sum_depth']) if b in side_df.index else 0.0
                        c_sum[side][b] = accum_cnt
                        c_depth_sum[side][b] = accum_depth

                best_a, min_diff = None, float('inf')
                
                # 寻找最优匹配
                for a in range(-10, target_s + 11):
                    b = target_s - a
                    if a not in c_sum[1] or b not in c_sum[2]:
                        continue
                    cnt1, cnt2 = c_sum[1][a], c_sum[2][b]
                    if cnt1 == 0 and cnt2 == 0:
                        continue
                    diff = abs(cnt1 - cnt2)
                    if diff < min_diff:
                        min_diff, best_a = diff, a
                    elif diff == min_diff and cnt1 > c_sum[1].get(best_a, -1):
                        best_a = a

                if best_a is not None:
                    fb = target_s - best_a
                    open_cnt = c_sum[1][best_a]
                    close_cnt = c_sum[2][fb]
                    recommendations.append({
                        "symbol": s,
                        "open_bp": best_a,
                        "close_bp": fb,
                        "open_cnt": open_cnt,
                        "close_cnt": close_cnt,
                        "open_avg_depth": round(c_depth_sum[1][best_a] / open_cnt, 4) if open_cnt > 0 else 0,
                        "close_avg_depth": round(c_depth_sum[2][fb] / close_cnt, 4) if close_cnt > 0 else 0,
                        "ts_created": int(time.time() * 1000)
                    })

            if recommendations:
                insert_sql = text("""
                    INSERT INTO strategy_recommendations 
                    (symbol, open_bp, close_bp, open_cnt, close_cnt, open_avg_depth, close_avg_depth, ts_created) 
                    VALUES (:symbol, :open_bp, :close_bp, :open_cnt, :close_cnt, :open_avg_depth, :close_avg_depth, :ts_created)
                """)
                conn.execute(insert_sql, recommendations)
                conn.commit()
                logger.info(f"✅ [T3] 计算完毕并成功入库！共 {len(recommendations)} 条数据。耗时 {time.perf_counter() - start_total:.2f}s")
            else:
                logger.warning("⚠️ [T3] 跑了一圈，没有符合条件的币种。")

    except Exception as e:
        logger.error(f"💥 [T3] 运行崩溃: {str(e)}", exc_info=True)
