# -*- coding: UTF-8 -*-
import pandas as pd
from sqlalchemy import text
import time

def run(ctx):
    logger = ctx['logger']
    db_fr = ctx['db_fr']
    
    # 保持与你前端完全一致的时间戳
    ts_map = {
        '2025': (1735689600, 1767225600), 
        '2026': (1767225600, 1798761600)
    }
    
    try:
        logger.info("开始执行 Task 3.2: 历史费率汇总（仅更新数据）...")
        start_exec = time.time()
        
        with db_fr.engine.connect() as conn:
            # 1. 获取币种列表
            t0 = time.time()
            # 增加对 coin 的排序，让日志输出更有序，方便你观察进度
            coins = pd.read_sql("SELECT DISTINCT coin FROM `bybit` ORDER BY coin", conn)['coin'].tolist()
            logger.info(f"获取到 {len(coins)} 个币种，查询耗时: {time.time()-t0:.2f}s")

            for i, coin in enumerate(coins):
                res_years = {}
                for yr, (start, end) in ts_map.items():
                    # 核心计算：总费率 / 唯一天数 * 365
                    sql = text(f"""
                        SELECT 
                            ct_type, 
                            SUM(CAST(value AS DECIMAL(20,8))) as total_val, 
                            COUNT(DISTINCT fr_date) as days 
                        FROM `bybit` 
                        WHERE coin = :coin AND fr_timestamp >= {start} AND fr_timestamp < {end} 
                        GROUP BY ct_type
                    """)
                    df = pd.read_sql(sql, conn, params={"coin": coin})
                    
                    apr_dict = {'uc': 0.0, 'ut': 0.0}
                    if not df.empty:
                        for _, r in df.iterrows():
                            t_raw = str(r['ct_type']).lower()
                            key = 'uc' if t_raw in ['uc', 'usdc'] else 'ut'
                            # APR 计算逻辑
                            apr_dict[key] = (float(r['total_val']) / r['days'] * 365) if r['days'] > 0 else 0
                    
                    res_years[f'diff_{yr}'] = abs(apr_dict['uc'] - apr_dict['ut'])

                # 2. Upsert 逻辑
                upsert_sql = text("""
                    INSERT INTO `funding_history_summary` (symbol, diff_2025, diff_2026)
                    VALUES (:symbol, :d25, :d26)
                    ON DUPLICATE KEY UPDATE 
                        diff_2025 = VALUES(diff_2025),
                        diff_2026 = VALUES(diff_2026)
                """)
                
                conn.execute(upsert_sql, {
                    "symbol": coin,
                    "d25": res_years['diff_2025'],
                    "d26": res_years['diff_2026']
                })
                
                # 每 20 个币种 commit 一次并输出详细耗时，方便你排查哪个币慢
                if (i + 1) % 20 == 0:
                    conn.commit()
                    logger.info(f"已更新进度: {i+1}/{len(coins)} | 当前币种: {coin}")

            conn.commit()
            logger.info(f"✅ Task 3.2: 更新完毕，总耗时: {time.time()-start_exec:.2f}s")

    except Exception as e:
        # 增加异常堆栈信息，防止报错时只看得到一个名字
        logger.error(f"Task 3.2 运行异常: {str(e)}", exc_info=True)