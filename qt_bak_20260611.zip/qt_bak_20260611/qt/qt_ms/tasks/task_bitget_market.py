# -*- coding: UTF-8 -*-
import time
import requests
from sqlalchemy import text

def run(ctx):
    logger = ctx['logger']
    db = ctx['bitget_db']
    
    logger.info("🚀 [T5-Bitget] 批量采集 USDC 本位合约实验开始...")
    start_time = time.perf_counter()
    
    try:
        # 核心修改1：请求 USDC 永续合约接口
        url = "https://api.bitget.com/api/v2/mix/market/tickers?productType=USDC-FUTURES"
        response = requests.get(url, timeout=10).json()
        
        # 检查接口响应
        if response.get('code') != '00000':
            logger.error(f"❌ [T5-Bitget] 接口报错: {response.get('msg')}")
            return
            
        tickers = response.get('data', [])
        
        if not tickers:
            return

        metrics_list = []
        now_ts = int(time.time() * 1000) 
        
        for item in tickers:
            # 核心修改2：去掉末尾的 USDC 后缀
            raw_symbol = item.get('symbol', '')
            if not raw_symbol:
                continue
            
            if raw_symbol.endswith('PERP'):
                clean_symbol = raw_symbol[:-4]  # 去掉 "USDC"
            else:
                clean_symbol = raw_symbol # 兜底兼容

            price = float(item.get('lastPr', 0) or 0)
            
            # 核心修改3：USDC本位的24h交易额，官方字段是 quoteVolume (计价货币即USDC的金额)
            vol_24h_usdc = float(item.get('quoteVolume', 0) or 0)
            
            # 核心修改4：持仓金额转换 (张数 * 价格)
            oi_usdc = 0.0
            holding_amount = float(item.get('holdingAmount', 0) or 0) # 持仓张数
            if holding_amount > 0 and price > 0:
                oi_usdc = holding_amount * price  # 按你的公式：张数 * 价格
                
            funding_rate = float(item.get('fundingRate', 0) or 0)
            
            metrics_list.append({
                'symbol': clean_symbol,
                'price': price,
                'volume_24h_usdc': vol_24h_usdc,
                'oi_value_usdc': oi_usdc,
                'current_funding_rate': funding_rate,
                'ts': now_ts  
            })

        if metrics_list:
            insert_sql = text("""
                INSERT INTO market_metrics 
                (symbol, price, volume_24h_usdc, oi_value_usdc, current_funding_rate, ts) 
                VALUES (:symbol, :price, :volume_24h_usdc, :oi_value_usdc, :current_funding_rate, :ts)
            """)
            
            with db.engine.connect() as conn:
                logger.info(f"📦 [T5-Bitget] 准备一次性批量 INSERT {len(metrics_list)} 条 USDC 本位数据...")
                conn.execute(insert_sql, metrics_list)
                conn.commit()
                
                logger.info(f"✅ [T5-Bitget] 批量实验成功！总耗时: {time.perf_counter() - start_time:.2f}s")
        else:
            logger.warning("⚠️ [T5-Bitget] 无符合条件数据。")

    except Exception as e:
        logger.error(f"❌ [T5-Bitget] 崩溃: {str(e)}", exc_info=True)
