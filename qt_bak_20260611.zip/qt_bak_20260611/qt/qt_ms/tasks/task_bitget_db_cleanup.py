# -*- coding: UTF-8 -*-
import time
import configparser
from sqlalchemy import text

def run(ctx):
    logger = ctx['logger']
    db = ctx['bitget_db'] # 核心改动：指向 bitget_db
    
    # 1. 获取配置，默认保留 7 天
    config = configparser.ConfigParser()
    config.read('config.ini', encoding='utf-8')
    days = config.getint('storage', 'retention_days', fallback=7)
    
    # 计算截止时间戳（毫秒，用于趋势表）和 时间字符串（用于快照表）
    now_ts = time.time()
    limit_ms = int((now_ts - days * 24 * 60 * 60) * 1000)
    limit_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(now_ts - days * 24 * 60 * 60))
    
    logger.info(f"🧹 [Bitget-Cleanup] 开始清理 Bitget 超过 {days} 天的历史数据...")

    try:
        with db.engine.connect() as conn:
            # --- 2. 清理 market_metrics 表 (Bitget 行情快照数据) ---
            logger.info("正在清理 Bitget market_metrics 过期快照...")
            metrics_deleted = 0
            while True:
                # 分批删除，每次 1000 条
                del_metrics = text("DELETE FROM market_metrics WHERE ts < :limit LIMIT 1000")
                res_m = conn.execute(del_metrics, {"limit": limit_ms})
                conn.commit()
                
                count = res_m.rowcount
                metrics_deleted += count
                if count < 1000:
                    break
                time.sleep(0.1)
            logger.info(f"Bitget market_metrics 清理完成，共删除 {metrics_deleted} 条记录。")

            # --- 3. 清理所有 5s_TREND 趋势表 (Bitget 策略原始数据) ---
            result = conn.execute(text("SHOW TABLES LIKE '%5s_TREND_%'"))
            tables = [row[0] for row in result]
            
            for table in tables:
                total_deleted = 0
                while True:
                    del_sql = text(f"DELETE FROM `{table}` WHERE ts < :limit LIMIT 1000")
                    res = conn.execute(del_sql, {"limit": limit_ms})
                    conn.commit()
                    
                    rows_affected = res.rowcount
                    total_deleted += rows_affected
                    if rows_affected < 1000:
                        break
                    time.sleep(0.1)
                
                if total_deleted > 0:
                    logger.info(f"Bitget 趋势表 {table} 清理完成，共删除 {total_deleted} 条记录。")
            
        logger.info("✅ [Bitget-Cleanup] Bitget 过期数据全量清理完毕。")
    except Exception as e:
        logger.error(f"❌ [Bitget-Cleanup] 清理过程中出错: {e}", exc_info=True)
