import asyncio
import ccxt.pro as ccxt
import os
import json
import time
from core import TradingCore
import db_manager
from config_loader import ConfigLoader
from exchange_handler import ExchangeHandler
from logger import logger  
from state_monitor import StateMonitor 
import sys

async def sync_core_positions(core, handler):
    """同步核心持仓状态"""
    try:
        pos_data = await handler.fetch_all_positions(core.usdt_symbol, core.usdc_symbol)
        usdt_size = pos_data['usdt_size']
        usdc_size = pos_data['usdc_size']

        # ✅ 新增：对冲一致性校验
        if abs(usdt_size) != abs(usdc_size):
            raise RuntimeError(
                f"{core.symbol} 对冲偏移！USDT={usdt_size}, USDC={usdc_size}"
            )

        core.update_position_status(usdt_size, usdc_size)
        logger.info(f"🔄 {core.symbol} 同步: UP={core.up_position}, DN={core.down_position}, max={core.get_open_more()}")
    except Exception as e:
        logger.error(f"❌ {core.symbol} 同步失败: {e}")
        raise  # ✅ 新增：向上抛出，阻止该币种启动

async def execute_trade_flow(core, handler, decision):
    """
    完整执行流：1.计算Ticks偏置 -> 2.执行USDC FOK -> 3.判定成交量 -> 4.USDT对冲
    """
    symbol_dc = core.usdc_symbol
    symbol_dt = core.usdt_symbol

    # 1. 计算 FOK 报单价 (保留你的 ticks 逻辑)
    # 买入 USDC 要往高处报单增加成交率，卖出 往低处报
    offset = core.slip_ticks * (core.tick_size or 0)
    target_price = (decision['exp_usdc'] + offset) if decision['side_dc'] == 'buy' else (decision['exp_usdc'] - offset)

    try:
        # 2. 第一步：执行 USDC FOK (核心端)
        usdc_order = await handler.place_fok_order(
            symbol_dc, 
            decision['side_dc'], 
            decision['amount'], 
            target_price, 
            decision['reduce']
        )

        # --- 核心判定：提取成交量 ---
        if not usdc_order:
            return False, 0
            
        filled_qty = float(usdc_order['filled'])
        logger.info(f"✅ {core.symbol} USDC端确认成交: {filled_qty}")

        # 第二步：执行 USDT 对冲
        try:
            usdt_order = await handler.place_market_order(
                symbol_dt,
                decision['side_dt'], 
                filled_qty, 
                decision['reduce']
            )
          
            # 封装成交快照
            fill_usdc = float(usdc_order.get('average') or usdc_order.get('price') or 0)
            fill_usdt = float(usdt_order.get('average') or usdt_order.get('price') or 0)
            trade_info = {'symbol': core.symbol, 'side': decision['tag'], 'amount': filled_qty,'fill_usdc': fill_usdc, 'fill_usdt': fill_usdt }
            db_manager.db.submit_trade(trade_info)
            
            return True, filled_qty
        except Exception as e:
            logger.error(f"🚨 严重异常！USDC已成交但USDT对冲失败: {e}")

            # 对USDC单进行回滚
            try:
                # 判定 USDC 回滚方向 (买变卖，卖变买)
                rollback_side = "sell" if "buy" in decision['side_dc'].lower() else "buy"
                # 💡 完美反转 reduceOnly 状态：如果原本是 reduce(True) 平仓，回滚就是开仓(False)；反之亦然
                rollback_reduce = False if decision['reduce'] else True
                # 反向操作，reduceOnly 状态也要反转
                rollback_order = await handler.place_market_order(
                    symbol_dc, 
                    rollback_side, 
                    filled_qty, 
                    reduce_only=rollback_reduce
                )
                if rollback_order and rollback_order.get('id'):
                    logger.info(f"🍏 [ROLLBACK DONE] {core.symbol} USDC端仓位已成功对等回滚平仓！")
            except Exception as rollback_error:
                logger.critical(f"💥 [FATAL] 极度危险：USDC端反向回滚单也失败了！现场已被卡死: {rollback_error}")

            sys.exit("🚨 策略由于对冲失败主动安全退出")

    except Exception as e:
        error_msg = str(e)
        # --- 自愈补丁：处理 110017 报错 ---
        if "110017" in error_msg:
            logger.warning(f"⚠️ {core.symbol} 仓位已在交易所清空，强制执行本地校准")
            # 返回 True 触发本地变量减去本次 decision 数量，直到归零
            return True, decision['amount']
        
        logger.error(f"🚨 下单逻辑执行异常: {error_msg}")
        sys.exit("🚨 策略由于下单逻辑异常主动安全退出")



async def monitor_single_coin(core, handler):
    # 1. 极简镜像
    cache = {"usdt": None, "usdc": None}
    is_finished = False
    
    # 2. 用 Event 门铃替代 Lock。Event 是无竞争的，天然免疫竞态条件
    bell = asyncio.Event()

    async def watch_ws(contract_symbol, key):
        nonlocal is_finished
        while not is_finished:
            try:
                ob = await core.exchange.watch_order_book(contract_symbol, 1)
                
                # ✅ 保留你的想法：如果在更新前发现已经达到上限，直接退出
                if core.current_loop >= core.max_loops:
                    if not is_finished:
                        logger.info(f"🚀 {core.symbol} 已达 max_loops")
                        is_finished = True
                        bell.set() # 临死前按一次门铃，防止消费者死等
                    break
                
                # 更新镜像
                cache[key] = ob
                
                # ✅ 升级你的想法：只有当两边都有数据时，才按门铃
                # 这完美解决了"单边断连5秒后重连，拿到另一边过期数据"的问题
                if cache["usdt"] and cache["usdc"]:
                    bell.set()
                    
            except asyncio.CancelledError:
                break # 优雅退出
            except Exception as e:
                logger.error(f"WS 异常 ({contract_symbol}): {e}")
                # ✅ 保留你的想法：异常时清空缓存
                cache[key] = None
                await asyncio.sleep(5)

    async def process_decision():
        nonlocal is_finished
        while not is_finished:
            try:
                # 3. 消费者死等门铃，不消耗 CPU
                await bell.wait()
                bell.clear() # 拔掉门铃
                
                # 二次检查风控
                if core.current_loop >= core.max_loops:
                    is_finished = True
                    break
                
                # ✅ 保留你的神来之笔：瞬间快照
                # 因为脱离了锁，直接拿引用是最快的，且由于我们只有1个消费者，不存在覆盖风险
                snap_usdt = cache["usdt"]
                snap_usdc = cache["usdc"]
                
                if not snap_usdt or not snap_usdc:
                    continue
                    
                decision = core.make_decision(snap_usdt, snap_usdc)
        
                if decision['triggered']:
                    logger.info(f"🎯 [SIGNAL] {core.symbol} 触发 {decision['tag']}")
                    
                    # 4. 执行交易（此时完全不会阻塞任何 WS 的接收）
                    is_success, filled_qty = await execute_trade_flow(core, handler, decision)
            
                    if is_success:
                        core.current_loop += 1
                        core.apply_trade_result(decision['tag'], filled_qty)
                        logger.info(f"✅ {core.symbol} 交易成功，当前 Loop: {core.current_loop}")
                        
            except Exception as e:
                logger.error(f"Decision 业务异常: {e}")
                await asyncio.sleep(0.5)

    # 5. 启动gather，加上 return_exceptions=True 防止一个挂了直接杀死另一个
    try:
        await asyncio.gather(
            watch_ws(core.usdt_symbol, "usdt"),
            watch_ws(core.usdc_symbol, "usdc"),
            process_decision(),
            return_exceptions=True # 即使 process_decision 报错，WS 也不会立刻断开，给你排查时间
        )
    finally:
        is_finished = True

async def main():
    # 1. 初始化配置加载器 (解析 config.ini 和 coins.json)
    loader = ConfigLoader().load_all()
    
    # 初始化数据库
    db_manager.db.set_config(loader.db)
    db_manager.db.init_db()
    
    # 3. 初始化交易所对象
    exchange = ccxt.bybit({
        "apiKey": loader.auth.api_key,
        "secret": loader.auth.secret_key,
        "enableRateLimit": True,
        "options": {"defaultType": "linear"} # 确保 Bybit 走线性合约路径
    })
    
    # 4. 实例化新的执行处理器 (这是之前漏掉的 handler)
    handler = ExchangeHandler(exchange)
    await handler.init_market_data()

    cores = []
    # 使用 loader.coins 而不是 config["coins"]
    for coin_cfg in loader.coins:
        try:
            core = TradingCore(**coin_cfg)

            core.check_params()
        
            core.exchange = exchange
        
            # 获取精度并同步给 core
            info = await handler.get_symbol_info(core.usdc_symbol)
            if info:
                core.tick_size = float(info['tick_size'])
        
            # 初始化同步持仓
            await sync_core_positions(core, handler)
            cores.append(core)
        except Exception as e:
            # 如果初始配置里的 deep/amount/bp 写的有问题，直接拦截并报错[cite: 6]
            logger.error(f"❌ {coin_cfg.get('symbol')} 配置非法，已跳过: {e}")
            continue

    if not cores:
        logger.error("🚫 没有有效的币种配置可运行，程序退出")
        await exchange.close()
        return

    # 启动监控任务
    monitor = StateMonitor(cores)

    # 5. 启动监控任务，注意要把 handler 传进去
    tasks = [asyncio.create_task(monitor_single_coin(core, handler)) for core in cores]
    tasks.append(asyncio.create_task(monitor.run())) # 添加状态监控任务
    tasks.append(asyncio.create_task(loader.start_hot_reload(cores)))
    try:
        await asyncio.gather(*tasks)
    except Exception as e:
        logger.error(f"🚨 主循环异常退出: {e}")
    finally:
        logger.info("⏳ 正在全力回收系统资源，准备安全断电...")
        try:
            if db_manager.db:
                # 检查 close 是否是异步方法，如果是则 await，否则直接同步调用
                if asyncio.iscoroutinefunction(db_manager.db.close):
                    await db_manager.db.close()
                else:
                    db_manager.db.close() # 👈 日志证明你的 db.close 是同步方法，去掉了 await 限制
                logger.info("💾 本地数据库已安全落盘并关闭")
        except Exception as db_err:
            logger.error(f"⚠️ 关闭数据库时发生异常: {db_err}")

        # 2. 确保交易所连接必然会被执行关闭
        try:
            if exchange:
                await exchange.close()
                logger.info("🔌 Bybit 交易所连接及 WebSocket 订阅已安全注销")
        except Exception as ex_err:
            logger.error(f"⚠️ 关闭交易所连接时发生异常: {ex_err}")
            
        logger.info("🏁 策略运行环境已彻底洗场，进程安全退出。")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass