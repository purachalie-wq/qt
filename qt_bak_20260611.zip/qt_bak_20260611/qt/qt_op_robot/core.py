from types import SimpleNamespace
import ccxt.pro as ccxt
import asyncio
from logger import logger
from typing import Tuple, Optional, Dict, List
import json
import time

class TradingCore:
    """交易核心逻辑管理 - 已适配嵌套配置格式"""
    def __init__(self, **kwargs):
        self.symbol = kwargs.get('symbol', '').upper()
        self.confirm_duration = kwargs.get('confirm_ms', 100) / 1000.0
        self.max_loops = kwargs.get("max_loops")
        self.max_position = kwargs.get('max_position', 0)
        self.slip_ticks = kwargs.get('slip_ticks', 0)
        self.up = self._dict_to_obj(kwargs.get('up'))
        self.down = self._dict_to_obj(kwargs.get('down'))
        self.current_loop = 0  # 状态归位：记录当前已循环次数
        
        self.tick_size = None
        self.up_position = 0.0
        self.down_position = 0.0
        self.signal_timers = {"up_open": None, "up_close": None, "down_open": None, "down_close": None}
        
        #self.can_open_more = True
        self.sample_count = 0
        self.exchange = None
        
        
        self.usdt_symbol = f"{self.symbol}USDT"
        self.usdc_symbol = f"{self.symbol}PERP"
        

    def _dict_to_obj(self, d):
        if isinstance(d, dict):
            return SimpleNamespace(**{k: self._dict_to_obj(v) for k, v in d.items()})
        return d

    def get_open_more(self):
       
        # 1. 0 或负数代表禁止开仓
        if self.max_position <= 0:
            return False
        current_max = max(self.up_position, self.down_position)
        return  current_max < self.max_position
        

    def update_position_status(self, usdt_raw, usdc_raw):
        """
        根据原始仓位解析逻辑方向：
        USDC 负数 -> 代表做了 USDC Sell / USDT Buy -> 归为 up_position
        USDC 正数 -> 代表做了 USDC Buy / USDT Sell -> 归为 down_position
        """
        self.up_position = abs(usdc_raw) if usdc_raw < 0 else 0.0
        self.down_position = abs(usdc_raw) if usdc_raw > 0 else 0.0
        

    def apply_trade_result(self, tag, amount):
        """
        核心修正：直接根据成交的 Tag 和 数量，原地更新本地仓位数值。
        UP_OPEN: USDC Sell / USDT Buy  -> up_position 增加
        UP_CLOSE: USDC Buy / USDT Sell -> up_position 减少
        DN_OPEN: USDC Buy / USDT Sell  -> down_position 增加
        DN_CLOSE: USDC Sell / USDT Buy -> down_position 减少
        """
        if tag == "UP_OPEN":
            self.up_position += amount
        elif tag == "UP_CLOSE":
            self.up_position = max(0, self.up_position - amount)
        elif tag == "DOWN_OPEN":
            self.down_position += amount
        elif tag == "DOWN_CLOSE":
            self.down_position = max(0, self.down_position - amount)

        
        logger.info(f"✅ [本地更新] {tag} 完成 | 数量: {amount} | 当前仓位(U/D): {self.up_position}/{self.down_position}")
        
        
    def make_decision(self, usdt_ob: dict, usdc_ob: dict) -> dict:
        # 1. 提取四端价格与深度
        u_ask, u_ask_q = float(usdt_ob["asks"][0][0]), float(usdt_ob["asks"][0][1])
        u_bid, u_bid_q = float(usdt_ob["bids"][0][0]), float(usdt_ob["bids"][0][1])
        c_ask, c_ask_q = float(usdc_ob["asks"][0][0]), float(usdc_ob["asks"][0][1])
        c_bid, c_bid_q = float(usdc_ob["bids"][0][0]), float(usdc_ob["bids"][0][1])

        decision = {"triggered": False, "tag": None, "side_dt": None, "side_dc": None, 
                    "reduce": False, "amount": 0.0, "exp_usdc": 0.0, "exp_usdt": 0.0}

        # --- 第一阶段：平仓优先 (无论 can_open_more 是什么，平仓必须先查) ---
        
        # 检查 UP 平仓
        if self.up_position > 0:
            if self._check_signal_with_timer("up_close", u_bid, c_ask, u_bid_q, c_ask_q, self.up.close, self.up.close.deep):
                decision.update({
                    "triggered": True, "tag": "UP_CLOSE", "side_dt": "sell", "side_dc": "buy",
                    "reduce": True, "amount": min(self.up.amount, abs(self.up_position)),
                    "exp_usdc": c_ask, "exp_usdt": u_bid
                })

        # 检查 DOWN 平仓 (即使上面没触发，也要看这里)
        if not decision["triggered"] and self.down_position > 0:
            if self._check_signal_with_timer("down_close", u_ask, c_bid, u_ask_q, c_bid_q, self.down.close, self.down.close.deep):
                decision.update({
                    "triggered": True, "tag": "DOWN_CLOSE", "side_dt": "buy", "side_dc": "sell",
                    "reduce": True, "amount": min(self.down.amount, abs(self.down_position)),
                    "exp_usdc": c_bid, "exp_usdt": u_ask
                })

        # --- 第二阶段：开仓判定 (只有在没平仓需求且允许开仓时才进入) ---
        if not decision["triggered"] and self.get_open_more():
            
            # 检查 UP 开仓
            if self.down_position  <= 0:
                if self._check_signal_with_timer("up_open", u_ask, c_bid, u_ask_q, c_bid_q, self.up.open, self.up.open.deep):
                    decision.update({
                        "triggered": True, "tag": "UP_OPEN", "side_dt": "buy", "side_dc": "sell",
                        "reduce": False, "amount": self.up.amount,
                        "exp_usdc": c_bid, "exp_usdt": u_ask
                    })

            # 检查 DOWN 开仓
            if not decision["triggered"] and self.up_position <= 0:
                if self._check_signal_with_timer("down_open", u_bid, c_ask, u_bid_q, c_ask_q, self.down.open, self.down.open.deep):
                    decision.update({
                        "triggered": True, "tag": "DOWN_OPEN", "side_dt": "sell", "side_dc": "buy",
                        "reduce": False, "amount": self.down.amount,
                        "exp_usdc": c_ask, "exp_usdt": u_bid
                    })

        # 只有在决策完成后才调用采样日志
        self.log_status(u_ask, u_bid, c_ask, c_bid, u_ask_q, u_bid_q, c_ask_q, c_bid_q, force=decision["triggered"])

        return decision


    def _check_signal_with_timer(self, key, p_usdt, p_usdc, q_usdt, q_usdc, cfg, deep) -> bool:
        """带时间去噪和深度校验的信号检查"""
        # 1. 基础深度校验 (必须大于交易量的 N 倍)
        if q_usdc < deep:
            self.signal_timers[key] = None
            return False

        # 2. 计算实时 BP
        # 卖出 USDC 端的逻辑 (UP_OPEN, DOWN_CLOSE)
        if "sell" in key or "up_open" in key or "down_close" in key:
            current_bp = ((p_usdc - p_usdt) / p_usdt) * 10000
        else: # 买入 USDC 端的逻辑 (UP_CLOSE, DOWN_OPEN)
            current_bp = ((p_usdt - p_usdc) / p_usdc) * 10000

        # 3. 阈值判定
        if current_bp < cfg.bp:
            self.signal_timers[key] = None
            return False

        # 4. 时间去噪 (Confirm Duration)
        if self.signal_timers[key] is None:
            self.signal_timers[key] = time.time()
            return False
        
        elapsed = time.time() - self.signal_timers[key]
        if elapsed >= self.confirm_duration:
            return True
        
        return False
        
    def log_status(self, u_ask, u_bid, c_ask, c_bid, u_ask_q, u_bid_q, c_ask_q, c_bid_q, force=False):
        self.sample_count += 1
        if not (self.sample_count >= 100 or force):
            return
        self.sample_count = 0
        curr_up_open = ((c_bid - u_ask) / u_ask) * 10000
        curr_dn_open = ((u_bid - c_ask) / c_ask) * 10000
        tag = "🚀" if force else ""
        logger.info(f"{tag}{self.symbol} | UP:{self.up_position:.1f} DN:{self.down_position:.1f} | BP: UP:{curr_up_open:+.1f} DN:{curr_dn_open:+.1f} | DT:{u_bid_q:.0f}/{u_ask_q:.0f} DC:{c_bid_q:.0f}/{c_ask_q:.0f}")

    def check_params(self, cfg: dict = None) -> None:
        """
        参数校验逻辑：涵盖 BP、交易量、仓位以及深度校验[cite: 6]
        """
        if cfg:
            # 提取新配置 (使用 .get 安全取值)[cite: 8]
            t_u_o_bp = cfg.get('up', {}).get('open', {}).get('bp')
            t_u_c_bp = cfg.get('up', {}).get('close', {}).get('bp')
            t_d_o_bp = cfg.get('down', {}).get('open', {}).get('bp')
            t_d_c_bp = cfg.get('down', {}).get('close', {}).get('bp')
            t_u_o_dp = cfg.get('up', {}).get('open', {}).get('deep')
            t_u_c_dp = cfg.get('up', {}).get('close', {}).get('deep')
            t_d_o_dp = cfg.get('down', {}).get('open', {}).get('deep')
            t_d_c_dp = cfg.get('down', {}).get('close', {}).get('deep')
            t_up_amt = cfg.get('up', {}).get('amount')
            t_dn_amt = cfg.get('down', {}).get('amount')
            t_max_pos = cfg.get('max_position')
        else:
            # 校验当前属性[cite: 6]
            t_u_o_bp, t_u_c_bp = self.up.open.bp, self.up.close.bp
            t_d_o_bp, t_d_c_bp = self.down.open.bp, self.down.close.bp
            t_u_o_dp, t_u_c_dp = self.up.open.deep, self.up.close.deep
            t_d_o_dp, t_d_c_dp = self.down.open.deep, self.down.close.deep
            t_up_amt, t_dn_amt = self.up.amount, self.down.amount
            t_max_pos = self.max_position

        # 规则1: BP 范围校验[cite: 6]
        for val, label in [(t_u_o_bp, "UP开仓"), (t_u_c_bp, "UP平仓"), (t_d_o_bp, "DN开仓"), (t_d_c_bp, "DN平仓")]:
            if val is not None and not (-100 < val < 1000):
                raise ValueError(f"{self.symbol} {label} BP 异常: {val}")

        # 规则2: 深度校验 (Deep 必须 > 0 且 >= Amount)[cite: 1, 6]
        dp_map = [(t_u_o_dp, "UP开仓", t_up_amt), (t_u_c_dp, "UP平仓", t_up_amt), (t_d_o_dp, "DN开仓", t_dn_amt), (t_d_c_dp, "DN平仓", t_dn_amt)]
        for dp_val, label, amt in dp_map:
            if dp_val is not None:
                if dp_val <= 0: raise ValueError(f"{self.symbol} {label} 深度必须大于0")
                if amt is not None and dp_val < amt: raise ValueError(f"{self.symbol} {label} 深度({dp_val})不能小于交易量({amt})")

        # 规则3: 交易量与仓位[cite: 6]
        if (t_up_amt is not None and t_up_amt <= 0) or (t_dn_amt is not None and t_dn_amt <= 0):
            raise ValueError(f"{self.symbol} 交易数量必须大于0")
        if t_max_pos is not None and t_max_pos < 0:
            raise ValueError(f"{self.symbol} 最大仓位不能为负数")