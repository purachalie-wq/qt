from logger import logger
import asyncio
import ccxt

class ExchangeHandler:
    def __init__(self, exchange):
        self.ex = exchange
        self.markets = {}

    async def init_market_data(self):
        """初始化加载市场信息，确保精度可用"""
        try:
            self.markets = await self.ex.load_markets()
            logger.info("✅ 市场信息加载完成")
        except Exception as e:
            logger.error(f"❌ 加载市场信息失败: {e}")
    
    async def get_symbol_info(self, symbol):
        """获取指定币种的精度和限制"""
        if not self.markets: await self.init_market_data()
        m = self.markets.get(symbol)
        if not m: return None
        return {
            "tick_size": m['precision']['price'],
            "step_size": m['precision']['amount'],
            "min_notional": m['limits']['cost']['min']
        }

    async def fetch_all_positions(self, usdt_symbol: str, usdc_symbol: str):
        """
        通过 settleCoin 分别查询 USDT 和 USDC 结算的仓位
        返回格式: { 'usdt_size': 12.3, 'usdc_size': 12.3 }
        """
        res = {'usdt_size': 0.0, 'usdc_size': 0.0}
        
        # 1. 查询 USDT 结算仓位
        try:
            p_usdt = await self.ex.fetch_positions(None, {'category': 'linear', 'settleCoin': 'USDT'})
            for p in p_usdt:
                info = p.get('info', {})
                if info.get('symbol') == usdt_symbol:
                    # Bybit V5 size 始终为正，靠 side 区分
                    size = float(info.get('size', 0))
                    res['usdt_size'] = size if info.get('side') == 'Buy' else -size
        except Exception as e:
            logger.error(f"❌ Bybit USDT 仓位同步失败: {e}")

        # 2. 查询 USDC 结算仓位
        try:
            p_usdc = await self.ex.fetch_positions(None, {'category': 'linear', 'settleCoin': 'USDC'})
            for p in p_usdc:
                info = p.get('info', {})
                if info.get('symbol') == usdc_symbol:
                    size = float(info.get('size', 0))
                    res['usdc_size'] = size if info.get('side') == 'Buy' else -size
        except Exception as e:
            logger.error(f"❌ Bybit USDC 仓位同步失败: {e}")

        return res

    async def place_fok_order(self, symbol, side, amount, price, reduce_only):
        try:
            params = {'timeInForce': 'FOK', 'reduceOnly': reduce_only, 'category': 'linear'}
            
            # 1. 发送下单请求（此时返回的只是 ACK 确认，可能没有 filled 等真实状态）
            order = await self.ex.create_order(symbol, 'limit', side, amount, price, params)
        
            if not order or not order.get('id'):
                logger.warning(f"⚠️ FOK 下单返回为空或无订单ID")
                return None
            
            order_id = order.get('id')
            logger.info(f"📨 FOK 已提交 ACK, 订单号: {order_id}, 正在查询真实状态...")
            
            real_order = None
            for attempt in range(4):
                # 2. 使用 fetch_order 强制拉取真实结果（关键修复：acknowledged=True）
                try:
                    real_order = await asyncio.wait_for(
                        self.ex.fetch_order(
                            order_id, 
                            symbol, 
                            params={"acknowledged": True, "category": "linear"}
                        ),
                        timeout=1
                    )
                    break
                except ccxt.OrderNotFound:
                    if attempt < 3: 
                        await asyncio.sleep(0.04)
                    else:
                        logger.warning(f"⚠️ FOK 订单多次查询不存在，判定已被系统自动 Kill: {order_id}")
                        return None
                except asyncio.TimeoutError:
                    logger.error(f"⏰ 查询订单状态超时: {order_id}")
                    return None
            
            
            if not real_order:
                logger.warning(f"⚠️ FOK 查询订单状态返回为空")
                return None
                
            logger.info(f"📋 查询到真实状态: status={real_order.get('status')}, filled={real_order.get('filled')}")
            
            # 3. 判定是否真实成交
            if real_order.get('status') in ['closed', 'filled']:
                return real_order
            else:
                logger.warning(f"⚠️ FOK 状态非成交: {real_order.get('status')}")
                return None
                
        except Exception as e:
            if "110017" in str(e):
                raise e
            logger.error(f"❌ FOK 下单/查询异常 [{symbol}]: {e}")
            return None


    async def place_market_order(self, symbol, side, amount, reduce_only):
        """执行市价对冲单"""
        try:
            params = {'reduceOnly': reduce_only, 'category': 'linear'}
            return await self.ex.create_order(symbol, 'market', side, amount, None, params)
        except Exception as e:
            logger.error(f"❌ Market 下单异常 [{symbol}]: {e}")
            return None