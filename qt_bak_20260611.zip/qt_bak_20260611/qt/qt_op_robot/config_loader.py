import json
import configparser
from types import SimpleNamespace
from logger import logger
import os
import asyncio

class ConfigLoader:
    def __init__(self):
        self.auth = None
        self.db = None
        self.coins = []
        self._json_path = "coins.json"
        self._last_mtime = 0

    def load_all(self, ini_path="config.ini", json_path="coins.json"):
        self._json_path = json_path
        # 1. 加载 config.ini
        try:
            config = configparser.ConfigParser()
            config.read(ini_path, encoding='utf-8')
            
            self.auth = SimpleNamespace(
                api_key=config.get('auth', 'api_key'),
                secret_key=config.get('auth', 'secret_key')
            )
            
            self.db = {
                "host": config.get('database', 'host'),
                "port": config.getint('database', 'port'),
                "user": config.get('database', 'user'),
                "password": config.get('database', 'password'),
                "database": config.get('database', 'database'),
                "charset": "utf8mb4"
            }
        except Exception as e:
            logger.error(f"❌ 加载 config.ini 失败: {e}")
            raise

        # 2. 加载 coins.json
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                self.coins = json.load(f)
        except Exception as e:
            logger.error(f"❌ 加载 coins.json 失败: {e}")
            raise
            
        logger.info(f"✅ 配置加载成功: 已加载 {len(self.coins)} 个币种策略")
        self._last_mtime = os.path.getmtime(self._json_path)
        return self

    async def start_hot_reload(self, cores):
        """
        对外暴露的热更新接口。传入运行中的 cores 实例列表即可。
        """
        logger.info(f"🔥 [ConfigLoader] 配置热更监听已启动 (文件: {self._json_path})")
        while True:
            await asyncio.sleep(5) # 低频轮询，无性能损耗
            try:
                current_mtime = os.path.getmtime(self._json_path)
                if current_mtime <= self._last_mtime:
                    continue
                
                # 1. 重新读取文件
                with open(self._json_path, "r", encoding="utf-8") as f:
                    new_configs = json.load(f)
                cfg_map = {c['symbol'].upper(): c for c in new_configs}
                
                # 2. 遍历实例进行安全同步
                for core in cores:

                    new_cfg = cfg_map.get(core.symbol)
                    if not new_cfg:
                        continue

                    # --- 核心修改：原子化校验点 ---
                    try:
                        # 1. 假设 check_params 已在 TradingCore 类中定义
                        # 2. 传入从文件读取的字典进行预校验
                        core.check_params(new_cfg) 
                        
                        # 3. 校验通过后，才同步到内存[cite: 8]
                        self._sync_core_fields(core, new_cfg)
                    except Exception as e:
                        # 拦截非法配置，旧参数继续运行，系统不崩溃
                        logger.error(f"⚠️ {core.symbol} 热更新拦截：参数不合法。原因: {e}")
                        continue
                
                self._last_mtime = current_mtime
                logger.info("✅ [ConfigLoader] 内存配置热更新完成")
                
            except Exception as e:
                logger.error(f"❌ [ConfigLoader] 热更新异常: {e}")

    def _sync_core_fields(self, core, new_cfg):
        """内部方法：按白名单安全浅更新 core 属性"""
        
        # 1. 特殊字段：confirm_ms 需要转换单位
        old_ms = int(core.confirm_duration * 1000)
        new_ms = new_cfg.get('confirm_ms', old_ms)
        if old_ms != new_ms:
            logger.info(f"🔄 {core.symbol} confirm_ms: {old_ms} -> {new_ms}")
            core.confirm_duration = new_ms / 1000.0

        # 2. 一级普通字段
        for field in ['max_loops', 'max_position', 'slip_ticks']:
            old_val = getattr(core, field)
            new_val = new_cfg.get(field, old_val)
            if old_val != new_val:
                logger.info(f"🔄 {core.symbol} {field}: {old_val} -> {new_val}")
                setattr(core, field, new_val)

        # 3. 二级嵌套字段
        for direction in ['up', 'down']:
            dir_obj = getattr(core, direction)
            dir_cfg = new_cfg.get(direction, {})
            
            if 'amount' in dir_cfg and dir_obj.amount != dir_cfg['amount']:
                logger.info(f"🔄 {core.symbol} {direction}.amount: {dir_obj.amount} -> {dir_cfg['amount']}")
                dir_obj.amount = dir_cfg['amount']
                
            # 4. 三级嵌套字段
            for action in ['open', 'close']:
                action_obj = getattr(dir_obj, action)
                action_cfg = dir_cfg.get(action, {})
                
                for param in ['bp', 'deep']:
                    if param in action_cfg:
                        old_val = getattr(action_obj, param)
                        new_val = action_cfg[param]
                        if old_val != new_val:
                            logger.info(f"🔄 {core.symbol} {direction}.{action}.{param}: {old_val} -> {new_val}")
                            setattr(action_obj, param, new_val)

    