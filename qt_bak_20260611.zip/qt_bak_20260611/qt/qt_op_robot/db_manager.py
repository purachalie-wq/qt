# -*- coding: UTF-8 -*-
import pymysql
from dbutils.pooled_db import PooledDB
import threading
import time
from logger import logger

class DBManager:
    def __init__(self):
        self.pool = None
        self.config = {}
        # 核心缓冲区：存放待写入的成交数据
        self.buffer = []
        self._lock = threading.Lock()
        self._worker_thread = None
        self._running = False

    def set_config(self, config):
        """同步配置信息"""
        self.config = {
            'host': config['host'],
            'port': config['port'],
            'user': config['user'],
            'password': config['password'],
            'database': config['database'],
            'charset': 'utf8mb4',
            'autocommit': True
        }

    def init_db(self):
        """初始化同步连接池并启动后台轮询线程"""
        if not self.pool:
            try:
                # 使用你要求的 PooledDB
                self.pool = PooledDB(
                    creator=pymysql,
                    maxconnections=10,
                    mincached=2,
                    blocking=True,
                    **self.config
                )
                logger.info("✅ [DB] 同步连接池已建立 (PooledDB)")
                
                # 执行建表检查 (同步方式)
                self._check_and_create_tables()
                
                # 启动定时轮询线程
                self._running = True
                self._worker_thread = threading.Thread(target=self._timer_worker, daemon=True)
                self._worker_thread.start()
                logger.info("🏗️ [DB] 定时入库线程已启动 (0.1s 频率)")
            except Exception as e:
                logger.error(f"❌ [DB] 初始化数据库失败: {e}")
                raise

    def _check_and_create_tables(self):
        """同步创建业务表"""
        conn = self.pool.connection()
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS order_fills (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    symbol VARCHAR(20),
                    side VARCHAR(20),
                    trade_amount DOUBLE,
                    fill_usdc_price DOUBLE,
                    fill_usdt_price DOUBLE,
                    created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
                    INDEX idx_symbol (symbol)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS arb_stats (
                    symbol VARCHAR(20) PRIMARY KEY,
                    total_trades INT DEFAULT 0,
                    last_update DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
        conn.close()

    def submit_trade(self, data):
        """生产者：将数据放入缓冲区 (线程安全)"""
        with self._lock:
            self.buffer.append(data)

    def _timer_worker(self):
        """后台死循环：每 0.1 秒检查并写入一次[cite: 7]"""
        while self._running:
            start_time = time.time()
            self._flush_buffer()
            
            # 计算剩余休眠时间，确保约 0.1 秒频率
            elapsed = time.time() - start_time
            sleep_time = max(0.01, 0.1 - elapsed)
            time.sleep(sleep_time)

    def _flush_buffer(self):
        """执行批量写入逻辑"""
        batch_data = []
        with self._lock:
            if not self.buffer:
                return
            batch_data = self.buffer[:]
            self.buffer.clear()

        conn = None
        try:
            conn = self.pool.connection()
            with conn.cursor() as cur:
                for data in batch_data:
                    # 1. 插入成交明细
                    cur.execute(
                        "INSERT INTO order_fills (symbol, side, trade_amount, fill_usdc_price, fill_usdt_price) VALUES (%s, %s, %s, %s, %s)",
                        (data['symbol'], data['side'], data['amount'], data['fill_usdc'], data['fill_usdt'])
                    )
                    # 2. 更新汇总统计
                    cur.execute(
                        "INSERT INTO arb_stats (symbol, total_trades) VALUES (%s, 1) ON DUPLICATE KEY UPDATE total_trades = total_trades + 1",
                        (data['symbol'],)
                    )
            conn.commit()
        except Exception as e:
            logger.error(f"❌ [DB] 批量入库异常: {e}")
            # 如果写入失败，把数据塞回缓冲区顶部重新尝试
            with self._lock:
                self.buffer = batch_data + self.buffer
        finally:
            if conn:
                conn.close()

    def close(self):
        """退出前最后一次强制刷盘"""
        self._running = False
        logger.info("⏳ [DB] 正在执行最后一次刷盘...")
        self._flush_buffer()
        if self.pool:
            self.pool.close()
        logger.info("🔌 [DB] 同步连接池已安全关闭")

# 全局单例
db = DBManager()