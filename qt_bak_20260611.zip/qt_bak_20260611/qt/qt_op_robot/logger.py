import os
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime

def setup_custom_logger(name="trading"):
    """
    配置全局唯一的日志处理器
    """
    if not os.path.exists('log'):
        os.makedirs('log')

    # 生成带启动时间的文件名
    start_time_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f'log/trading_{start_time_str}.log'

    # 创建格式化器
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - [%(name)s] - %(message)s')

    # 创建 100MB 切分处理器
    # maxBytes = 100 * 1024 * 1024 (100MB)
    file_handler = RotatingFileHandler(
        log_filename, 
        maxBytes=104857600, 
        backupCount=20, 
        encoding='utf-8'
    )
    file_handler.setFormatter(formatter)

    # 获取根日志记录器
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    # 避免重复添加 Handler（防止在某些环境下日志翻倍打印）
    if not logger.handlers:
        logger.addHandler(file_handler)
        
    return logger

# 预初始化一个单例 logger
logger = setup_custom_logger()