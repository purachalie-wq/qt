import json
import aiofiles # 建议 pip install aiofiles
import asyncio
import logging
import time # 必须导入，否则 time.strftime 报错

class StateMonitor:
    def __init__(self, cores):
        self.cores = cores
        self.state_file = "state.json"

    async def run(self):
        """定时 5 秒更新一次状态"""
        while True:
            try:
                state_data = {}
                for core in self.cores:
                    # 从 core 实例和其闭包逻辑中提取关键数据
                    state_data[core.symbol] = {
                        "loop_status": f"{getattr(core, 'current_loop', 0)}/{core.max_loops}",
                        "position": {
                            "up": core.up_position,
                            "down": core.down_position,
                            "max_allowed": core.max_position
                        },
                        "update_time": time.strftime("%Y-%m-%d %H:%M:%S")
                    }
                
                # 异步写入，不阻塞交易主流程
                async with aiofiles.open(self.state_file, mode='w', encoding='utf-8') as f:
                    await f.write(json.dumps(state_data, indent=4, ensure_ascii=False))
                    
            except Exception as e:
                logging.error(f"❌ 状态更新失败: {e}")
            
            await asyncio.sleep(5)