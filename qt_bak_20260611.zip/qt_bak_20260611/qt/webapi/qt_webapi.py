from flask import Flask , request
import os
import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
import yaml
import json
import subprocess

app = Flask(__name__)
KEY = ""

def generate_aes_key() -> str:
    """生成一个 128 位的随机对称密钥（Base64 编码）"""
    return base64.b64encode(os.urandom(16)).decode('utf-8')

def encrypt_string_aes(plaintext: str, key: str) -> str:
    """
    使用 AES-128-CBC 加密字符串。

    :param plaintext: 要加密的明文字符串
    :param key:       Base64 编码的 16 字节密钥
    :return:          Base64 编码的密文字符串（格式: iv + ciphertext）
    """
    # 解码密钥
    key_bytes = base64.b64decode(key.encode('utf-8'))

    # 生成 128 位随机 IV（初始化向量）
    iv = os.urandom(16)

    # 执行 AES-CBC 加密
    cipher = Cipher(algorithms.AES(key_bytes), modes.CBC(iv))
    encryptor = cipher.encryptor()
    
    # 对明文进行 PKCS7 填充
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(plaintext.encode('utf-8')) + padder.finalize()
    
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()

    # 将 IV + 密文拼接后 Base64 编码（解密时需拆分）
    result = base64.b64encode(iv + ciphertext).decode('utf-8')
    return result

def decrypt_string_aes(encrypted_b64: str, key: str) -> str:
    """
    使用 AES-128-CBC 解密字符串。

    :param encrypted_b64: Base64 编码的密文字符串（iv + ciphertext）
    :param key:           Base64 编码的 16 字节密钥
    :return:              解密后的明文字符串
    """
    # 解码密钥和密文
    key_bytes = base64.b64decode(key.encode('utf-8'))
    encrypted_data = base64.b64decode(encrypted_b64.encode('utf-8'))

    # 拆分 IV（前 16 字节）和密文
    iv = encrypted_data[:16]
    ciphertext = encrypted_data[16:]

    # 执行 AES-CBC 解密
    cipher = Cipher(algorithms.AES(key_bytes), modes.CBC(iv))
    decryptor = cipher.decryptor()
    padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()
    
    # 去除 PKCS7 填充
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()
    
    return plaintext.decode('utf-8')

def api_return(code: int, message: str, data: dict = None):
    res = {
        'code': code,
        'message': message,
        'data': data
    }
    json_res = json.dumps(res, ensure_ascii=False)
    return encrypt_string_aes(json_res, KEY)

def control_service(service_name, action):
    """
    控制 systemctl 服务
    :param service_name: 服务名称（例如 'nginx'、'apache2'）
    :param action: 动作，可选 'start'、'stop'、'restart'、'status'
    """
    try:
        # 构建命令（需要 sudo 权限）
        command = ['systemctl', action, service_name]
        # 执行命令并捕获输出
        result = subprocess.run(command, capture_output=True, text=True)

        if result.returncode == 0:
            print(f"✅ 服务 '{service_name}' {action} 成功")
            if result.stdout:
                print("输出:", result.stdout.strip())
        else:
            print(f"❌ 服务 '{service_name}' {action} 失败")
            if result.stderr:
                print("错误:", result.stderr.strip())
    except Exception as e:
        print(f"执行命令时出错: {e}")

def is_service_running(service_name):
    """检查 systemd 服务是否正在运行"""
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', service_name],
            capture_output=True,
            text=True
        )
        # is-active 返回 'active' 表示正在运行
        return result.stdout.strip() == 'active'
    except Exception as e:
        print(f"检查服务状态时出错: {e}")
        return False
    
@app.route('/')
def hello_world():
    return 'Hello, Flask!'

@app.route('/status')
def status():
    return api_return(0, 'success', {'status': 'ok'})

@app.route('/getCFG')
def getCFG():
    with open('/root/qt/qt_op_robot_fr_small/coins.json', 'r', encoding='utf-8') as f:
        cfgcontent = f.read()
    json_cfg = json.loads(cfgcontent)
    return api_return(0, 'success', {'data': json_cfg})

@app.route('/setCFG', methods=['POST'])
def setCFG():
    cfgcontent = request.form.get('data')
    cfgcontent = decrypt_string_aes(cfgcontent, KEY)
    with open('/root/qt/qt_op_robot_fr_small/coins.json', 'w', encoding='utf-8') as f:
        f.write(cfgcontent)
    return api_return(0, 'success')

@app.route('/getTradeStatus')
def getTradeStatus():
    with open('/root/qt/qt_op_robot_fr_small/state.json', 'r', encoding='utf-8') as f:
        statuscontent = f.read()
    json_data = json.loads(statuscontent)
    return api_return(0, 'success', {'data': json_data})

@app.route('/getTradeProgramStatus')
def getTradeProgramStatus():
    if is_service_running('QtService'):
        return api_return(0, 'success', {'data': 'running'})
    else:
        return api_return(0, 'success', {'data': 'stopped'})

@app.route('/controlTradeProgram', methods=['POST'])
def controlTradeProgram():
    action = request.form.get('data')
    action = decrypt_string_aes(action, KEY)
    if action == 'start':
        control_service('QtService', 'start')
        return api_return(0, 'success')
    elif action == 'stop':
        control_service('QtService', 'stop')
        return api_return(0, 'success')
    elif action == 'restart':
        control_service('QtService', 'restart')
        return api_return(0, 'success')
    else:
            return api_return(400, 'fail'+action)
    
if __name__ == '__main__':
    with open('webapi_config.yaml', 'r', encoding='utf-8') as file:
        data = yaml.load(file, Loader=yaml.FullLoader)
    
    if len(data['key']) != 24:
        KEY = generate_aes_key()
        data['key'] = KEY
        with open('webapi_config.yaml', 'w', encoding='utf-8') as file:
            yaml.dump(data, file, allow_unicode=True)
    else:
        KEY = data['key']
    
    app.run(host='0.0.0.0', port=8501)