import streamlit as st
from services import get_full_data, get_trade_stats
from pages import dashboard, detail, trade_stats
from coin_manager import CoinManager  # 新增：导入 CoinManager


st.set_page_config(page_title="QT 综合监控系统", layout="wide")

# --- 注入暗黑金融风格 CSS (照抄 qt_view.py) ---
st.markdown("""
<style>
/* ========== 全局背景 ========== */
.stApp { background-color: #000000 !important; color: #FFFFFF !important; }

/* ========== 侧边栏 ========== */
[data-testid="stSidebar"] { background-color: #050505 !important; border-right: 1px solid #222 !important; }
[data-testid="stSidebar"] div, [data-testid="stSidebar"] label, [data-testid="stSidebar"] span, [data-testid="stSidebar"] p { color: #e0e0e0 !important; font-weight: 500 !important; }

/* ========== 隐藏 Streamlit 自带导航区域 ========== */
/* 隐藏 Streamlit 侧边栏顶部的默认页面导航 */
[data-testid="stSidebar"] > div:first-child > div:first-child { display: none; }
/* 隐藏 Streamlit 侧边栏的标题 */
[data-testid="stSidebar"] .css-1d391sc { display: none; }
/* 侧边栏顶部留白去掉 */
[data-testid="stSidebar"] > div:first-child { padding-top: 0rem !important; }

/* ========== 主内容区顶部贴顶 ========== */
.block-container { padding-top: 1rem !important; padding-bottom: 0rem !important; padding-left: 1rem !important; padding-right: 1rem !important; max-width: 100% !important; }
[data-testid="stAppViewContainer"] > section:nth-child(2) > div:first-child { padding-top: 0rem !important; }

/* ========== 隐藏顶栏和底栏 ========== */
header { visibility: hidden; height: 0px !important; min-height: 0px !important; padding: 0 !important; margin: 0 !important; }
footer { visibility: hidden; }

/* ========== 控件颜色 ========== */
[data-testid="stWidgetLabel"] p { color: #AAAAAA !important; }
div[data-testid="stRadio"] label p { color: #FFFFFF !important; }
[data-testid="stMetricValue"] { color: #FFFFFF !important; font-weight: 800 !important; }
</style>
""", unsafe_allow_html=True)




# 新增：配置你的服务名称和对应路径（请将路径替换为你实际的路径）
SERVICE_CONFIGS = {
    "QT0001": "/root/qt/qt_op_robot", 
    "FRQT0001": "/root/qt/qt_op_robot_fr_small", 
    "bybit_main": "/root/qt/qt_op_robot_fr", 
    # 如果有多个服务，在这里添加 "服务B": "./service_b_dir"
}
# 初始化 CoinManager
coin_manager = CoinManager(service_configs=SERVICE_CONFIGS)
# 默认取第一个服务名（如果你的币种分布在不同服务，可以写逻辑动态匹配，这里先默认取第一个）
default_service_name = list(SERVICE_CONFIGS.keys())[0] if SERVICE_CONFIGS else "未知服务"



df = get_full_data()

# 侧边栏
st.sidebar.title(f"导航 ({len(df)})")
if not df.empty:
    page = st.sidebar.radio(
        "切换页面",
        ["📊 全量看板", "💰 成交统计"] + df['symbol'].tolist()
    )
else:
    page = "📊 全量看板"

# 路由分发
if page == "📊 全量看板":
    dashboard.render(df)
elif page == "💰 成交统计":
    trade_stats.render(coin_manager=coin_manager)  # 修改：传入 coin_manager
else:
     # 修改：动态查找该币种属于哪个服务，找不到则降级使用默认服务名
    actual_service_name = coin_manager.find_service_by_symbol(page)
    if actual_service_name is None:
        actual_service_name = default_service_name
        
    detail.render(page, coin_manager=coin_manager, service_name=actual_service_name)
