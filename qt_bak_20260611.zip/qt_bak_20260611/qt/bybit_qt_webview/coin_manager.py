import json
import os
from dataclasses import dataclass
from typing import Dict, List, Optional

# ================= 1. 定义数据结构类 =================

@dataclass
class OpenCloseConfig:
    bp: int
    deep: int

@dataclass
class DirectionConfig:
    amount: int
    open: OpenCloseConfig
    close: OpenCloseConfig

@dataclass
class CoinConfig:
    """对应 coins.json 中的币种配置信息"""
    symbol: str
    max_loops: int
    max_position: int
    up: DirectionConfig
    down: DirectionConfig
    confirm_ms: int = 0
    slip_ticks: int = 0

@dataclass
class PositionState:
    up: float
    down: float
    max_allowed: float

@dataclass
class CoinState:
    """对应 state.json 中的币种执行状态信息"""
    loop_status: str
    position: PositionState
    update_time: str


# ================= 2. 定义管理类 =================

class CoinManager:
    def __init__(self, service_configs: Dict[str, str]):
        """
        初始化管理类
        :param service_configs: 服务配置字典，格式为 {"服务名称": "服务所在目录路径"}
        例如: {"service_1": "/path/to/service1", "service_2": "/path/to/service2"}
        """
        self.service_configs = service_configs

    def _read_json(self, file_path: str) -> Optional[dict]:
        """读取 JSON 文件的内部方法"""
        if not os.path.exists(file_path):
            return None
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"读取文件 {file_path} 失败: {e}")
            return None

    def get_coin_config(self, service_name: str, symbol: str) -> Optional[CoinConfig]:
        """
        获取指定服务下指定币种的配置信息 (每次调用实时读取 coins.json)
        """
        path = self.service_configs.get(service_name)
        if not path:
            return None
        
        data = self._read_json(os.path.join(path, "coins.json"))
        if not data:
            return None
            
        for item in data:
            if item.get("symbol") == symbol:
                try:
                    return CoinConfig(
                        symbol=item["symbol"],
                        max_loops=item["max_loops"],
                        max_position=item["max_position"],
                        up=DirectionConfig(
                            amount=item["up"]["amount"],
                            open=OpenCloseConfig(**item["up"]["open"]),
                            close=OpenCloseConfig(**item["up"]["close"])
                        ),
                        down=DirectionConfig(
                            amount=item["down"]["amount"],
                            open=OpenCloseConfig(**item["down"]["open"]),
                            close=OpenCloseConfig(**item["down"]["close"])
                        ),
                        confirm_ms=item.get("confirm_ms", 0),
                        slip_ticks=item.get("slip_ticks", 0)
                    )
                except KeyError as e:
                    print(f"解析 {symbol} 配置失败，缺少字段: {e}")
                    return None
        return None

    def get_coin_state(self, service_name: str, symbol: str) -> Optional[CoinState]:
        """
        获取指定服务下指定币种的执行状态 (每次调用实时读取 state.json)
        """
        path = self.service_configs.get(service_name)
        if not path:
            return None
            
        data = self._read_json(os.path.join(path, "state.json"))
        if not data:
            return None
            
        state_data = data.get(symbol)
        if not state_data:
            return None
            
        try:
            pos_data = state_data["position"]
            return CoinState(
                loop_status=state_data["loop_status"],
                position=PositionState(
                    up=pos_data["up"],
                    down=pos_data["down"],
                    max_allowed=pos_data["max_allowed"]
                ),
                update_time=state_data["update_time"]
            )
        except KeyError as e:
            print(f"解析 {symbol} 状态失败，缺少字段: {e}")
            return None

    def get_all_coin_configs(self, service_name: str) -> List[CoinConfig]:
        """获取指定服务下所有币种的配置信息"""
        path = self.service_configs.get(service_name)
        if not path:
            return []
            
        data = self._read_json(os.path.join(path, "coins.json"))
        if not data:
            return []
            
        configs = []
        for item in data:
            try:
                configs.append(CoinConfig(
                    symbol=item["symbol"],
                    max_loops=item["max_loops"],
                    max_position=item["max_position"],
                    up=DirectionConfig(
                        amount=item["up"]["amount"],
                        open=OpenCloseConfig(**item["up"]["open"]),
                        close=OpenCloseConfig(**item["up"]["close"])
                    ),
                    down=DirectionConfig(
                        amount=item["down"]["amount"],
                        open=OpenCloseConfig(**item["down"]["open"]),
                        close=OpenCloseConfig(**item["down"]["close"])
                    )
                ))
            except KeyError:
                continue
        return configs

    def get_all_coin_states(self, service_name: str) -> Dict[str, CoinState]:
        """获取指定服务下所有币种的执行状态"""
        path = self.service_configs.get(service_name)
        if not path:
            return {}
            
        data = self._read_json(os.path.join(path, "state.json"))
        if not data:
            return {}
            
        states = {}
        for symbol, state_data in data.items():
            try:
                pos_data = state_data["position"]
                states[symbol] = CoinState(
                    loop_status=state_data["loop_status"],
                    position=PositionState(
                        up=pos_data["up"],
                        down=pos_data["down"],
                        max_allowed=pos_data["max_allowed"]
                    ),
                    update_time=state_data["update_time"]
                )
            except KeyError:
                continue
        return states
    # ============= 新增：根据币种反查服务名 =============
    def find_service_by_symbol(self, symbol: str) -> Optional[str]:
        """遍历所有服务，查找币种所属的服务名称"""
        for service_name, path in self.service_configs.items():
            # 先查 coins.json
            data = self._read_json(os.path.join(path, "coins.json"))
            if data:
                for item in data:
                    if item.get("symbol") == symbol:
                        return service_name
            
            # 再查 state.json (双保险，防止有些币种只在 state 里)
            state_data = self._read_json(os.path.join(path, "state.json"))
            if state_data and symbol in state_data:
                return service_name
                
        return None  # 找不到返回 None
