from sqlalchemy import create_engine

DB_URI = "mysql+pymysql://qt:sT36Hc2CwPbN8txY@127.0.0.1:3306/qt"
engine = create_engine(DB_URI, pool_recycle=3600)
