import streamlit as st
import pandas as pd
from sqlalchemy import text
from datetime import datetime
from db import engine
from algo import get_processed_data, solve_axis

@st.cache_data(ttl=5)
def get_full_data():
    """主页面全量数据"""
    try:
        with engine.connect() as conn:
            show_tables_query = text("SHOW TABLES LIKE 'arb_5s_TREND_%'")
            table_rows = conn.execute(show_tables_query).fetchall()
            all_symbols = [r[0].replace('arb_5s_TREND_', '') for r in table_rows]
            if not all_symbols: return pd.DataFrame()

            config_query = text("""
                SELECT sr.symbol, sr.open_bp, sr.close_bp, sr.open_cnt, sr.close_cnt,
                       sr.open_avg_depth, sr.close_avg_depth, sr.ts_created
                FROM strategy_recommendations sr
                INNER JOIN (SELECT symbol, MAX(id) as max_id FROM strategy_recommendations GROUP BY symbol) latest 
                ON sr.id = latest.max_id
            """)
            config_df = pd.read_sql(config_query, conn)

            market_query = text("""
                SELECT m1.symbol, m1.price, m1.volume_24h_usdc, m1.oi_value_usdc,m1.current_funding_rate, m1.usdt_funding_rate
                FROM market_metrics m1
                INNER JOIN (SELECT symbol, MAX(ts) as max_ts FROM market_metrics GROUP BY symbol) m2 
                ON m1.symbol = m2.symbol AND m1.ts = m2.max_ts
            """)
            market_df = pd.read_sql(market_query, conn)
            
            fills_query = text("""
                SELECT symbol,SUM(CASE WHEN side IN ('DOWN_CLOSE','UP_CLOSE')
                AND created_at >= NOW() - INTERVAL 24 HOUR
                THEN trade_amount * fill_usdc_price ELSE 0 END) AS h24_close_amt,
                SUM(CASE WHEN side IN ('DOWN_OPEN','UP_OPEN')
                AND created_at >= NOW() - INTERVAL 24 HOUR
                THEN trade_amount * fill_usdc_price ELSE 0 END) AS h24_open_amt
                FROM order_fills
                WHERE created_at >= NOW() - INTERVAL 24 HOUR
                GROUP BY symbol
            """)
            fills_df = pd.read_sql(fills_query, conn)


            df = pd.merge(pd.DataFrame({'symbol': all_symbols}), config_df, on='symbol', how='left')
            df = pd.merge(df, market_df, on='symbol', how='left')
            df = pd.merge(df, fills_df, on='symbol', how='left')
            # 【关键修复】防止 merge 失败导致列不存在
            df['h24_open_amt'] = df['h24_open_amt'].fillna(0)
            df['h24_close_amt'] = df['h24_close_amt'].fillna(0)

            # 格式化逻辑
            def format_ts(ts):
                if pd.isna(ts) or ts == 0: return "未计算"
                try: return datetime.fromtimestamp(int(ts) / 1000).strftime('%m-%d %H:%M:%S')
                except: return "格式错误"

            # 【关键修复】显示真实金额 + 比值，而不是纯比值
            df['24H CLOSE/OPEN'] = df.apply(
                lambda x: f"${x['h24_close_amt']:,.2f} /${x['h24_open_amt']:,.2f}"
                if pd.notna(x['h24_open_amt']) and x['h24_open_amt'] > 0
                else (f"${x['h24_close_amt']:,.2f} / 无OPEN" if pd.notna(x['h24_close_amt']) and x['h24_close_amt'] > 0 else "-"),
                axis=1
            )


            df['刷新时间'] = df['ts_created'].apply(format_ts)
            df['推荐(开/平)'] = df.apply(lambda x: f"{int(x.open_bp)} / {int(x.close_bp)}" if pd.notnull(x.open_bp) else "- / -", axis=1)
            df['统计点数(开/平)'] = df.apply(lambda x: f"{int(x.open_cnt)} / {int(x.close_cnt)}" if pd.notnull(x.open_cnt) else "0 / 0", axis=1)
            df['_min_cnt'] = df.apply(lambda x: min(int(x.open_cnt), int(x.close_cnt)) if pd.notnull(x.open_cnt) else 0, axis=1)
            df['深度统计(开/平)'] = df.apply(lambda x: f"{x.open_avg_depth:.2f} / {x.close_avg_depth:.2f}" if pd.notnull(x.open_avg_depth) else "0.00 / 0.00", axis=1)
            df['价格指数'] = df['price'].fillna(0.0)
            df['24h交易额'] = df['volume_24h_usdc'].fillna(0.0)
            df['现有持仓'] = df['oi_value_usdc'].fillna(0.0)
            df['usdc_funding_rate'] = df['current_funding_rate'].fillna(0.0)  # 🟢 新增
            df['usdt_funding_rate'] = df['usdt_funding_rate'].fillna(0.0)  # 🟢 新增

            return df.sort_values(by='_min_cnt', ascending=False)
    except Exception as e:
        st.error(f"数据加载失败: {e}")
        return pd.DataFrame()

@st.cache_data(ttl=60)
def get_detail_market(symbol):
    """详情页：单个币种的基础数据"""
    try:
        with engine.connect() as conn:
            config_df = pd.read_sql(text("""
                SELECT sr.open_bp, sr.close_bp, sr.open_cnt, sr.close_cnt,
                       sr.open_avg_depth, sr.close_avg_depth, sr.ts_created
                FROM strategy_recommendations sr
                INNER JOIN (SELECT symbol, MAX(id) as max_id FROM strategy_recommendations GROUP BY symbol) latest 
                ON sr.id = latest.max_id WHERE sr.symbol = :symbol
            """), conn, params={"symbol": symbol})

            market_df = pd.read_sql(text("""
                SELECT price, volume_24h_usdc, oi_value_usdc
                FROM market_metrics WHERE symbol = :symbol ORDER BY ts DESC LIMIT 1
            """), conn, params={"symbol": symbol})

            return (
                config_df.iloc[0].to_dict() if not config_df.empty else None,
                market_df.iloc[0].to_dict() if not market_df.empty else None
            )
    except:
        return None, None

@st.cache_data(ttl=60)
def get_detail_chart_data(symbol, hours):
    """详情页：获取图表所需的计算数据"""
    return get_processed_data(engine, symbol, hours)
    
    
    
    
    
# 替换 services.py 中的 get_trade_stats 函数
@st.cache_data(ttl=30)
def get_trade_stats(time_range="default"):
    """成交统计页：从 order_fills 表聚合数据"""
    try:
        with engine.connect() as conn:
            # 1. 设置会话时区为UTC
            conn.execute(text("SET time_zone = '+00:00'"))
            
            # 2. 根据选择动态构建时间条件
            if time_range == "default":
                # 默认(从每天8点开始)：如果当前时间小于8点，取昨天8点，否则取今天8点
                # 注意：这里的8点是 UTC 时间。如果你指的是北京时间8点，请将 '08:00:00' 改为 '00:00:00'
                time_cond = """
                    CASE 
                        WHEN CURTIME() < '08:00:00' THEN DATE_SUB(CURDATE(), INTERVAL 1 DAY) + INTERVAL 8 HOUR 
                        ELSE CURDATE() + INTERVAL 8 HOUR 
                    END
                """
            elif time_range == "3h":
                time_cond = "DATE_SUB(NOW(), INTERVAL 3 HOUR)"
            elif time_range == "7d":
                time_cond = "DATE_SUB(NOW(), INTERVAL 7 DAY)"
            else:
                time_cond = "CURDATE()"

            # 3. 执行查询，直接按 close_amount 降序排序
            query = text(f"""
                SELECT 
                    symbol,
                    SUM(CASE WHEN side IN ('DOWN_OPEN', 'UP_OPEN') AND created_at >= ({time_cond}) THEN trade_amount * fill_usdc_price ELSE 0 END) AS open_amount,
                    SUM(CASE WHEN side IN ('DOWN_OPEN', 'UP_OPEN') AND created_at >= ({time_cond}) THEN 1 ELSE 0 END) AS open_count,
                    SUM(CASE WHEN side IN ('DOWN_CLOSE', 'UP_CLOSE') AND created_at >= ({time_cond}) THEN trade_amount * fill_usdc_price ELSE 0 END) AS close_amount,
                    SUM(CASE WHEN side IN ('DOWN_CLOSE', 'UP_CLOSE') AND created_at >= ({time_cond}) THEN 1 ELSE 0 END) AS close_count
                FROM order_fills 
                WHERE created_at >= ({time_cond})
                GROUP BY symbol
                ORDER BY close_amount DESC
            """)
            
            df = pd.read_sql(query, conn)

            if df.empty:
                df = pd.DataFrame(columns=['symbol', 'open_amount', 'open_count', 'close_amount', 'close_count'])

            # 4. 组装前端需要的显示列
            df['open交易额'] = df.apply(
                lambda r: f"${r['open_amount']:,.0f} " if r['open_amount'] > 0 else "-", 
                axis=1
            )
            df['close交易额'] = df.apply(
                lambda r: f"${r['close_amount']:,.0f} " if r['close_amount'] > 0 else "-", 
                axis=1
            )
            df['现有持仓'] = ""  # 按要求先留空

            return df

    except Exception as e:
        st.error(f"成交统计加载失败: {e}")
        return pd.DataFrame(columns=['symbol', 'open_amount', 'open_count', 'close_amount', 'close_count', 'open交易额', 'close交易额', '现有持仓'])





