import pandas as pd
from sqlalchemy import text
import time

def get_processed_data(engine, symbol, hours):
    """预处理单币种累积数据"""
    ts_limit = int((time.time() - (hours * 3600)) * 1000)
    table_name = f"arb_5s_TREND_{symbol}"
    query = text(f"""
        SELECT side, ROUND(bp_avg) as bp, COUNT(*) as cnt, SUM(depth_avg) as sum_depth
        FROM `{table_name}`
        WHERE ts >= :ts AND bp_avg BETWEEN -20 AND 100
        GROUP BY side, ROUND(bp_avg)
    """)
    try:
        with engine.connect() as conn:
            df = pd.read_sql(query, conn, params={"ts": ts_limit})
            if df.empty:
                return None

            bp_range = range(-20, 101)
            c_sum = {1: {b: 0 for b in bp_range}, 2: {b: 0 for b in bp_range}}
            c_depth_sum = {1: {b: 0.0 for b in bp_range}, 2: {b: 0.0 for b in bp_range}}

            for side in [1, 2]:
                side_df = df[df['side'] == side].set_index('bp')
                accum_cnt, accum_depth = 0, 0.0
                for b in sorted(bp_range, reverse=True):
                    accum_cnt += int(side_df.loc[b, 'cnt']) if b in side_df.index else 0
                    accum_depth += float(side_df.loc[b, 'sum_depth']) if b in side_df.index else 0.0
                    c_sum[side][b] = accum_cnt
                    c_depth_sum[side][b] = accum_depth

            return c_sum, c_depth_sum
    except Exception as e:
        print(f"Algo Error: {e}")
        return None

def solve_axis(c_sum, c_depth_sum, target_s):
    """计算特定 A+B 下的最优配对"""
    best_a, min_diff = None, float('inf')
    for a in range(-10, target_s + 11):
        b = target_s - a
        if a not in c_sum[1] or b not in c_sum[2]:
            continue
        cnt1, cnt2 = c_sum[1][a], c_sum[2][b]
        if cnt1 == 0 and cnt2 == 0:
            continue
        diff = abs(cnt1 - cnt2)
        if diff < min_diff:
            min_diff, best_a = diff, a
        elif diff == min_diff and cnt1 > c_sum[1].get(best_a, -1):
            best_a = a

    if best_a is not None:
        fb = target_s - best_a
        open_cnt = c_sum[1][best_a]
        close_cnt = c_sum[2][fb]
        return {
            "open_bp": best_a, "close_bp": fb,
            "open_cnt": open_cnt, "close_cnt": close_cnt,
            "open_avg_depth": round(c_depth_sum[1][best_a] / open_cnt, 2) if open_cnt > 0 else 0,
            "close_avg_depth": round(c_depth_sum[2][fb] / close_cnt, 2) if close_cnt > 0 else 0,
        }
    return None
