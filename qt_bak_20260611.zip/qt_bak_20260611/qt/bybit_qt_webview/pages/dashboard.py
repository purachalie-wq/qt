# -*- coding: UTF-8 -*-
import streamlit as st
import pandas as pd
import re

def render(df):
    st.title("📊 策略与市场行情全景")
    
    if df.empty:
        st.warning("暂无数据，请确认数据库表及字段。")
        return

    # ==========================================
    # ⚙️ 1. 提取刷新时间并配置顶部组件（时间 + 刷新按钮）
    # ==========================================
    valid_times = df['刷新时间'].dropna()
    latest_time = "未计算"
    if not valid_times.empty:
        latest_time = str(valid_times.iloc[0])

    # 布局：左侧标题预留，中间放时间，右侧放刷新按钮
    col_title, col_time, col_btn = st.columns([4, 2, 1])
    
    with col_time:
        st.markdown(
            f"<div style='text-align: right; color: #888888; font-size: 14px; padding-top: 25px;'> "
            f"⏱️ 数据时间: <span style='color: #00FF00; font-weight: bold;'>{latest_time}</span>"
            f"</div>", 
            unsafe_allow_html=True
        )
        
    with col_btn:
        # 稍微往下垫一点像素以便与时间文本对齐
        st.markdown("<div style='padding-top: 18px;'></div>", unsafe_allow_html=True)
        # 增加刷新按钮，点击后 Streamlit 会自动 rerun 重新拉取上游数据
        if st.button("🔄 刷新", use_container_width=True):
            pass 

    # ==========================================
    # ⚙️ 2. 列名映射与筛选（引入新费率，重命名持仓）
    # ==========================================
    column_mapping = {
        'symbol': '币种',
        '推荐(开/平)': '推荐(开/平)',
        '统计点数(开/平)': '统计点数(开/平)',
        '深度统计(开/平)': '深度统计(开/平)',
        'usdc_funding_rate': 'USDC费率',   # 新增
        'usdt_funding_rate': 'USDT费率',   # 新增
        '24h交易额': '24h交易额',
        'oi_value_usdc': '持仓规模(USDC)',  # 重命名
        '价格指数': '价格指数',
        '24H CLOSE/OPEN': '24H CLOSE/OPEN'
    }

    # 按照映射字典的 key 提取数据并重新命名列
    display_df = df[list(column_mapping.keys())].copy()
    display_df = display_df.reset_index(drop=True)
    display_df.columns = list(column_mapping.values())

    # 动态计算前端大屏容器的高度
    dynamic_height = (len(df) + 1) * 35 + 50

    # ==========================================
    # 🎨 3. 动态行/单元格着色渲染逻辑
    # ==========================================
    def highlight_row(row):
        base_bg = '#000000'
        styles = []
        
        for col in row.index:
            # 🟢 优化：处理 USDC费率 和 USDT费率 的高亮逻辑
            if col in ['USDC费率', 'USDT费率']:
                try:
                    rate_val = float(row[col] or 0)
                    if abs(rate_val) > 0.0001:
                        # 绝对值大于 0.0001 (1BP) 则标绿加粗
                        styles.append(f'background-color: {base_bg}; color: #00FF00; font-weight: bold;')
                        continue
                except:
                    pass

            # 单独处理 24H CLOSE/OPEN 列
            elif col == '24H CLOSE/OPEN':
                val = str(row[col])
                if val != '-':
                    try:
                        clean_val = val.replace('$', '').replace(',', '')
                        nums = re.findall(r"\d+\.?\d*", clean_val)
                        if nums:
                            close_num = float(nums[0])
                            if close_num > 1000:
                                styles.append(f'background-color: {base_bg}; color: #00FF00; font-weight: bold;')
                                continue
                    except:
                        pass
                        
            # 单独处理 24h交易额 列
            elif col == '24h交易额':
                val = str(row[col])
                if val != '-':
                    try:
                        clean_val = val.replace(',', '')
                        trade_amount = float(clean_val)
                        if trade_amount > 20000:
                            styles.append(f'background-color: {base_bg}; color: #00FF00; font-weight: bold;')
                            continue
                    except:
                        pass
                        
            # 单独处理 深度统计(开/平) 列
            elif col == '深度统计(开/平)':
                val = str(row[col])
                if '/' in val:
                    try:
                        parts = val.split('/')
                        open_val = float(parts[0].replace(',', ''))
                        close_val = float(parts[1].replace(',', ''))
                        price_index = row['价格指数']
                        open_product = open_val * price_index
                        close_product = close_val * price_index
                        if open_product < 10 or close_product < 10:
                            styles.append(f'background-color: {base_bg}; color: #FF0000; font-weight: bold;')
                            continue
                    except:
                        pass
            
            # 其他不满足染色条件的常规单元格
            styles.append(f'background-color: {base_bg}; color: #FFFFFF;')
            
        return styles

    # ==========================================
    # ✨ 4. 数据精度格式化与 Styler 注入
    # ==========================================
    styled_df = display_df.style.apply(highlight_row, axis=1).format({
        '价格指数': '{:.4f}', 
        '24h交易额': '{:,.0f}', 
        '持仓规模(USDC)': '{:,.0f}',
        'USDC费率': '{:.5f}', # 费率建议保留5位小数
        'USDT费率': '{:.5f}'
    }).set_table_styles([
        # 表头全局样式
        {'selector': 'th', 'props': [
            ('background-color', '#111111'), 
            ('color', '#FFFFFF'), 
            ('border', '1px solid #333333'),
            ('padding', '8px')
        ]},
        # 单元格边框与间距
        {'selector': 'td', 'props': [
            ('border', '1px solid #333333'),
            ('padding', '8px')
        ]},
        # 表格结构样式
        {'selector': 'table', 'props': [
            ('border-collapse', 'collapse'), 
            ('width', '100%'),
            ('font-size', '14px')
        ]}
    ])

    # ==========================================
    # 🚀 5. 转为原生 HTML 并渲染大屏纵向无缝滚动容器
    # ==========================================
    html_table = styled_df.to_html(index=False, border=0, justify='left')
    
    st.markdown(f"""
    <div style="max-height: {dynamic_height}px; overflow-y: auto; width: 100%;">
        {html_table}
    </div>
    """, unsafe_allow_html=True)