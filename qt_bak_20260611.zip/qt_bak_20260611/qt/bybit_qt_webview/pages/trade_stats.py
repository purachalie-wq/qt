import streamlit as st
import pandas as pd
from services import get_trade_stats

def _clean_numeric(val):
    """将带 $ 和 , 的字符串转为浮点数"""
    if pd.isna(val) or val == '-' or val == '':
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        cleaned = val.replace('$', '').replace(',', '').strip()
        try:
            return float(cleaned)
        except ValueError:
            return 0.0
    return 0.0

def render(coin_manager=None):
    # 1. 标题居中显示
    st.markdown("<h1 style='text-align: center; color: white;'>💰 成交统计</h1>", unsafe_allow_html=True)
    
    # 2. 注入 CSS：强制 Tab 字体颜色为白色，并优化选中时的下划线颜色
    st.markdown("""
    <style>
        /* 未选中的 Tab 字体颜色 */
        [data-baseweb="tab-list"] button {
            color: white !important;
        }
        /* 选中的 Tab 字体加粗和下划线颜色 */
        [data-baseweb="tab-list"] button[aria-selected="true"] {
            color: white !important;
            font-weight: bold !important;
            border-bottom-color: white !important;
        }
        /* 鼠标悬停时的 Tab 颜色 */
        [data-baseweb="tab-list"] button:hover {
            color: #cccccc !important;
        }
    </style>
    """, unsafe_allow_html=True)
    
    if not coin_manager:
        st.warning("CoinManager 未初始化，无法按服务器分类")
        return

    # 1. 获取所有服务器及其配置的完整币种列表
    service_symbols = {}
    for svc in coin_manager.service_configs.keys():
        cfgs = coin_manager.get_all_coin_configs(svc)
        syms = [c.symbol for c in cfgs] if cfgs else []
        service_symbols[svc] = syms

    # ================= 2. 时间选择器放在 Tab 上方 =================
    time_range = st.radio(
        "选择时间范围",
        options=["default", "3h", "7d"],
        format_func=lambda x: {"default": "默认(每日8点起)", "3h": "最近3小时", "7d": "最近7天"}[x],
        horizontal=True,
        index=0,
        key="trade_time_range"
    )

    # ================= 3. 获取并清洗数据 =================
    raw_df = get_trade_stats(time_range=time_range)
    
    if raw_df.empty:
        raw_df = pd.DataFrame(columns=['symbol', 'close交易额', 'open交易额', '现有持仓', 'open_amount', 'close_amount'])
    
    # 清洗数值列，把带符号的字符串转成数字
    num_cols = ['close交易额', 'open交易额', '现有持仓', 'open_amount', 'close_amount']
    for col in num_cols:
        if col in raw_df.columns:
            raw_df[col] = raw_df[col].apply(_clean_numeric)

    # 给原始数据打上服务器标签
    if 'symbol' in raw_df.columns:
        raw_df['service'] = raw_df['symbol'].apply(lambda x: coin_manager.find_service_by_symbol(str(x)) or "未知服务")
    else:
        raw_df['service'] = "未知服务"

    # ================= 4. 创建 Tab：总览 + 各服务器 =================
    tab_names = ["总览"] + list(coin_manager.service_configs.keys())
    tabs = st.tabs(tab_names)

    # ================= Tab 0: 总览 =================
    with tabs[0]:
        overview_rows = []
        for svc, syms in service_symbols.items():
            svc_raw_df = raw_df[raw_df['service'] == svc]
            exist_syms = set(svc_raw_df['symbol'].unique()) if not svc_raw_df.empty else set()
            missing_syms = set(syms) - exist_syms
            
            if missing_syms:
                missing_data = pd.DataFrame({
                    'symbol': list(missing_syms),
                    'close交易额': 0.0,
                    'open交易额': 0.0,
                    '现有持仓': 0.0,
                    'open_amount': 0.0,
                    'close_amount': 0.0,
                    'service': svc
                })
                svc_full_df = pd.concat([svc_raw_df, missing_data], ignore_index=True)
            else:
                svc_full_df = svc_raw_df
                
            overview_rows.append({
                '服务器': svc,
                'close交易额': svc_full_df['close交易额'].sum(),
                'open交易额': svc_full_df['open交易额'].sum(),
                '现有持仓': svc_full_df['现有持仓'].sum()
            })
        
        overview_df = pd.DataFrame(overview_rows)
        
        if not overview_df.empty:
            grand_total = {
                '服务器': '合计',
                'close交易额': overview_df['close交易额'].sum(),
                'open交易额': overview_df['open交易额'].sum(),
                '现有持仓': overview_df['现有持仓'].sum()
            }
            overview_df = pd.concat([overview_df, pd.DataFrame([grand_total])], ignore_index=True)

        _render_styled_table(overview_df, first_col_name='服务器')

    # ================= Tab 1...N: 各服务器明细 =================
    for i, svc_name in enumerate(list(coin_manager.service_configs.keys())):
        with tabs[i+1]:
            syms = service_symbols.get(svc_name, [])
            svc_raw_df = raw_df[raw_df['service'] == svc_name].copy()
            
            exist_syms = set(svc_raw_df['symbol'].unique()) if not svc_raw_df.empty else set()
            missing_syms = set(syms) - exist_syms
            
            if missing_syms:
                missing_data = pd.DataFrame({
                    'symbol': list(missing_syms),
                    'close交易额': 0.0,
                    'open交易额': 0.0,
                    '现有持仓': 0.0
                })
                display_df = pd.concat([svc_raw_df[['symbol', 'close交易额', 'open交易额', '现有持仓']], missing_data], ignore_index=True)
            else:
                display_df = svc_raw_df[['symbol', 'close交易额', 'open交易额', '现有持仓']].copy()
                
            display_df.columns = ['币种', 'close交易额', 'open交易额', '现有持仓']
            
            for col in ['close交易额', 'open交易额', '现有持仓']:
                display_df[col] = display_df[col].astype(float)
            
            if not display_df.empty:
                svc_total = {
                    '币种': '合计',
                    'close交易额': display_df['close交易额'].sum(),
                    'open交易额': display_df['open交易额'].sum(),
                    '现有持仓': display_df['现有持仓'].sum()
                }
                display_df = pd.concat([display_df, pd.DataFrame([svc_total])], ignore_index=True)
            
            _render_styled_table(display_df, first_col_name='币种')


# ================= 样式渲染抽离函数 =================
def _render_styled_table(df, first_col_name):
    """统一渲染带样式的 DataFrame 表格"""
    dynamic_height = (len(df) + 1) * 38 + 50

    def highlight_row(row):
        if row[first_col_name] == '合计':
            return ['background-color: #000000; color: #FFFFFF; font-weight: bold; border-top: 2px solid #FFFFFF;'] * len(row)
        return ['background-color: #000000; color: #FFFFFF;'] * len(row)

    format_dict = {
        'close交易额': '{:,.0f}',
        'open交易额': '{:,.0f}',
        '现有持仓': '{:,.0f}'
    }
    valid_format_dict = {k: v for k, v in format_dict.items() if k in df.columns}

    styled_df = (
        df.style
        .apply(highlight_row, axis=1)
        .format(valid_format_dict, na_rep="-")
        .set_table_styles([
            {'selector': 'th', 'props': [
                ('background-color', '#111111'), 
                ('color', '#FFFFFF'), 
                ('border', '1px solid #333333'),
                ('padding', '10px'), 
                ('text-align', 'left'),
                ('font-size', '14px'),
            ]},
            {'selector': 'td', 'props': [
                ('border', '1px solid #333333'),
                ('padding', '10px'), 
                ('text-align', 'left'),
                ('font-size', '14px'),
            ]},
            {'selector': 'table', 'props': [
                ('border-collapse', 'collapse'), 
                ('width', '100%'),
            ]},
        ])
    )

    html_table = styled_df.to_html(index=False, border=0, justify='left')
    st.markdown(f"""
    <div style="max-height: {dynamic_height}px; overflow-y: auto; width: 100%;">
        {html_table}
    </div>
    """, unsafe_allow_html=True)
