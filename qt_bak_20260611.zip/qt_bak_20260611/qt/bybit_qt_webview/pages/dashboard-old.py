import streamlit as st
import pandas as pd
import re

def render(df):
    st.title("📊 策略与市场行情全景")
    
    if df.empty:
        st.warning("暂无数据，请确认数据库表及字段。")
        return

    display_df = df[[
        'symbol', '推荐(开/平)', '统计点数(开/平)', '深度统计(开/平)',
        '价格指数','24H CLOSE/OPEN', '24h交易额', '现有持仓', '刷新时间'
    ]].copy()
    
    # 重置索引，去掉序号列
    display_df = display_df.reset_index(drop=True)
    display_df.columns = [
        '币种', '推荐(开/平)', '统计点数(开/平)', '深度统计(开/平)',
        '价格指数', '24H CLOSE/OPEN','24h交易额', '现有持仓', '刷新时间'
    ]

    dynamic_height = (len(df) + 1) * 35 + 50

    def highlight_row(row):
        # 先确定基础背景色
        if row['刷新时间'] == '未计算':
            base_bg = '#331111'
        else:
            base_bg = '#000000'
        
        styles = []
        for col in row.index:
            # 单独处理 24H CLOSE/OPEN 列
            if col == '24H CLOSE/OPEN':
                val = str(row[col])
                if val != '-':
                    try:
                        # 去掉$符号和逗号，用正则提取第一个数字（包括小数）
                        clean_val = val.replace('$', '').replace(',', '')
                        # 匹配数字（整数或小数）
                        nums = re.findall(r"\d+\.?\d*", clean_val)
                        if nums:
                            close_num = float(nums[0])
                            if close_num > 1000:
                                # 大于1000：背景色不变，字体改成绿色加粗
                                styles.append(f'background-color: {base_bg}; color: #00FF00; font-weight: bold;')
                                continue
                    except:
                        pass
            # 单独处理 24h交易额 列
            elif col == '24h交易额':
                val = str(row[col])
                if val != '-':
                    try:
                        # 去掉逗号，转换为数字
                        clean_val = val.replace(',', '')
                        trade_amount = float(clean_val)
                        if trade_amount > 20000:
                            # 大于20000：背景色不变，字体改成绿色加粗
                            styles.append(f'background-color: {base_bg}; color: #00FF00; font-weight: bold;')
                            continue
                    except:
                        pass
            # 单独处理 深度统计(开/平) 列
            elif col == '深度统计(开/平)':
                val = str(row[col])
                if '/' in val:
                    try:
                        parts = val.split('/')
                        open_val = float(parts[0].replace(',', ''))
                        close_val = float(parts[1].replace(',', ''))
                        price_index = row['价格指数']
                        open_product = open_val * price_index
                        close_product = close_val * price_index
                        if open_product < 10 or close_product < 10:
                            # 低于10：背景色不变，字体改成红色加粗
                            styles.append(f'background-color: {base_bg}; color: #FF0000; font-weight: bold;')
                            continue
                    except:
                        pass
            # 其他列：默认黑底白字（或暗红底白字）
            styles.append(f'background-color: {base_bg}; color: #FFFFFF;')
            
        return styles

    # 1. 使用 Pandas Styler 直接把颜色写死在单元格上
    styled_df = display_df.style.apply(highlight_row, axis=1).format({
        '价格指数': '{:.4f}', 
        '24h交易额': '{:,.0f}', 
        '现有持仓': '{:,.0f}'
    }).set_table_styles([
        # 表头样式：深灰背景，白字，深灰边框
        {'selector': 'th', 'props': [
            ('background-color', '#111111'), 
            ('color', '#FFFFFF'), 
            ('border', '1px solid #333333'),
            ('padding', '8px')
        ]},
        # 单元格边框样式
        {'selector': 'td', 'props': [
            ('border', '1px solid #333333'),
            ('padding', '8px')
        ]},
        # 表格整体样式
        {'selector': 'table', 'props': [
            ('border-collapse', 'collapse'), 
            ('width', '100%'),
            ('font-size', '14px')
        ]}
    ])

    # 2. 转换为原生 HTML，用外层 div 控制滚动高度
    html_table = styled_df.to_html(index=False, border=0, justify='left')
    
    # 3. 用 markdown 渲染 HTML
    st.markdown(f"""
    <div style="max-height: {dynamic_height}px; overflow-y: auto; width: 100%;">
        {html_table}
    </div>
    """, unsafe_allow_html=True)
