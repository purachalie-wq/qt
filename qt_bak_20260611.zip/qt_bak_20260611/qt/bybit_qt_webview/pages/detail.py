import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime, timedelta
from sqlalchemy import text

from db import engine
from services import get_detail_market, get_detail_chart_data
from algo import solve_axis
from pages.detail_charts import render_curve, render_scatter, render_funding, fr_get_year_stats, symbol_to_coin


def render(symbol, coin_manager=None, service_name="未知服务"):
    # ==========================================
    # 全局 CSS：暗黑金融风格
    # ==========================================
    # ==========================================
    # 全局 CSS：暗黑金融风格 (已调整间距)
    # ==========================================
    st.markdown("""
<style>
/* ========== 全局背景 ========== */
.stApp { background: #0a0a0f; }

/* metric 样式 */
[data-testid="stMetricLabel"] * { color: #6b7280 !important; font-size: 12px !important; }
[data-testid="stMetricValue"] * { color: #e5e7eb !important; font-size: 20px !important; font-weight: 600 !important; }

/* Tab 样式调整 */
[data-baseweb="tab-list"] {
    gap: 8px !important;
}
[data-baseweb="tab-list"] button { 
    color: #6b7280 !important; 
    font-size: 14px !important; 
    padding-top: 0px !important; /* 压缩 Tab 内部上间距 */
}
[data-baseweb="tab-list"] button[aria-selected="true"] { color: #e5e7eb !important; font-weight: 600 !important; border-bottom-color: #3b82f6 !important; }
[data-baseweb="tab-list"] button:hover { color: #9ca3af !important; }

/* 核心指标高亮卡 - 统一所有卡片大小 */
.core-card { 
    background: linear-gradient(135deg, #111118 0%, #0d0d14 100%); 
    border: 1px solid #1e1e2e; 
    border-radius: 10px; 
    padding: 20px 16px; 
    text-align: center; 
    min-height: 100px; /* 统一最小高度 */
}
.core-card .label { 
    color: #6b7280; 
    font-size: 11px; 
    text-transform: uppercase; 
    letter-spacing: 1px; 
    margin-bottom: 8px; 
}
.core-card .value { 
    font-size: 24px; 
    font-weight: 700; 
}

/* 分组卡片 */
.card { background: linear-gradient(135deg, #111118 0%, #0d0d14 100%); border: 1px solid #1e1e2e; border-radius: 10px; padding: 18px 22px; margin: 6px 0; }
.card-title { color: #4b5563; font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 14px; font-weight: 600; }
.card-row { display: flex; justify-content: space-between; align-items: center; }
.card-item { text-align: center; flex: 1; }
.card-item .label { color: #6b7280; font-size: 11px; margin-bottom: 4px; }
.card-item .value { color: #e5e7eb; font-size: 15px; font-weight: 600; }
.card-item .value.green { color: #34d399; }
.card-item .value.red { color: #f87171; }
.card-item .value.blue { color: #60a5fa; }
.card-item .value.amber { color: #fbbf24; }

/* 分割线：只调整特定位置的间距 */
.divider { border: none; border-top: 1px solid #1a1a2a; margin: 5px 0; }  /* 核心指标和交易配置之间的间距 */

/* 标题 */
.main-title { font-size: 28px; font-weight: 700; color: #e5e7eb; margin-bottom: 4px; }
.sub-title { font-size: 13px; color: #4b5563; margin-bottom: 16px; }

/* 状态指示灯 */
.dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; margin-right: 6px; vertical-align: middle; }
.dot.green { background: #34d399; box-shadow: 0 0 6px #34d39966; }
.dot.gray { background: #6b7280; }

/* 费率卡片 */
.top-card { background-color: #111111; border: 1px solid #333; padding: 5px; border-radius: 8px; text-align: center; height: 70px; display: flex; direction: column; justify-content: center; }
.top-label { color: #888; font-size: 0.75rem; margin-bottom: 4px; }
.top-value { color: #fff; font-size: 1rem; font-weight: bold; line-height: 1.2; }
</style>
""", unsafe_allow_html=True)




    # ==========================================
    # 收集数据
    # ==========================================
    current_pos_str = "0"
    max_pos_str = "-"
    up_oc_str = "-"
    down_oc_str = "-"
    loop_status_str = "-"
    pos_has_position = False

    if coin_manager:
        cfg = coin_manager.get_coin_config(service_name, symbol)
        state = coin_manager.get_coin_state(service_name, symbol)
        if cfg:
            up_oc_str = f"{cfg.up.open.bp} / {cfg.up.close.bp}"
            down_oc_str = f"{cfg.down.open.bp} / {cfg.down.close.bp}"
            max_pos_str = f"{cfg.max_position:,.0f}"
        if state:
            loop_status_str = state.loop_status
            pos = state.position
            if pos.up > 0:
                current_pos_str = f"up: {pos.up:,.0f}"
                pos_has_position = True
            elif pos.down > 0:
                current_pos_str = f"down: {pos.down:,.0f}"
                pos_has_position = True
            else:
                current_pos_str = "0"
            if pos.max_allowed > 0:
                max_pos_str = f"{pos.max_allowed:,.0f}"

    config, market = get_detail_market(symbol)

    default_anchor_res = None
    default_data_pack = get_detail_chart_data(symbol, 24)
    if default_data_pack:
        c_sum_def, c_depth_sum_def = default_data_pack
        default_anchor_res = solve_axis(c_sum_def, c_depth_sum_def, 30)

    recommend_pos_str = "-"
    if market is not None:
        oi = market['oi_value_usdc']
        low = oi * 0.05
        high = oi * 0.10
        recommend_pos_str = f"{low:,.0f} ~ {high:,.0f}"

    # ==========================================
    # 标题区
    # ==========================================
    dot_class = "green" if pos_has_position else "gray"
    st.markdown(f"""
    <div class="main-title">🪙 {symbol}</div>
    <div class="sub-title"><span class="dot {dot_class}"></span>{service_name}</div>
    """, unsafe_allow_html=True)

    # ==========================================
    # 第一行：4个核心指标
    # ==========================================
    anchor_open = f"{default_anchor_res['open_bp']}" if default_anchor_res else "-"
    anchor_close = f"{default_anchor_res['close_bp']}" if default_anchor_res else "-"
    stat_open = f"{default_anchor_res['open_cnt']}" if default_anchor_res else "-"
    stat_close = f"{default_anchor_res['close_cnt']}" if default_anchor_res else "-"
    depth_open = f"{default_anchor_res['open_avg_depth']:.0f}" if default_anchor_res else "-"
    depth_close = f"{default_anchor_res['close_avg_depth']:.0f}" if default_anchor_res else "-"

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f"""
        <div class="core-card">
            <div class="label">推荐配置 (开/平)</div>
            <div class="value" style="color:#60a5fa;">{anchor_open} <span style="color:#4b5563;">/</span> {anchor_close}</div>
        </div>
        """, unsafe_allow_html=True)
    with c2:
        st.markdown(f"""
        <div class="core-card">
            <div class="label">推荐仓位</div>
            <div class="value" style="color:#fbbf24; ">{recommend_pos_str}</div>
        </div>
        """, unsafe_allow_html=True)
    with c3:
        st.markdown(f"""
        <div class="core-card">
            <div class="label">深度 (开/平)</div>
            <div class="value" style="color:#e5e7eb;">{depth_open} <span style="color:#4b5563;">/</span> {depth_close}</div>
        </div>
        """, unsafe_allow_html=True)
    with c4:
        st.markdown(f"""
        <div class="core-card">
            <div class="label">统计点数 (开/平)</div>
            <div class="value" style="color:#e5e7eb;">{stat_open} <span style="color:#4b5563;">/</span> {stat_close}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<hr class='divider'>", unsafe_allow_html=True)

    # ==========================================
    # 第二行：交易配置 + 持仓状态
    # ==========================================
    pos_color = "#34d399" if pos_has_position else "#6b7280"
    st.markdown(f"""
    <div class="card">
        <div class="card-title">⚙ 交易配置 & 持仓</div>
        <div class="card-row">
            <div class="card-item">
                <div class="label">UP 开/平</div>
                <div class="value green">{up_oc_str}</div>
            </div>
            <div class="card-item">
                <div class="label">DOWN 开/平</div>
                <div class="value red">{down_oc_str}</div>
            </div>
            <div class="card-item">
                <div class="label">当前持仓</div>
                <div class="value" style="color:{pos_color};">{current_pos_str}</div>
            </div>
            <div class="card-item">
                <div class="label">最大仓位</div>
                <div class="value amber">{max_pos_str}</div>
            </div>
            <div class="card-item">
                <div class="label">循环状态</div>
                <div class="value">{loop_status_str}</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ==========================================
    # 第三行：市场行情卡片 + 费率利差
    # ==========================================
    if market is not None:
        fr_coin = symbol_to_coin(symbol)
        s25 = fr_get_year_stats(fr_coin, 2025)
        s26 = fr_get_year_stats(fr_coin, 2026)

        st.markdown(f"""
        <div class="card">
            <div class="card-title">◈ 市场行情</div>
            <div class="card-row">
                <div class="card-item">
                    <div class="label">价格指数</div>
                    <div class="value blue">{market['price']:.4f}</div>
                </div>
                <div class="card-item">
                    <div class="label">24h 交易额</div>
                    <div class="value">{market['volume_24h_usdc']:,.0f}</div>
                </div>
                <div class="card-item">
                    <div class="label">现有持仓</div>
                    <div class="value">{market['oi_value_usdc']:,.0f}</div>
                </div>
                <div class="card-item">
                    <div class="label">25年利差 | UC | UT</div>
                    <div class="value"><span style="color:#34d399;">{s25['diff']:.1%}</span><br><span style="color:#2775CA;">{s25['uc']:.1%}</span> | <span style="color:#F0B90B;">{s25['ut']:.1%}</span></div>
                </div>
                <div class="card-item">
                    <div class="label">26年利差 | UC | UT</div>
                    <div class="value"><span style="color:#34d399;">{s26['diff']:.1%}</span><br><span style="color:#2775CA;">{s26['uc']:.1%}</span> | <span style="color:#F0B90B;">{s26['ut']:.1%}</span></div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        st.markdown("<hr class='divider'>", unsafe_allow_html=True)

    # ==========================================
    # 图表 Tab 分页
    # ==========================================
    tab_curve, tab_open, tab_close, tab_funding = st.tabs([
        "📈 累积配对曲线",
        "🔴 OPEN 散点图",
        "🟢 CLOSE 散点图",
        "💰 费率"
    ])

    with tab_curve:
        render_curve(symbol)

    with tab_open:
        render_scatter(symbol, side=1, title="OPEN 散点分布")

    with tab_close:
        render_scatter(symbol, side=2, title="CLOSE 散点分布")

    with tab_funding:
        render_funding(symbol)
