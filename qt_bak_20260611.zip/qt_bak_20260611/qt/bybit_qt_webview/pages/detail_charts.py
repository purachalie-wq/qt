import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime, timedelta
from sqlalchemy import text, create_engine

from db import engine
from services import get_detail_chart_data
from algo import solve_axis

# ============================================================
# 📈 累积配对曲线 & 散点图
# ============================================================

def render_curve(symbol):
    """📈 累积配对曲线"""
    col_t, col_s = st.columns([1, 1])
    
    # 时间范围选择 - 使用 radio，去掉标签，修改名称
    with col_t:
        time_label = st.radio(
            "",  # 去掉标签
            ["3小时", "24小时", "7天"],  # 修改名称
            index=1,  # 默认选择"24小时"
            key=f"time_{symbol}",
            horizontal=True  # 水平排列
        )
    
    # 移除了 A+B 强度锚点功能，但保留默认值
    target_sum = 30  # 默认值30

    time_map = {"3小时": 3, "24小时": 24, "7天": 168}
    data_pack = get_detail_chart_data(symbol, time_map[time_label])

    if not data_pack:
        st.warning(f"币种 {symbol} 在此时间段内无数据")
        return

    c_sum, c_depth_sum = data_pack
    _draw_curve(c_sum, c_depth_sum, target_sum)




def _draw_curve(c_sum, c_depth_sum, target_sum):
    all_results = []
    for s in range(10, 101):
        res = solve_axis(c_sum, c_depth_sum, s)
        if res:
            res['sum_val'] = s
            all_results.append(res)

    df_axis = pd.DataFrame(all_results)
    if df_axis.empty:
        st.warning("无法计算配对曲线")
        return

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df_axis['sum_val'], y=df_axis['open_bp'],
        mode='lines+markers', name='Open (A)',
        line=dict(color='#FF4136', width=3),
        customdata=np.column_stack((df_axis['open_cnt'].values, df_axis['open_avg_depth'].values)),
        hovertemplate="Open: %{y} BP<br>点数: %{customdata[0]}<br>深度: %{customdata[1]:.2f}<extra></extra>"
    ))
    fig.add_trace(go.Scatter(
        x=df_axis['sum_val'], y=-df_axis['close_bp'],
        mode='lines+markers', name='Close (B)',
        line=dict(color='#2ECC40', width=3),
        customdata=np.column_stack((df_axis['close_bp'].values, df_axis['close_cnt'].values, df_axis['close_avg_depth'].values)),
        hovertemplate="Close: %{customdata[0]} BP<br>点数: %{customdata[1]}<br>深度: %{customdata[2]:.2f}<extra></extra>"
    ))
    fig.add_vline(x=target_sum, line_width=2, line_dash="dash", line_color="white", opacity=0.8)

    fig.update_layout(
        template="plotly_dark", height=550,
        paper_bgcolor="#000000", plot_bgcolor="#000000",
        hovermode="x unified", font=dict(color="white"),
        xaxis=dict(
            title=dict(text="A + B 总和强度", font=dict(color="white")),
            linecolor="#333", tickfont=dict(color="white")
        ),
        yaxis=dict(
            title=dict(text="BP 设定 (Open正 / Close负)", font=dict(color="white")),
            gridcolor="rgba(255,255,255,0.05)", tickfont=dict(color="white")
        ),
        legend=dict(font=dict(color="white"))
    )
    st.plotly_chart(fig, use_container_width=True)


def render_scatter(symbol, side, title):
    """🔴🟢 散点图
    side: 1=OPEN, 2=CLOSE
    """
    scatter_time = st.radio(
        f"{title} 时间范围",
        ["3小时", "24小时", "7天"],
        index=0, horizontal=True,
        key=f"scatter_time_{symbol}_{side}"
    )

    h_map = {"3小时": 3, "24小时": 24, "7天": 168}
    df_raw = _get_raw_scatter_data(symbol, h_map[scatter_time])

    if df_raw.empty:
        st.info("该范围内暂无数据")
        return

    sub = df_raw[df_raw['side'] == side].copy()
    if sub.empty:
        st.info("该范围内无对应方向的数据")
        return

    fig = go.Figure()
    fig.add_trace(go.Scattergl(
        x=sub['time'], y=sub['bp_avg'],
        mode='markers', name=title, showlegend=False,
        marker=dict(
            size=16, color=sub['depth_avg'],
            colorscale="Turbo", showscale=True, opacity=1.0,
            line=dict(width=0),
            colorbar=dict(
                title=dict(text="Depth", font=dict(color="white")),
                thickness=15, x=1.02, tickfont=dict(color="white")
            )
        ),
        customdata=np.stack((sub['bp_max'], sub['bp_min'], sub['depth_avg']), axis=-1),
        hovertemplate="时间: %{x}<br>价差: %{y:.2f}<br>Max: %{customdata[0]:.2f}<br>Min: %{customdata[1]:.2f}<br>Depth: %{customdata[2]:.2f}<extra></extra>"
    ))

    fig.update_layout(
        template="plotly_dark", height=550,
        paper_bgcolor="#000000", plot_bgcolor="#000000",
        margin=dict(l=20, r=80, t=20, b=20),
        font=dict(color="white"),
        xaxis=dict(
            showgrid=False, tickformat="%H:%M",
            linecolor="#333", zeroline=False, tickfont=dict(color="white")
        ),
        yaxis=dict(
            gridcolor="rgba(255,255,255,0.05)",
            zerolinecolor="#FFFFFF", zerolinewidth=1,
            title=dict(text="价差 (BP)", font=dict(color="white")),
            tickfont=dict(color="white")
        ),
        hovermode="closest"
    )
    st.plotly_chart(fig, use_container_width=True)


def _get_raw_scatter_data(symbol, hours):
    """实时查库，不走缓存"""
    table = f"arb_5s_TREND_{symbol}"
    start_ts = int((datetime.now() - timedelta(hours=hours)).timestamp() * 1000)
    query = text(f"SELECT ts, side, bp_max, bp_min, bp_avg, depth_avg FROM `{table}` WHERE ts >= {start_ts}")
    try:
        with engine.connect() as conn:
            df = pd.read_sql(query, conn)
        if not df.empty:
            df['time'] = pd.to_datetime(df['ts'], unit='ms') + timedelta(hours=8)
        return df
    except Exception as e:
        st.error(f"散点数据查询失败: {e}")
        return pd.DataFrame()


# ============================================================
# 💰 费率图表
# ============================================================

_FR_DB_URI = "mysql+pymysql://FundingRate:sT36Hc2CwPbN8txY@localhost/fundingrate?charset=utf8mb4"
_fr_engine = create_engine(_FR_DB_URI, pool_recycle=3600)


def symbol_to_coin(symbol):
    """与 fr_app_v1 对齐：去掉稳定币后缀"""
    for suffix in ["USDC", "USDT", "USD", "BUSD"]:
        if symbol.upper().endswith(suffix) and len(symbol) > len(suffix):
            return symbol[:-len(suffix)]
    return symbol


@st.cache_data(ttl=300)
def fr_get_year_stats(coin, year):
    ts_map = {2025: (1735689600, 1767225600), 2026: (1767225600, 1798761600)}
    if year not in ts_map:
        return {"diff": 0, "uc": 0, "ut": 0}
    start, end = ts_map[year]
    query = f"SELECT ct_type, value, fr_date FROM bybit WHERE coin=:coin AND fr_timestamp >= {start} AND fr_timestamp < {end}"
    with _fr_engine.connect() as conn:
        df = pd.read_sql(text(query), conn, params={"coin": coin})
    if df.empty:
        return {"diff": 0, "uc": 0, "ut": 0}
    df['date'] = pd.to_datetime(df['fr_date']).dt.date
    res = {'uc': 0, 'ut': 0}
    for t_raw in df['ct_type'].unique():
        sub = df[df['ct_type'] == t_raw]
        apr = (sub['value'].astype(float).sum() / sub['date'].nunique() * 365) if not sub.empty else 0
        key = 'uc' if t_raw.lower() in ['uc', 'usdc'] else 'ut'
        res[key] = apr
    return {"diff": abs(res['uc'] - res['ut']), "uc": res['uc'], "ut": res['ut']}


def render_funding(symbol):
    """💰 费率 Tab —— 只有图表"""
    coin = symbol_to_coin(symbol)

    # ---- Radio：每月/每日 ----
    c_radio, _ = st.columns([3, 2])
    with c_radio:
        if 'fr_view_mode' not in st.session_state:
            st.session_state.fr_view_mode = "每月数据"
        view_mode = st.radio(
            "", ["每月数据", "每日数据"],
            index=0 if st.session_state.fr_view_mode == "每月数据" else 1,
            horizontal=True,
            key=f"fr_view_mode_radio_{symbol}")
        st.session_state.fr_view_mode = view_mode

        fr_page_key = f"fr_page_idx_{symbol}"
        if f'fr_last_view_mode_{symbol}' not in st.session_state or st.session_state[f'fr_last_view_mode_{symbol}'] != view_mode:
            st.session_state[f'fr_last_view_mode_{symbol}'] = view_mode
            st.session_state[fr_page_key] = 1

    # ---- 查询绘图数据 ----
    query = "SELECT ct_type, value, fr_date FROM bybit WHERE coin=:coin AND fr_timestamp >= 1735689600"
    with _fr_engine.connect() as conn:
        df_plot = pd.read_sql(text(query), conn, params={"coin": coin})

    if df_plot.empty:
        st.warning(f"bybit 无 {coin} 费率数据")
        return

    df_plot['dt'] = pd.to_datetime(df_plot['fr_date'])
    df_plot['date_only'] = df_plot['dt'].dt.date
    df_plot['ct_type'] = df_plot['ct_type'].str.lower().replace({
        'uc': 'USDC', 'usdc': 'USDC',
        'ut': 'USDT', 'usdt': 'USDT'
    })

    fig = go.Figure()
    colors = {"USDC": "#2775CA", "USDT": "#F0B90B"}

    if "每日数据" in view_mode:
        if fr_page_key not in st.session_state:
            st.session_state[fr_page_key] = 1

        all_dates = sorted(df_plot['date_only'].unique(), reverse=True)
        page_size = 90
        total_pages = max((len(all_dates) + page_size - 1) // page_size, 1)
        st.session_state[fr_page_key] = max(1, min(st.session_state[fr_page_key], total_pages))

        current_dates = all_dates[
            (st.session_state[fr_page_key] - 1) * page_size: st.session_state[fr_page_key] * page_size
        ]

        res = df_plot[df_plot['date_only'].isin(current_dates)].groupby(['ct_type', 'date_only']).agg({'value': 'sum'}).reset_index()
        res['apr'] = res['value'].astype(float) * 365

        for t in ['USDC', 'USDT']:
            sub = res[res['ct_type'] == t].sort_values('date_only')
            fig.add_trace(go.Scatter(
                x=sub['date_only'], y=sub['apr'],
                name=f"{t} APR", mode='lines+markers',
                line=dict(color=colors[t], width=2)))
    else:
        df_plot['month'] = df_plot['dt'].dt.to_period('M')
        res = df_plot.groupby(['ct_type', 'month']).agg({'value': 'sum', 'date_only': 'nunique'}).reset_index()
        res['apr'] = (res['value'].astype(float) / res['date_only']) * 365
        res['display'] = res['month'].dt.to_timestamp()

        for t in ['USDC', 'USDT']:
            sub = res[res['ct_type'] == t].sort_values('display')
            fig.add_trace(go.Scatter(
                x=sub['display'], y=sub['apr'],
                name=f"{t} 月均APR", mode='lines+markers',
                line=dict(color=colors[t], width=3)))

    fig.update_layout(
        template="plotly_dark", height=500,
        margin=dict(l=0, r=0, t=40, b=10),
        paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
        yaxis=dict(tickformat='.1%', gridcolor='#333'),
        xaxis=dict(gridcolor='#333'),
        hovermode="x unified",
        legend=dict(orientation="h", x=1, xanchor="right", y=1.08, yanchor="top",
                    font=dict(color="#ffffff", size=12)))
    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # ---- 翻页（仅每日） ----
    if "每日数据" in view_mode:
        _, _, _, p_prev, p_info, p_next = st.columns([3, 1, 1, 1, 1, 1])
        with p_prev:
            if st.button("◀ 上一页", key=f"fr_btn_prev_{symbol}"):
                st.session_state[fr_page_key] += 1
                st.rerun()
        with p_next:
            if st.button("下一页 ▶", key=f"fr_btn_next_{symbol}"):
                st.session_state[fr_page_key] -= 1
                st.rerun()
        with p_info:
            st.markdown(
                f"<p style='margin-top:8px; color:#888; text-align:right;'>"
                f"{st.session_state[fr_page_key]} / {total_pages}</p>",
                unsafe_allow_html=True)
