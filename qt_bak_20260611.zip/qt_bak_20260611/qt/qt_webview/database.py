import pymysql
import json
import yaml

class DBManager:
    def __init__(self, config_path='config.yaml'):
        with open(config_path, 'r', encoding='utf-8') as f:
            self.cfg = yaml.safe_load(f)
        self.db_params = self.cfg['database']
        self.fields_definition = self.cfg.get('strategy_fields', [])

    def get_conn(self):
        return pymysql.connect(
            host=self.db_params['host'],
            port=self.db_params['port'],
            user=self.db_params['user'],
            password=self.db_params['password'],
            database=self.db_params['db_name'],
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )

    def fetch_strategies(self, svr_name):
        with self.get_conn() as conn:
            with conn.cursor() as cursor:
                sql = "SELECT * FROM ha_contract_pair WHERE svr_name = %s ORDER BY level DESC"
                cursor.execute(sql, (svr_name,))
                strategies = cursor.fetchall()
                for s in strategies:
                    param_sql = "SELECT config_name, config_value FROM ha_param_config WHERE svr_name=%s AND plat1=%s AND plat2=%s AND symbol1=%s AND symbol2=%s"
                    cursor.execute(param_sql, (s['svr_name'], s['plat1'], s['plat2'], s['symbol1'], s['symbol2']))
                    p_map = {p['config_name']: p['config_value'] for p in cursor.fetchall()}
                    s['max_qty'] = p_map.get('order_max_quantity', '0')
                    s['max_level'] = p_map.get('max_orders_level', '0')
                    try:
                        rate_data = json.loads(p_map.get('min_open_rate', '{"up": 0, "down": 0}'))
                        s['up_rate'] = rate_data.get('up', 0)
                        s['down_rate'] = rate_data.get('down', 0)
                    except:
                        s['up_rate'], s['down_rate'] = '0', '0'
                return strategies

    def fetch_params(self, strategy_id):
        with self.get_conn() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM ha_contract_pair WHERE id = %s", (strategy_id,))
                h = cursor.fetchone()
                if not h: return []
                cursor.execute("SELECT * FROM ha_param_config WHERE svr_name=%s AND plat1=%s AND plat2=%s AND symbol1=%s AND symbol2=%s", 
                               (h['svr_name'], h['plat1'], h['plat2'], h['symbol1'], h['symbol2']))
                db_params = {p['config_name']: p for p in cursor.fetchall()}
                ordered_params = []
                for field in self.fields_definition:
                    name = field['name']
                    db_p = db_params.get(name)
                    ordered_params.append({
                        'id': db_p['id'] if db_p else None,
                        'config_name': name,
                        'display_label': field['label'],
                        'config_value': str(db_p['config_value']) if db_p else str(field.get('default', '')),
                        'strategy_ref': h
                    })
                return ordered_params

    def update_config_value(self, param_id, value, p_data=None):
        with self.get_conn() as conn:
            with conn.cursor() as cursor:
                if param_id:
                    cursor.execute("UPDATE ha_param_config SET config_value = %s WHERE id = %s", (value, param_id))
                elif p_data:
                    m = p_data['strategy_ref']
                    sql = """INSERT INTO ha_param_config (svr_name, plat1, plat2, symbol1, symbol2, 
                             ct_type1, ct_type2, config_name, config_value) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                    cursor.execute(sql, (m['svr_name'], m['plat1'], m['plat2'], m['symbol1'], m['symbol2'], 
                                         m['ct_type1'], m['ct_type2'], p_data['config_name'], value))
            conn.commit()

    def delete_strategy(self, strategy_id):
        with self.get_conn() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT svr_name, plat1, plat2, symbol1, symbol2 FROM ha_contract_pair WHERE id = %s", (strategy_id,))
                info = cursor.fetchone()
                if info:
                    cursor.execute("DELETE FROM ha_param_config WHERE svr_name=%s AND plat1=%s AND plat2=%s AND symbol1=%s AND symbol2=%s", 
                                   (info['svr_name'], info['plat1'], info['plat2'], info['symbol1'], info['symbol2']))
                    cursor.execute("DELETE FROM ha_contract_pair WHERE id = %s", (strategy_id,))
            conn.commit()

    def add_strategy_with_default_config(self, data):
        with self.get_conn() as conn:
            with conn.cursor() as cursor:
                cols = ', '.join(data.keys())
                vals = list(data.values())
                placeholders = ', '.join(['%s'] * len(vals))
                cursor.execute(f"INSERT INTO ha_contract_pair ({cols}) VALUES ({placeholders})", vals)
                if self.fields_definition:
                    sql_param = """INSERT INTO ha_param_config (svr_name, plat1, plat2, symbol1, symbol2, 
                                   ct_type1, ct_type2, config_name, config_value) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                    batch = [(data['svr_name'], data['plat1'], data['plat2'], data['symbol1'], data['symbol2'], 
                              data['ct_type1'], data['ct_type2'], f['name'], str(f['default'])) for f in self.fields_definition]
                    cursor.executemany(sql_param, batch)
            conn.commit()