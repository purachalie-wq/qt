#!/bin/bash

# --- 配置区 ---
APP_NAME="ha_webview.py"
LOG_FILE="log/ha_webview.log"
PYTHON_BIN="python3"

# 确保环境准备就绪
[ ! -d "log" ] && mkdir log

# 1. 查找并杀掉旧进程
PIDS=$(pgrep -f $APP_NAME)

if [ -n "$PIDS" ]; then
    echo "Stopping $APP_NAME (PIDs: $PIDS)..."
    echo $PIDS | xargs kill -9 > /dev/null 2>&1
    sleep 1
fi

# 2. 启动新进程
# 注意：这里我们只把启动时间记入日志，不再把日志打印到屏幕
echo "Starting $APP_NAME..."
echo "--- Restart at $(date '+%Y-%m-%d %H:%M:%S') ---" >> $LOG_FILE

# nohup 启动，且完全静默处理
nohup $PYTHON_BIN $APP_NAME >> $LOG_FILE 2>&1 &

# 3. 快速确认
sleep 1
NEW_PID=$(pgrep -f $APP_NAME)

if [ -n "$NEW_PID" ]; then
    echo "✅ Started successfully. PID: $NEW_PID"
    echo "Done." # 打印完这行，脚本就直接退回命令行了
else
    echo "❌ Start failed! Please check $LOG_FILE"
fi