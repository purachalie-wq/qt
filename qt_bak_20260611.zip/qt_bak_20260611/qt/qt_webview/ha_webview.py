import json
import asyncio
import traceback
from nicegui import ui, app
from database import DBManager
import os

try:
    db = DBManager()
    cfg = db.cfg
except Exception as e:
    print(f"初始化失败: {e}")
    cfg = {'env': {'servers': ['localhost']}, 'field_labels': {}}

state = {
    'server': cfg['env'].get('servers', [''])[0],
    'strategies': [],
    'current_params': [],
    'editing_strategy': None,
    'new_strategy': {'plat1': 'bybit', 'plat2': 'bybit', 'symbol1': '', 'symbol2': '', 'ct_type1': 'ut', 'ct_type2': 'uc', 'level': 3}
}

async def load_data():
    try:
        state['strategies'] = db.fetch_strategies(state['server'])
        strategy_list_ui.refresh()
    except Exception as e:
        ui.notify(f'加载数据失败: {e}', type='negative')

def open_editor(strategy):
    state['editing_strategy'] = strategy
    state['current_params'] = db.fetch_params(strategy['id'])
    render_params.refresh()
    editor_dialog.open()

async def save_params():
    try:
        for p in state['current_params']:
            db.update_config_value(p['id'], str(p['config_value']), p_data=p)
        ui.notify('保存成功', type='positive')
        editor_dialog.close()
    except Exception as e:
        ui.notify(f'保存失败: {e}', type='negative')

async def do_delete(strategy_id, dialog):
    db.delete_strategy(strategy_id)
    ui.notify('策略已删除', type='warning')
    dialog.close()
    await load_data()

async def confirm_delete(strategy):
    with ui.dialog() as confirm_dialog, ui.card().classes('p-4'):
        ui.label(f"确认删除 {strategy['symbol1']} / {strategy['symbol2']} 吗？").classes('text-lg')
        with ui.row().classes('w-full justify-end mt-4'):
            ui.button('取消', on_click=confirm_dialog.close).props('flat')
            ui.button('确认删除', color='red', on_click=lambda: do_delete(strategy['id'], confirm_dialog))
    confirm_dialog.open()

async def create_strategy():
    data = state['new_strategy'].copy()
    data['svr_name'] = state['server']
    if not data['symbol1'] or not data['symbol2']:
        ui.notify('请输入合约名称', type='warning')
        return
    db.add_strategy_with_default_config(data)
    ui.notify('策略创建成功', type='positive')
    add_dialog.close()
    await load_data()

@ui.refreshable
def render_params():
    with ui.column().classes('w-full gap-3 p-2'):
        for p in state['current_params']:
            with ui.column().classes('w-full border-b border-slate-700 pb-2'):
                ui.label(p['display_label']).classes('text-[11px] text-amber-500 font-bold')
                ui.input().bind_value(p, 'config_value').props('dark dense borderless').classes('w-full text-slate-100')

@ui.refreshable
def strategy_list_ui():
    """使用 ui.row 配合 300px 固定宽度实现整齐排列"""
    if not state['strategies']:
        ui.label('暂无策略').classes('mx-auto mt-10 text-slate-500')
        return

    # 改为 row 布局，允许自动换行，并居中展示
    with ui.row().classes('w-full justify-center gap-4'):
        for s in state['strategies']:
            # 强制卡片宽度为 300px
            with ui.card().style('width: 300px').classes('p-3 bg-[#1e293b] border border-slate-700 relative overflow-hidden shadow-lg'):
                
                # 缩小版的删除按钮
                ui.button(icon='delete', on_click=lambda s=s: confirm_delete(s)) \
                    .props('flat round dense color=rose-4').classes('absolute right-0 bottom-0 z-10 scale-50 opacity-60 hover:opacity-100')

                with ui.column().classes('w-full gap-0 cursor-pointer').on('click', lambda s=s: open_editor(s)):
                    # 第一行：LV 标签
                    ui.label(f"LV {s.get('level', 0)}").classes('text-[10px] font-black text-amber-500 tracking-tighter')

                    # 第二行：交易对名称（处理长名称换行）
                    with ui.row().classes('items-center gap-1 w-full'):
                        ui.label(f"{s['symbol1']}").classes('text-[13px] font-bold text-slate-100 truncate max-w-[110px]')
                        ui.label('/').classes('text-slate-600')
                        ui.label(f"{s['symbol2']}").classes('text-[13px] font-bold text-slate-100 truncate max-w-[110px]')

                    # 第三行：参数底栏 (10000 | 10层 | ↑0.3% | ↓0.0%)
                    with ui.row().classes('items-center gap-2 mt-2 text-[11px] font-mono'):
                        ui.label(f"max: {s.get('max_qty', '0')}").classes('font-bold text-blue-400')
                        ui.label('|').classes('text-slate-700')
                        ui.label(f"lv: {s.get('max_level', '0')}").classes('text-indigo-300')
                        ui.label('|').classes('text-slate-700')
                        ui.label(f"up: {s.get('up_rate', '0')}").classes('text-emerald-400')
                        ui.label(f"dn: {s.get('down_rate', '0')}").classes('text-rose-400')

                ui.label(f"#{s['id']}").classes('absolute top-1 right-2 text-[8px] text-slate-600 font-mono')

@ui.page('/')
async def index():
    ui.dark_mode().enable()
    with ui.header().classes('bg-slate-800 items-center justify-between shadow-md'):
        ui.label('Arbitrage System Admin').classes('text-white font-bold ml-2')
        ui.select(cfg['env'].get('servers', []), value=state['server'], on_change=lambda e: (state.update({'server': e.value}), load_data())) \
            .props('dark borderless dense search').classes('w-48 bg-slate-700 rounded px-2 text-sm')

    with ui.column().classes('w-full p-4 pb-24'):
        strategy_list_ui()

    ui.button(icon='add', on_click=lambda: add_dialog.open()).props('fab color=primary').classes('fixed right-6 bottom-6 shadow-xl')

    global editor_dialog, add_dialog
    with ui.dialog() as editor_dialog:
        with ui.card().classes('w-full max-w-lg'):
            with ui.row().classes('w-full justify-between items-center mb-2'):
                ui.label('参数配置').classes('text-xl font-bold')
                ui.button(icon='close', on_click=editor_dialog.close).props('flat round dense')
            with ui.scroll_area().classes('h-[60vh] w-full'): render_params()
            ui.button('保存修改', on_click=save_params).classes('w-full py-2 shadow-md')

    with ui.dialog() as add_dialog:
        with ui.card().classes('w-full max-w-md'):
            ui.label('新增套利交易对').classes('text-xl font-bold mb-4')
            with ui.column().classes('w-full gap-4'):
                ui.input('合约1', on_change=lambda e: state['new_strategy'].update({'symbol1': e.value.upper()})).props('outlined dense').classes('w-full')
                ui.input('合约2', on_change=lambda e: state['new_strategy'].update({'symbol2': e.value.upper()})).props('outlined dense').classes('w-full')
                with ui.row().classes('w-full justify-between'):
                    ui.select(['bybit', 'binance', 'okx', 'bitget'], label='平台1').bind_value(state['new_strategy'], 'plat1').classes('w-[45%]')
                    ui.select(['bybit', 'binance', 'okx', 'bitget'], label='平台2').bind_value(state['new_strategy'], 'plat2').classes('w-[45%]')
                ui.number('优先级 (Level)', format='%.0f').bind_value(state['new_strategy'], 'level').classes('w-full')
            ui.button('提交创建', on_click=create_strategy).classes('w-full mt-6 py-2')

    ui.timer(0.1, load_data, once=True) 

target_port = int(os.environ.get('PORT', cfg['env'].get('web_port', 8080)))
# 强制清理钩子：确保退出时尽可能释放资源
def handle_shutdown():
    print("正在关闭服务，尝试释放端口...")
    # 这里可以加入清理逻辑
    app.on_shutdown(handle_shutdown)

ui.run(host='0.0.0.0', port=target_port, title="HA Admin v2", dark=True, reload=False)