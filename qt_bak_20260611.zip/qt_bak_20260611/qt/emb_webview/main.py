# main.py
from nicegui import ui
from views.funding_view import FundingView
from views.opportunity_view import OpportunityView  # 🌟 引入机会模块视图

funding_view = FundingView()
opportunity_view = OpportunityView()  # 🌟 初始化机会模块视图引擎

@ui.page('/')
def index():
    # ================= [第 1 步] 核心状态变量初始化 =================
    current_exchange = 'bybit'
    current_view = 'list'
    current_coin = None
    current_exchange_opp = 'bybit'  # 🌟 MB 模块独立的内部状态

    # 全局硬核暗黑、零边距重置
    ui.query('body').style('background-color: #000000; color: #ffffff; margin: 0; padding: 0;')
    
    # 【精准无损空间压缩 CSS 补丁】
    ui.add_head_html("""
        <style>
            .q-header .q-icon { display: none !important; }
            .q-header .q-tab { min-height: 32px !important; padding: 0 10px !important; }
            .q-header .q-tabs { min-height: 32px !important; }
            .q-tab-panels { padding-top: 0px !important; }
            .exchange-tabs-row {
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
                height: 32px !important;
                margin-top: 2px !important;
                margin-bottom: 2px !important;
                padding-bottom: 0px !important;
            }
            .exchange-tabs-row .q-tabs { min-height: 28px !important; height: 28px !important; }
            .exchange-tabs-row .q-tab { min-height: 28px !important; height: 28px !important; padding: 0 12px !important; }
            .exchange-tabs-row .q-tab__indicator { bottom: 0px !important; }
            .exchange-tabs-row .q-tab__content { padding: 0px !important; min-height: 28px !important; }
            .grid-cols-2, .grid-cols-5 { gap: 6px !important; margin-top: 4px !important; margin-bottom: 4px !important; }
            .q-card { padding: 4px 8px !important; min-height: auto !important; }
            .q-card .text-sm { margin-top: 2px !important; }
        </style>
    """)

    # ================= [第 2 步] 先声明占位容器引用 (以便函数闭包捕获) =================
    opp_content_container = None
    content_container = None
    opp_exchange_tabs = None
    exchange_tabs = None

    # ================= [第 3 步] 核心业务与刷新函数彻底定义在页首 =================
    
    # --- MB 视图模块逻辑 (方案A：动态组装独立库名、用户名、密码) ---
    def refresh_opp_view():
        if opp_content_container is not None:
            # 🌟 在这里单独配置各自独立的数据库环境参数
            db_configs = {
                'bybit': {
                    'db_name': 'qt',           # 库名 qt
                    'db_user': 'qt',           # 用户名 qt
                    'db_pass': 'sT36Hc2CwPbN8txY'
                },
                'bitget': {
                    'db_name': 'bitget',       # 库名 bitget
                    'db_user': 'bitget',       # 用户名 bitget
                    'db_pass': 'sT36Hc2CwPbN8txY'
                },
                'mexc': {
                    'db_name': 'mexc',         # 库名 mexc
                    'db_user': 'mexc',         # 用户名 mexc
                    'db_pass': 'sT36Hc2CwPbN8txY'
                }
            }
            
            # 获取当前选中平台的独家配置
            cfg = db_configs.get(current_exchange_opp, db_configs['bybit'])
            
            # 拼装出账号、密码、库名各自绝对隔离的 DSN 字符串
            dynamic_dsn = f"mysql+pymysql://{cfg['db_user']}:{cfg['db_pass']}@localhost:3306/{cfg['db_name']}?charset=utf8mb4"
            
            # 将组装好的专属连接直接下发给渲染器
            opportunity_view.render(
                container=opp_content_container,
                plat=current_exchange_opp,
                dsn=dynamic_dsn  # 🌟 动态连接串参数传递
            )

    def change_exchange_opp(exchange_name):
        nonlocal current_exchange_opp
        current_exchange_opp = exchange_name
        refresh_opp_view()

    # --- FR 费率模块逻辑 ---
    def refresh_fr_view():
        if content_container is not None:
            funding_view.render(
                container=content_container,
                plat=current_exchange,
                view_mode=current_view,
                coin=current_coin,
                on_click_coin=go_to_detail,
                on_click_back=go_to_list
            )

    def change_exchange(exchange_name):
        nonlocal current_exchange, current_view, current_coin
        current_exchange = exchange_name
        current_view = 'list'
        current_coin = None
        refresh_fr_view()

    def go_to_detail(coin_name):
        nonlocal current_view, current_coin
        current_view = 'detail'
        current_coin = coin_name
        refresh_fr_view()

    def go_to_list():
        nonlocal current_view, current_coin
        current_view = 'list'
        current_coin = None
        refresh_fr_view()


    # ================= [第 4 步] 开始静态创建 UI 骨架并填充容器 =================
    # 顶部主导航
    with ui.header().classes('items-center justify-between px-6 border-b border-slate-900').style('background-color: #0a0a0a; height: 36px;'):
        with ui.row().classes('items-center gap-2'):
            ui.icon('lan', size='18px').classes('text-emerald-500')
            ui.label('emb').classes('text-sm font-black font-mono tracking-widest text-slate-200')
        
        with ui.tabs() as main_tabs:
            tab_opp = ui.tab('opp', label='mb').classes('text-xs font-bold')
            tab_fr = ui.tab('fr', label='fr').classes('text-xs font-bold')
            tab_cfg = ui.tab('cfg', label='svc').classes('text-xs font-bold')

    with ui.tab_panels(main_tabs, value=tab_fr).classes('w-full bg-transparent max-w-5xl mx-auto p-2') as panels:
        
        # 🌟 MB 交易机会检测面板
        with ui.tab_panel(tab_opp).classes('p-0 gap-2'):
            with ui.row().classes('w-full border-b border-slate-900 exchange-tabs-row'):
                ui.label('MB ➔ 策略推荐看板').classes('text-xs font-mono text-slate-400 font-bold whitespace-nowrap')
                
                opp_exchange_tabs = ui.tabs(value=current_exchange_opp).classes('text-slate-400')
                with opp_exchange_tabs:
                    ui.tab('bybit').classes('text-xs font-mono uppercase')
                    ui.tab('bitget').classes('text-xs font-mono uppercase')
                    ui.tab('mexc').classes('text-xs font-mono uppercase')

            opp_content_container = ui.column().classes('w-full mt-1')
            
        # 🌟 费率面板容器布局
        with ui.tab_panel(tab_fr).classes('p-0 gap-2'):
            with ui.row().classes('w-full border-b border-slate-900 exchange-tabs-row'):
                
                exchange_tabs = ui.tabs(value=current_exchange).classes('text-slate-400')
                with exchange_tabs:
                    ui.tab('binance').classes('text-xs font-mono uppercase')
                    ui.tab('bybit').classes('text-xs font-mono uppercase')
                    ui.tab('okx').classes('text-xs font-mono uppercase')
                    ui.tab('bitget').classes('text-xs font-mono uppercase')

            content_container = ui.column().classes('w-full mt-1')


    # ================= [第 5 步] 动态绑定 Tab 切换事件，并执行初次安全渲染 =================
    opp_exchange_tabs.on_value_change(lambda e: change_exchange_opp(e.value))
    exchange_tabs.on_value_change(lambda e: change_exchange(e.value))

    # 执行初次屏幕渲染 (此时所有函数、容器及动态DSN映射在上下文中已安全就绪)
    refresh_opp_view()
    refresh_fr_view()

ui.run(title='emb_webview Console', port=8506)