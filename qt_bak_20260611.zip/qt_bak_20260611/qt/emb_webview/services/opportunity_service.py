# services/opportunity_service.py
from sqlalchemy import create_engine, text
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
import plotly.graph_objects as go

_QT_DSN = "mysql+pymysql://qt:M6HRcZAasYTjhmWr@127.0.0.1:3306/qt"
_FR_DSN = "mysql+pymysql://FundingRate:sT36Hc2CwPbN8txY@localhost/fundingrate?charset=utf8mb4"

qt_engine = create_engine(_QT_DSN, pool_recycle=3600)
fr_engine = create_engine(_FR_DSN, pool_recycle=3600)

class OpportunityService:
    _engines = {}

    @classmethod
    def _get_engine(cls, dsn: str):
        if dsn not in cls._engines:
            cls._engines[dsn] = create_engine(dsn, pool_recycle=3600, pool_size=5, max_overflow=10)
        return cls._engines[dsn]

    @staticmethod
    def symbol_to_coin(symbol: str) -> str:
        for suffix in ["USDC", "USDT", "USD", "BUSD"]:
            if symbol.upper().endswith(suffix) and len(symbol) > len(suffix):
                return symbol[:-len(suffix)]
        return symbol

    @classmethod
    def get_sorted_opportunities(cls, client_dsn: str) -> list:
        engines_to_try = [cls._get_engine(client_dsn), qt_engine] if client_dsn else [qt_engine]
        df = pd.DataFrame()
        for engine in engines_to_try:
            for table in ["strategy_recommendations", "opportunities"]:
                try:
                    sql = f"SELECT * FROM {table} ORDER BY ts_created DESC LIMIT 30;"
                    with engine.connect() as conn:
                        df = pd.read_sql(text(sql), conn)
                    if not df.empty: break
                except: continue
            if not df.empty: break

        if df.empty: return []
        raw_rows = []
        for _, row in df.iterrows():
            ts = row.get('ts_created')
            formatted_time = datetime.fromtimestamp(ts / 1000 if ts > 1e11 else ts).strftime('%Y-%m-%d %H:%M:%S') if ts else '---'
            o_val = row.get('open_cnt')
            c_val = row.get('close_cnt')
            raw_rows.append({
                'symbol': str(row.get('symbol', 'UNKNOWN')).upper(),
                'open_cnt': o_val if o_val is not None else '--',
                'close_cnt': c_val if c_val is not None else '--',
                'ts_created': formatted_time,
                '_sort_key': (o_val if o_val else 0) + (c_val if c_val else 0)
            })
        return sorted(raw_rows, key=lambda x: x['_sort_key'], reverse=True)

    @classmethod
    def get_market_metrics(cls, symbol: str) -> dict:
        res = {"price": 0.0, "volume_24h": 0.0, "oi_value": 0.0}
        query = "SELECT price, volume_24h_usdc, oi_value_usdc FROM market_metrics WHERE symbol=:s ORDER BY ts DESC LIMIT 1"
        try:
            with qt_engine.connect() as conn:
                df = pd.read_sql(text(query), conn, params={"s": symbol})
                if not df.empty:
                    res["price"] = float(df.iloc[0]['price'])
                    res["volume_24h"] = float(df.iloc[0]['volume_24h_usdc'])
                    res["oi_value"] = float(df.iloc[0]['oi_value_usdc'])
        except: pass
        return res

    @classmethod
    def get_year_stats(cls, coin: str, year: int) -> dict:
        ts_map = {2025: (1735689600, 1767225600), 2026: (1767225600, 1798761600)}
        if year not in ts_map: return {"diff": 0.0, "uc": 0.0, "ut": 0.0}
        start, end = ts_map[year]
        query = f"SELECT ct_type, value, fr_date FROM bybit WHERE coin=:coin AND fr_timestamp >= {start} AND fr_timestamp < {end}"
        try:
            with fr_engine.connect() as conn:
                df = pd.read_sql(text(query), conn, params={"coin": coin})
            if df.empty: return {"diff": 0.0, "uc": 0.0, "ut": 0.0}
            df['date'] = pd.to_datetime(df['fr_date']).dt.date
            res = {'uc': 0.0, 'ut': 0.0}
            for t_raw in df['ct_type'].unique():
                sub = df[df['ct_type'] == t_raw]
                apr = (sub['value'].astype(float).sum() / sub['date'].nunique() * 365) if not sub.empty else 0.0
                res['uc' if t_raw.lower().strip() in ['uc', 'usdc'] else 'ut'] = apr
            return {"diff": abs(res['uc'] - res['ut']), "uc": res['uc'], "ut": res['ut']}
        except: return {"diff": 0.0, "uc": 0.0, "ut": 0.0}

    @classmethod
    def build_opportunity_curve(cls, symbol: str, hours: int) -> go.Figure:
        fig = go.Figure()
        ts_limit = int((time.time() - (hours * 3600)) * 1000)
        table_name = f"arb_5s_TREND_{symbol}"
        query = f"SELECT side, ROUND(bp_avg) as bp, COUNT(*) as cnt, SUM(depth_avg) as sum_depth FROM `{table_name}` WHERE ts >= :ts AND bp_avg BETWEEN -20 AND 100 GROUP BY side, ROUND(bp_avg)"
        
        try:
            with qt_engine.connect() as conn:
                df = pd.read_sql(text(query), conn, params={"ts": ts_limit})
            if df.empty:
                fig.update_layout(template="plotly_dark", title="暂无配对曲线数据")
                return fig

            bp_range = range(-20, 101)
            c_sum = {1: {b: 0 for b in bp_range}, 2: {b: 0 for b in bp_range}}

            for side in [1, 2]:
                side_df = df[df['side'] == side].set_index('bp')
                accum_cnt = 0
                for b in sorted(bp_range, reverse=True):
                    accum_cnt += int(side_df.loc[b, 'cnt']) if b in side_df.index else 0
                    c_sum[side][b] = accum_cnt

            all_results = []
            for s in range(10, 101):
                best_a, min_diff = None, float('inf')
                for a in range(-10, s + 11):
                    b = s - a
                    if a not in c_sum[1] or b not in c_sum[2]: continue
                    cnt1, cnt2 = c_sum[1][a], c_sum[2][b]
                    if cnt1 == 0 and cnt2 == 0: continue
                    diff = abs(cnt1 - cnt2)
                    if diff < min_diff:
                        min_diff, best_a = diff, a
                if best_a is not None:
                    all_results.append({"sum_val": s, "open_bp": best_a, "close_bp": s - best_a})

            df_axis = pd.DataFrame(all_results)
            if not df_axis.empty:
                fig.add_trace(go.Scatter(x=df_axis['sum_val'], y=df_axis['open_bp'], mode='lines+markers', name='Open (A)', line=dict(color='#FF4136', width=2.5)))
                fig.add_trace(go.Scatter(x=df_axis['sum_val'], y=-df_axis['close_bp'], mode='lines+markers', name='Close (B)', line=dict(color='#2ECC40', width=2.5)))
        except Exception as e: print(e)
        fig.update_layout(template="plotly_dark", height=400, margin=dict(l=40, r=20, t=20, b=30), paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
        return fig

    @classmethod
    def build_scatter_chart(cls, symbol: str, hours: int) -> go.Figure:
        fig = go.Figure()
        table_name = f"arb_5s_TREND_{symbol}"
        start_ts = int((time.time() - (hours * 3600)) * 1000)
        scatter_sql = f"SELECT ts, side, bp_avg FROM `{table_name}` WHERE ts >= {start_ts} AND bp_avg BETWEEN -20 AND 100 ORDER BY ts DESC LIMIT 1500"
        try:
            with qt_engine.connect() as conn:
                df = pd.read_sql(text(scatter_sql), conn)
            if not df.empty:
                df['time'] = pd.to_datetime(df['ts'], unit='ms') + timedelta(hours=8)
                for side_id, name, color in [(1, 'OPEN', '#FF4136'), (2, 'CLOSE', '#2ECC40')]:
                    sub = df[df['side'] == side_id]
                    if not sub.empty:
                        fig.add_trace(go.Scatter(x=sub['time'], y=sub['bp_avg'], mode='markers', name=name, marker=dict(size=6, color=color, opacity=0.7)))
        except Exception as e: print(e)
        fig.update_layout(template="plotly_dark", height=400, margin=dict(l=40, r=20, t=20, b=30), paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
        return fig

    @classmethod
    def build_funding_chart(cls, coin: str, mode: str, month_offset: int = 0) -> tuple:
        fig = go.Figure()
        fr_sql = "SELECT ct_type, value, fr_date FROM bybit WHERE coin=:coin AND fr_timestamp >= 1735689600"
        try:
            with fr_engine.connect() as conn:
                df = pd.read_sql(text(fr_sql), conn, params={"coin": coin})
            if df.empty:
                fig.update_layout(template="plotly_dark", height=400)
                return fig, [], "无数据"

            df['dt'] = pd.to_datetime(df['fr_date'])
            df['month_str'] = df['dt'].dt.strftime('%Y-%m')
            available_months = sorted(df['month_str'].unique())
            colors = {"uc": "#2775CA", "ut": "#F0B90B"}

            if mode == '按月':
                df['month'] = df['dt'].dt.to_period('M')
                res = df.groupby(['ct_type', 'month']).agg({'value': 'sum', 'fr_date': 'nunique'}).reset_index()
                res['apr'] = (res['value'].astype(float) / res['fr_date']) * 365
                res['display'] = res['month'].dt.to_timestamp()
                for t in ['uc', 'ut']:
                    sub = res[res['ct_type'].str.lower().str.strip() == t].sort_values('display')
                    if not sub.empty:
                        fig.add_trace(go.Scatter(x=sub['display'], y=sub['apr'], name=f"{t.upper()} 月均APR", mode='lines+markers', line=dict(color=colors[t], width=2.5)))
                fig.update_layout(template="plotly_dark", height=400, margin=dict(l=40, r=20, t=20, b=30), paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
                return fig, available_months, "全量月份"
            else:
                if not available_months: return fig, [], "无可用月份"
                idx = max(0, min(len(available_months) - 1, len(available_months) - 1 + month_offset))
                target_month = available_months[idx]
                
                sub_month = df[df['month_str'] == target_month].copy()
                sub_month['apr'] = sub_month['value'].astype(float) * 365
                for t in ['uc', 'ut']:
                    sub = sub_month[sub_month['ct_type'].str.lower().str.strip() == t].sort_values('dt')
                    if not sub.empty:
                        fig.add_trace(go.Scatter(x=sub['dt'], y=sub['apr'], name=f"{t.upper()} 每日单次APR", mode='lines+markers', line=dict(color=colors[t], width=2)))
                fig.update_layout(template="plotly_dark", height=400, margin=dict(l=40, r=20, t=20, b=30), paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
                return fig, available_months, target_month
        except Exception as e:
            fig.update_layout(template="plotly_dark", height=400)
            return fig, [], "错误"