# views/funding_view.py
from nicegui import ui
import pandas as pd
import plotly.graph_objects as go
from sqlalchemy import create_engine, text
import ccxt
from datetime import datetime

# ==========================================
# 🌟 请在这里填入您本地正确的 MySQL 密码
# ==========================================
DB_USER = 'FundingRate'       # 您的 MySQL 用户名
DB_PASS = 'sT36Hc2CwPbN8txY'  # 您的 MySQL 密码
DB_HOST = 'localhost'
DB_NAME = 'fundingrate'       # 您的主数据库名
# ==========================================

class FundingView:
    def __init__(self):
        import urllib.parse
        safe_pass = urllib.parse.quote_plus(DB_PASS)
        conn_str = f'mysql+pymysql://{DB_USER}:{safe_pass}@{DB_HOST}/{DB_NAME}?charset=utf8mb4'
        self.engine = create_engine(conn_str)
        
        self.ccxt_clients = {
            'binance': ccxt.binance(), 'bybit': ccxt.bybit(), 
            'okx': ccxt.okx(), 'bitget': ccxt.bitget()
        }
        self.chart_mode = 'month'
        self.selected_month = datetime.now().strftime('%Y-%m') 
        self.chart_container = None 
        self.pager_container = None 

    def get_realtime_info(self, plat, coin):
        """抓取币种实时行情"""
        try:
            client = self.ccxt_clients.get(plat.lower())
            if not client: return {"price": "N/A", "vol": "N/A", "oi": "N/A"}
            symbol = f"{coin}/USDC:USDC"
            ticker = client.fetch_ticker(symbol)
            price = ticker['last']
            vol_24h = ticker['quoteVolume']
            try:
                oi_data = client.fetch_open_interest(symbol)
                oi_val = (oi_data['openInterestAmount'] * price) if oi_data['openInterestAmount'] else 0
            except:
                oi_val = 0
            return {
                "price": f"${price:,.4f}" if isinstance(price, (int, float)) else "N/A",
                "vol": f"{vol_24h:,.0f}" if isinstance(vol_24h, (int, float)) else "N/A",
                "oi": f"{oi_val:,.0f}" if oi_val > 0 else "N/A"
            }
        except:
            return {"price": "N/A", "vol": "N/A", "oi": "N/A"}

    def fetch_dashboard_data(self, engine, plat):
        """双本位汇总利差引擎"""
        current_month_str = datetime.now().strftime('%Y-%m')
        
        yearly_query = """
            SELECT `coin`,
                   MAX(CASE WHEN LOWER(`ct_type`) = 'uc' THEN `annualized_rate` END) AS `uc_rate`,
                   MAX(CASE WHEN LOWER(`ct_type`) = 'ut' THEN `annualized_rate` END) AS `ut_rate`
            FROM `summary_funding_yearly`
            WHERE LOWER(`plat`) = LOWER(:plat) 
              AND `year` = 2026 
              AND LOWER(`ct_type`) IN ('uc', 'ut')
            GROUP BY `coin`
            HAVING COUNT(CASE WHEN LOWER(`ct_type`) = 'uc' THEN 1 END) > 0
        """
        
        monthly_query = """
            SELECT `coin`,
                   MAX(CASE WHEN LOWER(`ct_type`) = 'uc' THEN `annualized_rate` END) AS `uc_rate`,
                   MAX(CASE WHEN LOWER(`ct_type`) = 'ut' THEN `annualized_rate` END) AS `ut_rate`
            FROM `summary_funding_monthly`
            WHERE LOWER(`plat`) = LOWER(:plat)
              AND `year_month` = :current_month
              AND LOWER(`ct_type`) IN ('uc', 'ut')
            GROUP BY `coin`
            HAVING COUNT(CASE WHEN LOWER(`ct_type`) = 'uc' THEN 1 END) > 0
        """
        
        with engine.connect() as conn:
            df_year_raw = pd.read_sql(text(yearly_query), conn, params={"plat": plat.lower()})
            df_month_raw = pd.read_sql(text(monthly_query), conn, params={"plat": plat.lower(), "current_month": current_month_str})
            
        df_year = pd.DataFrame(columns=['coin', 'rate_2026'])
        if not df_year_raw.empty:
            df_year_raw['uc_rate'] = pd.to_numeric(df_year_raw['uc_rate'], errors='coerce')
            df_year_raw['ut_rate'] = pd.to_numeric(df_year_raw['ut_rate'], errors='coerce').fillna(0.0)
            valid_mask = df_year_raw['uc_rate'].notna()
            df_year = df_year_raw[valid_mask].copy()
            df_year['rate_2026'] = df_year['uc_rate'] - df_year['ut_rate']
            df_year = df_year[['coin', 'rate_2026']]

        df_month = pd.DataFrame(columns=['coin', 'rate_current_month'])
        if not df_month_raw.empty:
            df_month_raw['uc_rate'] = pd.to_numeric(df_month_raw['uc_rate'], errors='coerce')
            df_month_raw['ut_rate'] = pd.to_numeric(df_month_raw['ut_rate'], errors='coerce').fillna(0.0)
            valid_mask = df_month_raw['uc_rate'].notna()
            df_month = df_month_raw[valid_mask].copy()
            df_month['rate_current_month'] = df_month_raw['uc_rate'] - df_month_raw['ut_rate']
            df_month = df_month[['coin', 'rate_current_month']]

        if df_year.empty and df_month.empty:
            return pd.DataFrame()

        df_main = pd.merge(df_year, df_month, on='coin', how='outer')
        df_main['sort_key'] = df_main['rate_2026'].fillna(df_main['rate_current_month']).fillna(0.0).abs()
        df_main = df_main.sort_values(by='sort_key', ascending=False).drop(columns=['sort_key'])
        return df_main

    def render(self, container, plat, view_mode, coin, on_click_coin, on_click_back):
        if not container: return
        container.clear()
        
        engine = self.engine 

        with container:
            # 💡 强制注入一条组件级别 CSS，把 Quasar 内部的单选容器彻底打平为横向 flex，不留任何堆叠死角
            ui.add_head_html("""
                <style>
                    .force-inline-radio .q-option-group {
                        display: flex !important;
                        flex-direction: row !important;
                        flex-wrap: nowrap !important;
                        gap: 16px !important;
                    }
                    .force-inline-radio .q-radio {
                        margin-right: 0px !important;
                    }
                </style>
            """)

            if view_mode == 'list':
                self.chart_mode = 'month'
                self.selected_month = datetime.now().strftime('%Y-%m') 
                
                ui.markdown(f"FR看板").classes('text-slate-200 font-mono font-bold mt-2')
                
                df_dash = self.fetch_dashboard_data(engine, plat)
                if df_dash.empty:
                    ui.label(f'⚠️ 当前平台 {plat.upper()} 未检测到当月有效双本位数据(须含UC)').classes('text-amber-500 font-mono p-4 text-xs')
                    return

                with ui.element('div').classes('w-full border border-slate-900 rounded-lg overflow-hidden bg-slate-950 font-mono text-xs'):
                    with ui.row().classes('w-full bg-slate-900/50 p-3 text-slate-500 font-bold border-b border-slate-900 text-center items-center no-wrap'):
                        ui.label('币种').classes('w-1/3 text-left pl-6')
                        ui.label('2026 利差 (UC - UT)').classes('w-1/3')
                        ui.label('当月利差 (UC - UT)').classes('w-1/3')

                    for _, row in df_dash.iterrows():
                        c_name = row['coin']
                        r26 = row['rate_2026']
                        r_month = row['rate_current_month']
                        
                        str_26 = f"{r26:.4f}%" if pd.notna(r26) else "-"
                        str_month = f"{r_month:.4f}%" if pd.notna(r_month) else "-"
                        
                        with ui.row().classes('w-full p-3 border-b border-slate-900/40 hover:bg-slate-900/30 text-center items-center no-wrap'):
                            with ui.element('div').classes('w-1/3 text-left pl-4'):
                                ui.button(c_name, on_click=lambda target_coin=c_name: on_click_coin(target_coin))\
                                    .props('dark dense flat')\
                                    .classes('text-emerald-400 font-bold text-sm font-mono tracking-wide rounded hover:bg-slate-900 m-0 p-1')
                            
                            ui.label(str_26).classes('w-1/3 text-emerald-400 font-bold' if str_26 != "-" else 'w-1/3 text-slate-600')
                            ui.label(str_month).classes('w-1/3 text-amber-500 font-bold' if str_month != "-" else 'w-1/3 text-slate-600')

            elif view_mode == 'detail' and coin:
                # 🌟【核心修复】改用 grid 强制划分空间，并结合 CSS 类确保右侧单选万无一失绝对横排
                with ui.grid(columns='1fr auto').classes('w-full items-center mb-4 pb-2 border-b border-slate-900/60 no-wrap'):
                    
                    # 左侧：面包屑与返回
                    with ui.row().classes('items-center gap-3 no-wrap'):
                        ui.button('◀ 返回', on_click=lambda: on_click_back())\
                            .props('dark dense outline').classes('text-xs text-slate-400 border-slate-800 bg-slate-900 px-3 py-1')
                        ui.label(f'{plat.upper()} ➔ {coin} ').classes('text-xs font-mono text-slate-400 font-bold whitespace-nowrap')
                    
                    # 右侧：使用强制 inline 属性以及独占 class，绝不换行堆叠
                    with ui.element('div').classes('force-inline-radio'):
                        ui.radio(
                            {'month': '月', 'day': '日'}, 
                            value=self.chart_mode,
                            on_change=lambda e: self.update_chart_mode(engine, plat, coin, e.value)
                        ).props('inline dark').classes('text-xs font-mono text-slate-400 m-0 p-0')

                rt = self.get_realtime_info(plat, coin)
                current_month_str = datetime.now().strftime('%Y-%m')
                
                with engine.connect() as conn:
                    y_rows = conn.execute(
                        text("SELECT `ct_type`, `annualized_rate` FROM `summary_funding_yearly` WHERE LOWER(`plat`)=LOWER(:plat) AND `coin`=:coin AND `year`=2026 AND LOWER(`ct_type`) IN ('uc', 'ut')"),
                        {"plat": plat, "coin": coin}
                    ).fetchall()
                    
                    m_rows = conn.execute(
                        text("SELECT `ct_type`, `annualized_rate` FROM `summary_funding_monthly` WHERE LOWER(`plat`)=LOWER(:plat) AND `coin`=:coin AND `year_month`=:current_month AND LOWER(`ct_type`) IN ('uc', 'ut')"),
                        {"plat": plat, "coin": coin, "current_month": current_month_str}
                    ).fetchall()
                
                y_map = {r[0].lower(): float(r[1]) for r in y_rows if r[1] is not None}
                m_map = {r[0].lower(): float(r[1]) for r in m_rows if r[1] is not None}
                
                has_y_uc = 'uc' in y_map
                has_m_uc = 'uc' in m_map
                
                det_26_diff = y_map.get('uc', 0.0) - y_map.get('ut', 0.0) if has_y_uc else None
                det_month_diff = m_map.get('uc', 0.0) - m_map.get('ut', 0.0) if has_m_uc else None

                str_det_26 = f"{det_26_diff:.4f}%" if det_26_diff is not None else "-"
                str_det_month = f"{det_month_diff:.4f}%" if det_month_diff is not None else "-"

                with ui.row().classes('w-full gap-2 mb-4 grid grid-cols-2 md:grid-cols-5 text-center font-mono text-xs'):
                    with ui.card().classes('bg-slate-950 border border-slate-900 p-2 gap-0'):
                        ui.label('当前均价').classes('text-slate-500 text-[10px]')
                        ui.label(rt['price']).classes('text-white font-bold text-sm mt-1')
                    with ui.card().classes('bg-slate-950 border border-slate-900 p-2 gap-0'):
                        ui.label('24H成交(U)').classes('text-slate-500 text-[10px]')
                        ui.label(rt['vol']).classes('text-white font-bold text-sm mt-1')
                    with ui.card().classes('bg-slate-950 border border-slate-900 p-2 gap-0'):
                        ui.label('持仓量(U)').classes('text-slate-500 text-[10px]')
                        ui.label(rt['oi']).classes('text-white font-bold text-sm mt-1')
                    with ui.card().classes('bg-slate-950 border border-slate-900 p-2 gap-0'):
                        ui.label('2026年利差|UC|UT').classes('text-slate-500 text-[10px]')
                        ui.label(str_det_26).classes('text-emerald-400 font-bold text-sm mt-0.5' if str_det_26 != "-" else 'text-slate-600 font-bold text-sm mt-0.5')
                        if has_y_uc:
                            ui.label(f"{y_map.get('uc', 0.0):.2f}%|{y_map.get('ut', 0.0):.2f}%").classes('text-[10px] text-slate-500')
                    with ui.card().classes('bg-slate-950 border border-slate-900 p-2 gap-0'):
                        ui.label(f'本月利差({current_month_str})').classes('text-slate-500 text-[10px]')
                        ui.label(str_det_month).classes('text-amber-500 font-bold text-sm mt-0.5' if str_det_month != "-" else 'text-slate-600 font-bold text-sm mt-0.5')
                        if has_m_uc:
                            ui.label(f"{m_map.get('uc', 0.0):.2f}%|{m_map.get('ut', 0.0):.2f}%").classes('text-[10px] text-slate-500')

                self.chart_container = ui.column().classes('w-full mt-2')
                self.pager_container = ui.column().classes('w-full mt-1')
                
                self.render_dimension_charts(engine, plat, coin)

    def update_chart_mode(self, engine, plat, coin, new_mode):
        self.chart_mode = new_mode
        self.render_dimension_charts(engine, plat, coin)

    def shift_month(self, engine, plat, coin, delta):
        try:
            dt = datetime.strptime(f"{self.selected_month}-01", "%Y-%m-%d")
            if delta == -1:
                new_dt = dt if dt.month > 1 else dt.replace(year=dt.year-1, month=12)
                if dt.month > 1: new_dt = dt.replace(month=dt.month-1)
            else:
                new_dt = dt if dt.month < 12 else dt.replace(year=dt.year+1, month=1)
                if dt.month < 12: new_dt = dt.replace(month=dt.month+1)
                
            self.selected_month = new_dt.strftime('%Y-%m')
            self.render_dimension_charts(engine, plat, coin)
        except:
            pass

    def render_dimension_charts(self, engine, plat, coin):
        if not self.chart_container: return
        self.chart_container.clear()
        self.pager_container.clear()

        if self.chart_mode == 'day':
            query = f"""
                SELECT `ct_type`, `value`, `fr_date` 
                FROM `{plat.lower()}` 
                WHERE `coin` = :coin AND `fr_date` LIKE :month_pattern
            """
            month_pattern = f"{self.selected_month}-%"
            params = {"coin": coin, "month_pattern": month_pattern}
        else:
            query = f"""
                SELECT `ct_type`, `value`, `fr_date` 
                FROM `{plat.lower()}` 
                WHERE `coin` = :coin AND `fr_timestamp` >= 1735689600
            """
            params = {"coin": coin}

        with engine.connect() as conn:
            df_plot = pd.read_sql(text(query), conn, params=params)
            
        if df_plot.empty:
            with self.chart_container:
                ui.label(f'⚠️ 该币种在 {self.selected_month} 毫无流水数据' if self.chart_mode == 'day' else '⚠️ 该币种历史无数据').classes('text-slate-600 font-mono p-4 text-xs')
            if self.chart_mode == 'day': self.inject_month_pager(engine, plat, coin)
            return

        df_plot['value'] = pd.to_numeric(df_plot['value'], errors='coerce').fillna(0.0)
        df_plot['dt'] = pd.to_datetime(df_plot['fr_date'])
        df_plot['date_only'] = df_plot['dt'].dt.date
        df_plot['ct_type'] = df_plot['ct_type'].str.lower().replace({'uc':'USDC','usdc':'USDC','ut':'USDT','usdt':'USDT'})

        fig = go.Figure()
        colors = {"USDC": "#2775CA", "USDT": "#F0B90B"}

        if self.chart_mode == 'day':
            res = df_plot.groupby(['ct_type', 'date_only']).agg({'value': 'sum'}).reset_index()
            res['apr'] = res['value'].astype(float) * 365
            x_axis_col = 'date_only'
            trace_suffix = "每日 APR"
            self.inject_month_pager(engine, plat, coin)
        else:
            df_plot['month'] = df_plot['dt'].dt.to_period('M')
            res = df_plot.groupby(['ct_type', 'month']).agg({'value': 'sum', 'date_only': 'nunique'}).reset_index()
            res['apr'] = (res['value'].astype(float) / res['date_only']) * 365
            res['display'] = res['month'].dt.to_timestamp()
            x_axis_col = 'display'
            trace_suffix = "月均 APR"

        for t in ['USDC', 'USDT']:
            sub = res[res['ct_type'] == t].sort_values(x_axis_col)
            if not sub.empty:
                fig.add_trace(go.Scatter(
                    x=sub[x_axis_col], 
                    y=sub['apr'], 
                    name=f"{t} {trace_suffix}", 
                    mode='lines+markers', 
                    line=dict(color=colors[t], width=2 if self.chart_mode == 'day' else 3)
                ))

        # 🌟【核心修复】统一对全局悬浮提示窗进行严苛的暗黑配置，保证 x unified 触发时也保持全黑背景色
        fig.update_layout(
            template="plotly_dark", height=420, margin=dict(l=10, r=10, t=30, b=10),
            paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
            yaxis=dict(tickformat='.2%', gridcolor='#222222'), xaxis=dict(gridcolor='#222222'),
            hovermode="x unified",
            hoverlabel=dict(
                bgcolor="#090d16",          # 强行注入统一暗黑底色
                bordercolor="#1e293b",      # 暗灰色边框
                font_size=12, 
                font_color="#ffffff",       # 文字保持纯白
                font_family="monospace"
            ),
            legend=dict(orientation="h", x=1, xanchor="right", y=1.12, yanchor="top", font=dict(color="#ffffff", size=11))
        )
        
        with self.chart_container:
            with ui.card().classes('w-full bg-slate-950 border border-slate-900 p-2'):
                ui.plotly(fig).classes('w-full')

    def inject_month_pager(self, engine, plat, coin):
        """注入简单干净的月份导航条"""
        with self.pager_container:
            with ui.row().classes('w-full justify-end items-center gap-4 px-2 font-mono text-xs text-slate-400 mt-2'):
                ui.button("◀ 上个月", on_click=lambda: self.shift_month(engine, plat, coin, -1))\
                    .props('dark dense outline').classes('text-slate-400 border-slate-800 bg-slate-950 px-2')
                
                ui.label(f"📅 当前月份: {self.selected_month}").classes('text-amber-500 font-bold tracking-wide text-sm')
                
                ui.button("下个月 ▶", on_click=lambda: self.shift_month(engine, plat, coin, 1))\
                    .props('dark dense outline').classes('text-slate-400 border-slate-800 bg-slate-950 px-2')