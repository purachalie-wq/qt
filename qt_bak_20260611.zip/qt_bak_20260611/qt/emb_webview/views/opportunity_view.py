# views/opportunity_view.py
from nicegui import ui
from services.opportunity_service import OpportunityService

class OpportunityView:
    def __init__(self):
        self.state = {
            'opp_hours': 24,
            'scatter_hours': 3,
            'funding_mode': '按月',
            'month_offset': 0
        }

    def render(self, container, plat, **kwargs):
        container.clear()
        client_dsn = kwargs.get('dsn', '')
        with container:
            try:
                rows = OpportunityService.get_sorted_opportunities(client_dsn)
                if not rows:
                    ui.label(f"⚠️ 暂无 [{plat.upper()}] 策略机会推荐数据...").classes('text-xs font-mono text-slate-500 p-4')
                    return

                columns = [
                    {'name': 'symbol', 'label': 'SYMBOL (点击穿透全屏大看板)', 'field': 'symbol', 'align': 'left', 'sortable': True},
                    {'name': 'open_cnt', 'label': 'OPEN CNT', 'field': 'open_cnt', 'align': 'right', 'sortable': True},
                    {'name': 'close_cnt', 'label': 'CLOSE CNT', 'field': 'close_cnt', 'align': 'right', 'sortable': True},
                    {'name': 'ts_created', 'label': 'CREATED TIME', 'field': 'ts_created', 'align': 'center', 'sortable': True}
                ]
                table = ui.table(columns=columns, rows=rows, row_key='symbol').classes('w-full dense font-mono text-xs')
                table.style('background-color: #000000; color: #e2e8f0; border: 1px solid #0f172a; --q-table-border-color: #0f172a;')
                table.add_slot('body-cell-symbol', '''
                    <q-td :props="props">
                        <span class="text-blue-400 font-bold cursor-pointer hover:underline" @click="() => $parent.$emit('action', {symbol: props.row.symbol})">
                            🪙 {{ props.value }}
                        </span>
                    </q-td>
                ''')
                table.on('action', lambda msg: self.show_detail_dialog(msg.args.get('symbol')))
            except Exception as e:
                ui.label(f"❌ 表格异常: {str(e)}").classes('text-rose-500 font-mono text-xs p-4')

    def show_detail_dialog(self, symbol):
        if not symbol: return
        coin = OpportunityService.symbol_to_coin(symbol)
        market = OpportunityService.get_market_metrics(symbol)
        s25 = OpportunityService.get_year_stats(coin, 2025)
        s26 = OpportunityService.get_year_stats(coin, 2026)

        self.state['opp_hours'] = 24
        self.state['scatter_hours'] = 3
        self.state['funding_mode'] = '按月'
        self.state['month_offset'] = 0

        with ui.dialog().props('full-width') as dialog:
            with ui.card().classes('bg-[#0a0a0f] text-slate-200 p-6 border border-slate-800 mx-auto').style('width: 94vw; max-width: 96vw;'):
                
                with ui.row().classes('w-full justify-between items-center border-b border-slate-900 pb-2'):
                    ui.label(f"🪙 {symbol} 量化透视看板").classes('text-lg font-bold font-mono text-emerald-400')
                    ui.button('关闭', on_click=dialog.close).props('flat dense').classes('text-slate-400 font-mono text-xs')

                # 看板四元组
                with ui.grid(columns=4).classes('w-full gap-4 my-2 font-mono'):
                    with ui.card().classes('bg-[#111118] border border-slate-900 p-3 text-center'):
                        ui.label('推荐配置 (开/平)').classes('text-[10px] text-slate-500')
                        ui.label('- / -').classes('text-base font-bold text-blue-400')
                    with ui.card().classes('bg-[#111118] border border-slate-900 p-3 text-center'):
                        ui.label('推荐仓位范围').classes('text-[10px] text-slate-500')
                        oi_val = market["oi_value"]
                        ui.label(f"{oi_val*0.05:,.0f} ~ {oi_val*0.10:,.0f}").classes('text-base font-bold text-amber-400')
                    with ui.card().classes('bg-[#111118] border border-slate-900 p-3 text-center'):
                        ui.label('24H 交易量 (USDC)').classes('text-[10px] text-slate-500')
                        ui.label(f"${market['volume_24h']:,.0f}").classes('text-base font-bold text-slate-200')
                    with ui.card().classes('bg-[#111118] border border-slate-900 p-3 text-center'):
                        ui.label('当前价格指数').classes('text-[10px] text-slate-500')
                        ui.label(f"{market['price']:.4f}").classes('text-base font-bold text-emerald-400')

                with ui.card().classes('w-full bg-[#111118] border border-slate-900 p-3 mb-2 font-mono text-xs'):
                    with ui.row().classes('w-full justify-between'):
                        ui.html(f"<b>2025年利差:</b> <span style='color:#34d399;'>{s25['diff']:.1%}</span> | <span style='color:#2775CA;'>USDC: {s25['uc']:.1%}</span> | <span style='color:#F0B90B;'>USDT: {s25['ut']:.1%}</span>")
                        ui.html(f"<b>2026年利差:</b> <span style='color:#34d399;'>{s26['diff']:.1%}</span> | <span style='color:#2775CA;'>USDC: {s26['uc']:.1%}</span> | <span style='color:#F0B90B;'>USDT: {s26['ut']:.1%}</span>")

                # 三大声明式标准标签页
                with ui.tabs().classes('w-full text-slate-400 dense text-xs') as detail_tabs:
                    tab_opp = ui.tab('📈 累积配对曲线')
                    tab_scatter = ui.tab('🔴 实时散点透视')
                    tab_funding = ui.tab('💰 费率历史看板')

                with ui.tab_panels(detail_tabs, value=tab_opp).classes('w-full bg-transparent p-0 mt-2') as panels:
                    
                    # 1. 曲线面板
                    with ui.tab_panel(tab_opp):
                        with ui.row().classes('items-center gap-4 mb-2'):
                            ui.label('时间跨度:').classes('text-xs text-slate-400 font-mono')
                            opp_radio = ui.radio({3: '3小时', 24: '24小时', 168: '7天'}, value=self.state['opp_hours']).props('inline dense').classes('text-xs text-slate-200 font-mono')
                        opp_plot = ui.plotly(OpportunityService.build_opportunity_curve(symbol, self.state['opp_hours'])).classes('w-full')

                    # 2. 散点面板
                    with ui.tab_panel(tab_scatter):
                        with ui.row().classes('items-center gap-4 mb-2'):
                            ui.label('滤镜跨度:').classes('text-xs text-slate-400 font-mono')
                            sc_radio = ui.radio({3: '3小时', 24: '24小时', 168: '7天'}, value=self.state['scatter_hours']).props('inline dense').classes('text-xs text-slate-200 font-mono')
                        sc_plot = ui.plotly(OpportunityService.build_scatter_chart(symbol, self.state['scatter_hours'])).classes('w-full')

                    # 3. 费率面板
                    with ui.tab_panel(tab_funding):
                        with ui.row().classes('w-full justify-between items-center mb-2 bg-[#111118] p-2 rounded border border-slate-900'):
                            with ui.row().classes('items-center gap-4'):
                                ui.label('展示模态:').classes('text-xs text-slate-400 font-mono')
                                fd_mode = ui.radio(['按月', '按日'], value=self.state['funding_mode']).props('inline dense').classes('text-xs text-slate-200 font-mono')
                            pager_wrap = ui.row().classes('items-center gap-2 font-mono text-xs')
                        
                        f_init, av_m, c_m = OpportunityService.build_funding_chart(coin, self.state['funding_mode'], self.state['month_offset'])
                        fd_plot = ui.plotly(f_init).classes('w-full')

                # 🛠️ 纯净刷新函数，不清除节点，直接走核心通信管道更新数据
                def update_opp_view():
                    opp_plot.update_figure(OpportunityService.build_opportunity_curve(symbol, self.state['opp_hours']))
                    opp_plot.update()  # 🛠️ 强行通知前端通道重绘

                def update_scatter_view():
                    sc_plot.update_figure(OpportunityService.build_scatter_chart(symbol, self.state['scatter_hours']))
                    sc_plot.update()   # 🛠️ 强行通知前端通道重绘

                def update_funding_view():
                    pager_wrap.clear()
                    f, av_m, c_m = OpportunityService.build_funding_chart(coin, self.state['funding_mode'], self.state['month_offset'])
                    fd_plot.update_figure(f)
                    fd_plot.update()   # 🛠️ 强行通知前端通道重绘
                    
                    with pager_wrap:
                        if self.state['funding_mode'] == '按日' and av_m:
                            def page_prev():
                                self.state['month_offset'] -= 1
                                update_funding_view()
                            def page_next():
                                self.state['month_offset'] += 1
                                update_funding_view()
                            ui.button('◀ 上一月', on_click=page_prev).props('flat dense text-color=amber').classes('text-xs')
                            ui.label(f" [{c_m}] ").classes('text-slate-300 font-bold')
                            ui.button('下一月 ▶', on_click=page_next).props('flat dense text-color=amber').classes('text-xs')

                # 事件直接点对点挂载，极其干净
                opp_radio.on('change', lambda e: [self.state.update({'opp_hours': e.value}), update_opp_view()])
                sc_radio.on('change', lambda e: [self.state.update({'scatter_hours': e.value}), update_scatter_view()])
                fd_mode.on('change', lambda e: [self.state.update({'funding_mode': e.value, 'month_offset': 0}), update_funding_view()])

                # 当页签切换或对话框打开时，只需无条件调用浏览器的 resize 确保画布像素伸展
                async def trigger_resize():
                    await ui.run_javascript("setTimeout(() => { window.dispatchEvent(new Event('resize')); }, 60);", respond=False)

                dialog.on('open', lambda: [update_opp_view(), update_scatter_view(), update_funding_view(), trigger_resize()])
                panels.on('update:model-value', trigger_resize)

        dialog.open()