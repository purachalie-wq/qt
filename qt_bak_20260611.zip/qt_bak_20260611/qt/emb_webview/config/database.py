# config/database.py
from sqlalchemy import create_engine

class DBFactory:
    def __init__(self):
        # 独立量化服务器配置库
        self.server_engine = create_engine(
            "mysql+pymysql://FundingRate:sT36Hc2CwPbN8txY@localhost/server_qt_db?charset=utf8mb4", 
            pool_recycle=3600
        )
        self.pools = {}

    def get_exchange_engine(self, exchange_name: str):
        """根据当前选中的交易所，动态分发对应的 MySQL 连接池"""
        # 统一映射到你的诸如 bybit_qt_db, bitget_qt_db 等数据库
        db_name = f"{exchange_name}_qt_db"
        if db_name not in self.pools:
            uri = f"mysql+pymysql://FundingRate:sT36Hc2CwPbN8txY@localhost/{db_name}?charset=utf8mb4"
            self.pools[db_name] = create_engine(uri, pool_recycle=3600)
        return self.pools[db_name]

db_factory = DBFactory()