# -*- coding: UTF-8 -*-
import pymysql
import numpy as np

# --- 配置区 ---
DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "tester",
    "password": "wLPrikjez8SKT3d8",
    "database": "testdb",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

TOTAL_COST = 16.5   # 总成本基准 (BP)
MIN_DURATION = 150  # 存续时间过滤 (ms)

def get_dual_direction_stats(cursor, table_name):
    """分析单个币对的 UP 和 DOWN 两个方向"""
    symbol = table_name.replace("arb_opp_ev_", "").upper()
    
    # 1. 计算时间跨度
    cursor.execute(f"SELECT MIN(start_time) as s, MAX(end_time) as e FROM {table_name}")
    t_range = cursor.fetchone()
    if not t_range or not t_range['s'] or not t_range['e']: return []
    
    days = (t_range['e'] - t_range['s']).total_seconds() / 86400.0
    days = max(days, 0.01)

    # 2. 提取数据
    sql = f"SELECT side, max_diff_bps FROM {table_name} WHERE duration_ms >= %s"
    cursor.execute(sql, (MIN_DURATION,))
    rows = cursor.fetchall()
    if len(rows) < 10: return []

    open_bps = np.array([abs(r['max_diff_bps']) for r in rows if r['side'] == 'OPEN'])
    close_bps = np.array([abs(r['max_diff_bps']) for r in rows if r['side'] == 'CLOSE'])

    if len(open_bps) < 3 or len(close_bps) < 3: return []

    # 3. 计算贡献值 (P60)
    val_open = np.percentile(open_bps, 60)
    val_close = np.percentile(close_bps, 60)
    
    # 4. 计算两个方向的指标
    # 收益 = Open + Close - 16.5
    net_profit = val_open + val_close - TOTAL_COST
    # 频率：该币种总事件数折算到每天
    daily_count = len(rows) / days
    # 期望得分
    score = net_profit * daily_count if net_profit > 0 else net_profit

    # 构造两个方向的结果报表
    # UP方向：配置为 Open_Thr=val_open, Close_Thr=val_close
    # DOWN方向：配置为 Open_Thr=val_close, Close_Thr=val_open (根据你的逻辑：反向开仓参考close，平仓参考open)
    return [
        {
            "display": f"{symbol} (UP)",
            "open_thr": val_open,
            "close_thr": val_close,
            "net_profit": net_profit,
            "daily_count": daily_count,
            "score": score
        },
        {
            "display": f"{symbol} (DOWN)",
            "open_thr": val_close,
            "close_thr": val_open,
            "net_profit": net_profit,
            "daily_count": daily_count,
            "score": score
        }
    ]

def main():
    conn = pymysql.connect(**DB_CONFIG)
    all_directions = []
    try:
        with conn.cursor() as cursor:
            cursor.execute("SHOW TABLES LIKE 'arb_opp_ev_%'")
            tables = [list(t.values())[0] for t in cursor.fetchall()]
            
            for table in tables:
                res_list = get_dual_direction_stats(cursor, table)
                all_directions.extend(res_list)
            
            # 按得分排序
            all_directions.sort(key=lambda x: x['score'], reverse=True)

            # 输出结果
            print("\n" + "="*105)
            print(f"{'排名':<4} {'交易方向':<18} {'日均频率':<10} {'单笔净利':<10} {'期望得分':<12} {'开仓阀值':<12} {'平仓阀值':<12}")
            print("-" * 105)
            
            for i, res in enumerate(all_directions, 1):
                icon = "🔥" if res['score'] > 50 else "✅" if res['score'] > 0 else "❄️"
                print(f"{icon} {i:<2} {res['display']:<18} "
                      f"{res['daily_count']:>10.1f} "
                      f"{res['net_profit']:>10.2f} "
                      f"{res['score']:>12.2f} "
                      f"{res['open_thr']:>12.2f} "
                      f"{res['close_thr']:>12.2f}")

            print("="*105)
            print("策略逻辑：收益 = Open端BP + Close端BP - 16.5")
            print("配置说明：正向开仓填UP的开仓值，反向开仓填DOWN的开仓值。")
            
    finally:
        conn.close()

if __name__ == "__main__":
    main()