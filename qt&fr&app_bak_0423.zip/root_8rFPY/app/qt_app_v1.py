import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import time
import io
import pymysql
from datetime import datetime
import requests  # 添加这一行
import re

# --- 数据库配置 ---
ARB_DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "tester",
    "password": "wLPrikjez8SKT3d8",
    "database": "testdb",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

def get_db_conn():
    return pymysql.connect(**ARB_DB_CONFIG)

# --- 数据获取函数 ---
def get_all_stats():
    """获取所有套利统计数据"""
    try:
        conn = get_db_conn()
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM arb_stats ORDER BY efficiency DESC")
            data = cursor.fetchall()
        conn.close()
        return data
    except Exception as e:
        st.sidebar.error(f"数据库错误: {e}")
        return []


# --- 工具函数：保持与入库脚本一致的表名生成规则 ---
def get_table_name(symbol):
    """根据 symbol 生成对应的分表名"""
    # 移除特殊字符并大写，例如 BTC-USDT -> arb_opp_ev_BTC_USDT
    safe_symbol = re.sub(r'[^a-zA-Z0-9]', '_', symbol).upper()
    return f"arb_opp_ev_{safe_symbol}"

# --- 修改后的数据获取函数 ---
def get_event_analysis(symbol, side, days=1):
    """获取指定符号的分表数据分析"""
    table_name = get_table_name(symbol)
    try:
        conn = get_db_conn()
        with conn.cursor() as cursor:
            # 1. 检查表是否存在（防止新币种还没产生分表时 Streamlit 报错）
            cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
            if not cursor.fetchone():
                return {"events": [], "metrics": {}}

            # 2. 获取明细数据 (注意：SQL 中的表名使用 f-string 注入，变量依然使用 %s 防止注入)
            query_events = f"""
            SELECT start_time, avg_diff_bps, bottle_qty_avg, duration_ms, tick_count 
            FROM {table_name} 
            WHERE side = %s 
              AND start_time >= DATE_SUB(NOW(), INTERVAL %s DAY)
            ORDER BY start_time DESC LIMIT 5000
            """
            cursor.execute(query_events, (side, days))
            events = cursor.fetchall()
            
            # 3. 计算核心指标汇总
            query_metrics = f"""
            SELECT COUNT(*) as total, 
                   AVG(bottle_qty_avg) as avg_qty, 
                   AVG(avg_diff_bps) as avg_bps, 
                   MAX(max_diff_bps) as max_bps 
            FROM {table_name} 
            WHERE side = %s
              AND start_time >= DATE_SUB(NOW(), INTERVAL %s DAY)
            """
            cursor.execute(query_metrics, (side, days))
            m = cursor.fetchone()

        conn.close()
        return {"events": events, "metrics": m}
    except Exception as e:
        st.error(f"分表 [{table_name}] 加载异常: {str(e)}")
        return {"events": [], "metrics": {}}

# --- Streamlit 应用主逻辑 ---
st.set_page_config(page_title="QT Dashboard Pro", layout="wide", initial_sidebar_state="expanded")

# --- 核心状态初始化 ---
if 'core_data' not in st.session_state:
    st.session_state.core_data = []
if 'last_refresh_time' not in st.session_state:
    st.session_state.last_refresh_time = 0
if 'bybit_data' not in st.session_state:
    st.session_state.bybit_data = pd.DataFrame(columns=['join_key', '24h_turnover', 'oi_value'])

# --- 配置参数 ---
API_BASE_URL = "http://43.167.241.71:5000/api/stats"
GREEN_SYMBOLS = ["IP", "RESOLV", "WLFI", "WIF", "SEI", "TAO", "XMR", "1000PEPE", "WLD", "HYPE", "BCH", "INJ", "BONK", "ONDO", "SOL", "1000BONK", "ASTER", "UNI", "LINK", "CRV", "DOT", "LTC", "ENA", "SUI", "XLM", "SAHARA"]
BYBIT_ENDPOINTS = ["https://api.bybit.com/v5/market/tickers", "https://api.bybit.net/v5/market/tickers"]

# --- 注入样式 ---
st.markdown("""
<style>
    [data-testid="collapsedControl"] { display: none !important; }
    .stApp { background-color: #0a0a0f !important; color: #e0e0e0 !important; }
    .block-container { padding-top: 25px !important; padding-left: 25px !important; padding-right: 25px !important; padding-bottom: 20px !important; }
    header[data-testid="stHeader"] { display: none !important; height: 0px !important; visibility: hidden !important; }
    [data-testid="stSidebar"] { min-width: 250px !important; max-width: 250px !important; width: 250px !important; background-color: #0d1117 !important; border-right: 1px solid #1e2a3a !important; }
    [data-testid="stSidebarUserContent"] { padding-top: 0px !important; }
    [data-testid="stSidebar"] div, [data-testid="stSidebar"] label, [data-testid="stSidebar"] span, [data-testid="stSidebar"] p { color: #3fb950 !important; font-weight: 600 !important; }
    .custom-table { width: 100%; border-collapse: collapse; background-color: #0d1117; color: white; border: 1px solid #1e2a3a; font-family: 'JetBrains Mono', monospace; font-size: 0.9rem; }
    .custom-table th { background-color: #161b22; color: #58a6ff; padding: 12px; text-align: left; }
    .custom-table td { padding: 20px 10px !important; border-bottom: 1px solid #1a2030; }
    .val-positive { color: #3fb950 !important; font-weight: bold !important; }
    .val-negative { color: #f85149 !important; font-weight: bold !important; }
    footer { visibility: hidden !important; }
    div[data-testid="stButton"] > button { background-color: transparent !important; border: none !important; color: #58a6ff !important; padding: 0 !important; font-weight: 600 !important; box-shadow: none !important; }
    div[data-testid="stButton"] > button:hover { color: #79c0ff !important; background-color: transparent !important; border: none !important; }
    [data-testid="stMetricLabel"] div { color: white !important; opacity: 0.9; }
    [data-testid="stMetricValue"] div { color: white !important; font-weight: 700 !important; }
</style>
""", unsafe_allow_html=True)

def sync_data():
    success = False
    try:
        st.session_state.core_data = get_all_stats()
        success = True
    except Exception as e:
        st.sidebar.error(f"数据获取错误: {e}")
    
    for url in BYBIT_ENDPOINTS:
        try:
            params = {"category": "linear"}
            bb_resp = requests.get(url, params=params, timeout=3)
            if bb_resp.status_code == 200 and bb_resp.json().get('retCode') == 0:
                raw_list = bb_resp.json()['result']['list']
                processed = []
                for t in raw_list:
                    symbol = t.get('symbol', '')
                    if 'USDC' in symbol or 'PERP' in symbol:
                        key = symbol.replace('USDT', '').replace('USDC', '').replace('PERP', '').replace('-', '')
                        processed.append({
                            "join_key": key,
                            "24h_turnover": float(t.get('turnover24h', 0)),
                            "oi_value": (float(t.get('openInterest', 0)) if t.get('openInterest') else 0) * float(t.get('lastPrice', 0))
                        })
                if processed:
                    df_new = pd.DataFrame(processed)
                    df_new = df_new.sort_values('24h_turnover', ascending=False)
                    st.session_state.bybit_data = df_new.drop_duplicates(subset=['join_key'])
                break
        except Exception as e:
            st.sidebar.error(f"Bybit API 错误: {e}")
    
    st.session_state.last_refresh_time = time.time()
    return success

def process_display_data(raw_data):
    if not raw_data: return pd.DataFrame()
    df = pd.DataFrame(raw_data)
    df['均价_v'] = df.get('dt_avg', 0).replace(0, float('nan'))
    df['盈亏BP'] = (df.get('max_entry', 0) + df.get('max_exit', 0)) * 10000 / df['均价_v']
    df['建仓BP'] = df.get('max_entry', 0) * 10000 / df['均价_v']
    df['平仓BP'] = df.get('max_exit', 0) * 10000 / df['均价_v']
    return df.fillna(0).sort_values(by='盈亏BP', ascending=False).reset_index(drop=True)

if not st.session_state.core_data:
    sync_data()

# --- 侧边栏导航 ---
with st.sidebar:
    df_nav = process_display_data(st.session_state.core_data)
    nav_options = ["📊 概览"]
    if not df_nav.empty:
        for _, row in df_nav.iterrows():
            nav_options.append(f"{row['symbol']} ({row['盈亏BP']:.0f} BP)")
    
    selected_option = st.radio("选择视图", nav_options, key="main_nav")
    st.markdown("---")
    st.caption(f"Sync: {datetime.fromtimestamp(st.session_state.last_refresh_time).strftime('%H:%M:%S')}")

# --- 主界面逻辑 ---
if selected_option == "📊 概览":
    col_title, col_btn = st.columns([10, 1.2])
    with col_title:
        st.markdown("## 📊 概览", unsafe_allow_html=True)
    with col_btn:
        if st.button("刷新"):
            sync_data()
            st.rerun()
    
    #st.markdown("---")
    df = process_display_data(st.session_state.core_data)
    bybit_df = st.session_state.bybit_data
    
    if not df.empty:
        df['join_key'] = df['symbol'].str.replace(r'USDT|USDC', '', case=False, regex=True)
        merged_df = pd.merge(df, bybit_df, on='join_key', how='left').fillna(0)
        cols = ['symbol', 'max_entry', 'max_exit', 'dt_avg', '盈亏BP', '建仓BP', '平仓BP', '24h_turnover', 'oi_value']
        final_df = merged_df[cols].copy()
        
        display_df = final_df.copy()
        display_df.columns = ['币种', '建仓', '平仓', '均价', '盈亏BP', '建仓BP', '平仓BP', '24h成交额', '持仓总值']
        
        def apply_html_styles(row):
            base = row['币种'].replace('USDT', '').replace('USDC', '')
            sym_cls = "val-positive" if base in GREEN_SYMBOLS else ""
            row['币种'] = f'<span class="{sym_cls}">{row["币种"]}</span>'
            for col in ['建仓', '平仓']: row[col] = f'{float(row[col]):.6f}'
            for col in ['盈亏BP', '建仓BP', '平仓BP']:
                val = int(row[col])
                row[col] = f'<span class="{"val-positive" if val > 0 else "val-negative"}">{val:d}</span>'
            row['24h成交额'] = f'<span class="{"val-positive" if row["24h成交额"] >= 20000 else "val-negative"}">{row["24h成交额"]:,.0f}</span>'
            row['持仓总值'] = f'<span class="{"val-positive" if row["持仓总值"] >= 200000 else "val-negative"}">{int(row["持仓总值"]):,}</span>'
            return row
        
        styled_df = display_df.apply(apply_html_styles, axis=1)
        st.markdown(f'<div style="overflow-x:auto;">{styled_df.to_html(classes="custom-table", index=False, escape=False, border=0)}</div>', unsafe_allow_html=True)
    else:
        st.info("💡 暂无核心数据，请点击刷新。")

else:
    # --- 详情页：机会事件分析 ---
    symbol = selected_option.split(" (")[0]
    st.markdown(f"## <span style='color:#58a6ff'>{symbol}</span> ", unsafe_allow_html=True)
    
    tab_open, tab_close = st.tabs([" OPEN", " CLOSE"])
    
    def render_side_analysis(current_side):
        # 1. 维度选择器
        col_sel, _ = st.columns([2, 8])
        with col_sel:
            time_frame = st.radio(f"时段_{current_side}", ["24H", "7D"], horizontal=True, label_visibility="collapsed")
        
        days_val = 1 if time_frame == "24H" else 7
        data = get_event_analysis(symbol, current_side, days=days_val)
        
        if data and data['events']:
            events = data['events']
            m = data['metrics']
            
            # 指标卡
            c1, c2, c3, c4 = st.columns(4)
            with c1: st.metric("累计次数", f"{m['total']} 次")
            with c2: st.metric("平均深度", f"${float(m['avg_qty']):,.2f}")
            with c3: st.metric("平均价差", f"{int(m['avg_bps'])} BP")
            with c4: st.metric("最大价差", f"{int(m['max_bps'])} BP")
            
            df_ev = pd.DataFrame(events)
            df_ev['start_time'] = pd.to_datetime(df_ev['start_time'])
            
            # 2. 采样逻辑：如果是7D且数据量大，则进行采样以保证拖动流畅
            if days_val == 7 and len(df_ev) > 2000:
                df_ev = df_ev.set_index('start_time').resample('5min').agg({
                    'avg_diff_bps': 'max',      # 保留刺头
                    'bottle_qty_avg': 'mean',
                    'duration_ms': 'mean'
                }).reset_index().dropna()

            # 3. 绘制散点图：颜色映射深度 (USDC Qty)
            fig = go.Figure(go.Scatter(
                x=df_ev['start_time'], 
                y=df_ev['avg_diff_bps'],
                mode='markers',
                marker=dict(
                    size=10,
                    color=df_ev['bottle_qty_avg'], # 颜色改为映射深度
                    colorscale='Viridis', 
                    showscale=True,
                    colorbar=dict(
                        title=dict(text="深度(Qty)", font=dict(color="white")),
                        tickfont=dict(color="white"),
                        outlinewidth=0
                    )
                ),
                text=[f"USDC深度: {q:,.0f}<br>时长: {d/1000:.3f}s" for q, d in zip(df_ev['bottle_qty_avg'], df_ev['duration_ms'])],
                hovertemplate="<b>时间:</b> %{x}<br><b>价差:</b> %{y:.2f} BP<br>%{text}<extra></extra>"
            ))
            
            # 4. 极简布局 + 滑动条 (Rangeslider)
            fig.update_layout(
                template="plotly_dark",
                height=500,
                margin=dict(l=0,r=0,t=20,b=0),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="white"),
                hovermode="closest",
                xaxis=dict(
                    rangeslider=dict(visible=True, thickness=0.08, bgcolor="#0d1117", yaxis_rangemode='fixed'), # 底部滑动条
                    type="date",
                    gridcolor="#1e2a3a",showspikes=False # 彻底关闭垂直辅助线
                ),
                yaxis=dict(
                    title_text="价差(BP)",
                    gridcolor="#1e2a3a",
                    zeroline=False,
                    range=[-15, max(df_ev['avg_diff_bps'].max() * 1.1, 30)],
                    showspikes=False # 彻底关闭水平辅助线
                )
            )
            st.plotly_chart(fig, use_container_width=True, config={
                'displayModeBar': False,  # 彻底隐藏右上角工具栏
                'showTips': False         # 隐藏提示信息
            })
            
        else:
            st.info(f"💡 该币种暂无 {current_side} 方向的监控记录")
    
    with tab_open: render_side_analysis("OPEN")
    with tab_close: render_side_analysis("CLOSE")