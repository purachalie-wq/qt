from flask import Flask
import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
app = Flask(__name__)

def generate_aes_key() -> str:
    """生成一个 256 位的随机对称密钥（Base64 编码）"""
    return base64.b64encode(os.urandom(32)).decode('utf-8')

def encrypt_string_aes(plaintext: str, key: str) -> str:
    """
    使用 AES-256-GCM 加密字符串。

    :param plaintext: 要加密的明文字符串
    :param key:       Base64 编码的 32 字节密钥
    :return:          Base64 编码的密文字符串（格式: nonce + ciphertext）
    """
    # 解码密钥
    key_bytes = base64.b64decode(key.encode('utf-8'))

    # 生成 96 位随机 Nonce（每次加密必须唯一）
    nonce = os.urandom(12)

    # 执行 AES-GCM 加密
    aesgcm = AESGCM(key_bytes)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)

    # 将 nonce + 密文拼接后 Base64 编码（解密时需拆分）
    result = base64.b64encode(nonce + ciphertext).decode('utf-8')
    return result

def decrypt_string_aes(encrypted_b64: str, key: str) -> str:
    """
    使用 AES-256-GCM 解密字符串。

    :param encrypted_b64: Base64 编码的密文字符串（nonce + ciphertext）
    :param key:           Base64 编码的 32 字节密钥
    :return:              解密后的明文字符串
    """
    # 解码密钥和密文
    key_bytes = base64.b64decode(key.encode('utf-8'))
    encrypted_data = base64.b64decode(encrypted_b64.encode('utf-8'))

    # 拆分 nonce（前 12 字节）和密文
    nonce = encrypted_data[:12]
    ciphertext = encrypted_data[12:]

    # 执行 AES-GCM 解密
    aesgcm = AESGCM(key_bytes)
    plaintext = aesgcm.decrypt(nonce, ciphertext, None).decode('utf-8')
    return plaintext

@app.route('/')
def hello_world():
   return 'Hello, Flask!'
if __name__ == '__main__':
   app.run(host='0.0.0.0', port=8501)