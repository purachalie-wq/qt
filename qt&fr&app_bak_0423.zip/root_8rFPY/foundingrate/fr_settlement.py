import ccxt
import pandas as pd
from datetime import datetime, timedelta
import time

# --- 配置信息 ---
API_KEY = 'uJujXhPrdakinzYLN6'
API_SECRET = 'q0T2MEIa1EzvTIbbZsoFI8jtgbO4hDKtUCKs'


def get_april_funding_pnl():
    # 初始化 Bybit 实例
    exchange = ccxt.bybit({
        'apiKey': API_KEY,
        'secret': API_SECRET,
        'enableRateLimit': True, # ccxt 内部速率限制器
    })

    # 定义 4 月份的起止时间
    start_dt = datetime(2026, 4, 1)
    # 截止到当前时间，避免请求未来数据产生错误
    end_dt = min(datetime(2026, 4, 30, 23, 59, 59), datetime.now())
    
    all_logs = []
    current_start = start_dt

    print(f"🚀 启动 4 月资金费统计 (频率控制: 最大 5 次请求/秒)...")

    try:
        # Bybit V5 要求 startTime 和 endTime 跨度不能超过 7 天
        while current_start < end_dt:
            current_end = min(current_start + timedelta(days=7), end_dt)
            
            start_ms = int(current_start.timestamp() * 1000)
            end_ms = int(current_end.timestamp() * 1000)
            
            print(f"📅 正在同步区间: {current_start.strftime('%m-%d')} 至 {current_end.strftime('%m-%d')} ...")
            
            cursor = None
            while True:
                params = {
                    'accountType': 'UNIFIED', # 统一账户
                    'type': 'FUNDING',       # 仅拉取资金费
                    'startTime': start_ms,
                    'endTime': end_ms,
                    'limit': 50
                }
                if cursor:
                    params['cursor'] = cursor

                # 调用接口
                response = exchange.privateGetV5AccountTransactionLog(params)
                
                # --- 核心频率控制：每次请求后暂停 0.2 秒 (1秒最多5次) ---
                time.sleep(0.2) 
                
                result = response.get('result', {})
                logs = result.get('list', [])
                
                if logs:
                    all_logs.extend(logs)
                
                # 分页处理
                cursor = result.get('nextPageCursor')
                if not cursor:
                    break
            
            # 步进到下一个 7 天区间，加 1 毫秒防止边界重复
            current_start = current_end + timedelta(milliseconds=1)

        if not all_logs:
            print("⚠️ 4 月份未拉取到任何流水。请检查 API Key 是否有 'Account Transfer' 权限。")
            return

        # --- 使用 Pandas 处理汇总 ---
        df = pd.DataFrame(all_logs)
        
        # 确保过滤出真正的 FUNDING 记录
        df = df[df['type'].str.contains('FUNDING', case=False, na=False)].copy()
        
        if df.empty:
            print("💡 抓到了流水，但其中没有 FUNDING 类型的记录。")
            return

        # 格式化数值和时间
        df['amount'] = df['change'].astype(float)
        df['time'] = pd.to_datetime(df['transactionTime'].astype(float), unit='ms')
        df['coin'] = df['currency'].str.upper()

        # 分币种统计盈亏和频率
        summary = df.groupby('coin')['amount'].agg(['sum', 'count']).rename(
            columns={'sum': '盈亏(USD)', 'count': '结算次数'}
        )
        
        # 打印结果
        print("\n" + "═"*60)
        print(f"📊 Bybit 资金费套利月度报告 (2026-04)")
        print("═"*60)
        print(summary.to_string())
        print("-" * 60)
        print(f"💰 4月总计盈亏: {df['amount'].sum():,.4f} USD")
        print(f"📈 结算流水总计: {len(df)} 条")
        print("═"*60)

    except Exception as e:
        print(f"❌ 运行中出错: {e}")

if __name__ == "__main__":
    get_april_funding_pnl()