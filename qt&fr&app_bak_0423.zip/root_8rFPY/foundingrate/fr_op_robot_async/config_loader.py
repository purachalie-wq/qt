import json
import configparser
import logging
from types import SimpleNamespace

class ConfigLoader:
    def __init__(self):
        self.auth = None
        self.db = None
        self.coins = []

    def load_all(self, ini_path="config.ini", json_path="coins.json"):
        # 1. 加载 config.ini
        try:
            config = configparser.ConfigParser()
            config.read(ini_path, encoding='utf-8')
            
            self.auth = SimpleNamespace(
                api_key=config.get('auth', 'api_key'),
                secret_key=config.get('auth', 'secret_key')
            )
            
            self.db = {
                "host": config.get('database', 'host'),
                "port": config.getint('database', 'port'),
                "user": config.get('database', 'user'),
                "password": config.get('database', 'password'),
                "database": config.get('database', 'database'),
                "charset": "utf8mb4"
            }
        except Exception as e:
            logging.error(f"❌ 加载 config.ini 失败: {e}")
            raise

        # 2. 加载 coins.json
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                self.coins = json.load(f)
        except Exception as e:
            logging.error(f"❌ 加载 coins.json 失败: {e}")
            raise
            
        logging.info(f"✅ 配置加载成功: 已加载 {len(self.coins)} 个币种策略")
        return self