# -*- coding: UTF-8 -*-
import pymysql
import logging
import re
from datetime import datetime

_db_config = {}

def set_config(config):
    global _db_config
    _db_config = config

def get_conn():
    return pymysql.connect(**_db_config)


def init_db():
    """初始化数据库核心表结构"""
    conn = get_conn()
    try:
        with conn.cursor() as cursor:
            # 1. 汇总统计表：用于展示各币种运行概况
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS arb_stats (
                    symbol VARCHAR(20) PRIMARY KEY,
                    total_trades INT DEFAULT 0,
                    fok_failure_count INT DEFAULT 0,
                    avg_slippage_bp DOUBLE DEFAULT 0,
                    total_profit_usdt DOUBLE DEFAULT 0,
                    last_update DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)

            # 2. 成交明细表 (核心复盘表)：记录期望价与实际成交价
            # 记录：下单时间、USDC期望/成交价、USDT期望/成交价、理论BP、实际滑点
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS order_fills (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    symbol VARCHAR(20),
                    side VARCHAR(20),           -- 'UP_OPEN', 'UP_CLOSE', 'DN_OPEN', 'DN_CLOSE'
                    trade_amount DOUBLE,
                    
                    -- USDC端 (FOK限价端)
                    exp_usdc_price DOUBLE,      -- 决策时的盘面价 (c_bid/c_ask)
                    target_usdc_price DOUBLE,   -- 加了 slip_ticks 后的报单价
                    fill_usdc_price DOUBLE,     -- 实际成交均价
                    
                    -- USDT端 (市价对冲端)
                    exp_usdt_price DOUBLE,      -- 决策时的盘面价 (u_ask/u_bid)
                    fill_usdt_price DOUBLE,     -- 实际成交均价
                    
                    -- 利润与成本分析
                    theoretical_bp DOUBLE,      -- 触发瞬间的理论利润(BP)
                    actual_bp DOUBLE,           -- 扣除双边滑点后的实际利润(BP)
                    slippage_loss_bp DOUBLE,    -- 相比理论价，滑点损失了多少BP
                    
                    created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
                    INDEX idx_symbol (symbol),
                    INDEX idx_time (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
        conn.commit()
        logging.info("✅ [DB] 数据库初始化成功 (order_fills & arb_stats)")
    except Exception as e:
        logging.error(f"❌ [DB] 初始化失败: {e}")
    finally:
        conn.close()

def save_order_fill(data: dict):
    """记录每一笔成功的双边成交明细"""
    conn = get_conn()
    try:
        with conn.cursor() as cursor:
            # 计算实际利润和滑点损失
            # 实际 BP = ((成交USDC - 成交USDT) / 成交USDT) * 10000 (以开仓买入为例，逻辑需根据方向微调)
            # 这里我们建议由外部计算好传入，或者在此处根据 side 统一逻辑
            
            sql = """
                INSERT INTO order_fills (
                    symbol, side, trade_amount, 
                    exp_usdc_price, target_usdc_price, fill_usdc_price,
                    exp_usdt_price, fill_usdt_price,
                    theoretical_bp, actual_bp, slippage_loss_bp
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (
                data['symbol'], data['side'], data['amount'],
                data['exp_usdc'], data['target_usdc'], data['fill_usdc'],
                data['exp_usdt'], data['fill_usdt'],
                data['theo_bp'], data['act_bp'], data['slip_loss']
            ))
            
            # 同时更新汇总表
            update_stats_sql = """
                INSERT INTO arb_stats (symbol, total_trades) 
                VALUES (%s, 1) 
                ON DUPLICATE KEY UPDATE total_trades = total_trades + 1
            """
            cursor.execute(update_stats_sql, (data['symbol'],))
            
        conn.commit()
    except Exception as e:
        logging.error(f"❌ [DB] 记录成交明细失败: {e}")
    finally:
        conn.close()

def log_fok_failure(symbol):
    """记录 FOK 失败次数，用于复盘 slip_ticks 是否设置合理"""
    conn = get_conn()
    try:
        with conn.cursor() as cursor:
            sql = """
                INSERT INTO arb_stats (symbol, fok_failure_count) 
                VALUES (%s, 1) 
                ON DUPLICATE KEY UPDATE fok_failure_count = fok_failure_count + 1
            """
            cursor.execute(sql, (symbol,))
        conn.commit()
    except Exception as e:
        logging.error(f"❌ [DB] 记录FOK失败统计失败: {e}")
    finally:
        conn.close()

def get_recent_performance(symbol, limit=100):
    """获取最近N笔的滑点表现，供可视化看板使用"""
    conn = get_conn()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM order_fills WHERE symbol = %s ORDER BY id DESC LIMIT %s"
            cursor.execute(sql, (symbol, limit))
            return cursor.fetchall()
    finally:
        conn.close()

# 兼容性封装：动态分表保留逻辑 (如果你的采集器仍需记录原始机会)
def get_table_name(symbol):
    safe_symbol = re.sub(r'[^a-zA-Z0-9]', '_', symbol).upper()
    return f"arb_opp_{safe_symbol}"

def save_opportunity(symbol, data: dict):
    """记录原始套利机会(可选)"""
    table_name = get_table_name(symbol)
    conn = get_conn()
    try:
        with conn.cursor() as cursor:
            # 动态建分表逻辑
            cursor.execute(f"CREATE TABLE IF NOT EXISTS {table_name} LIKE order_fills") # 示例简化
            # ... 具体的写入逻辑 ...
        conn.commit()
    except: pass
    finally: conn.close()