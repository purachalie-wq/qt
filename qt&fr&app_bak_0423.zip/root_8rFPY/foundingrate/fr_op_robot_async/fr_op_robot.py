import asyncio
import ccxt.pro as ccxt
import os
import logging
import json
import time
from core import TradingCore
import db_manager
from config_loader import ConfigLoader
from exchange_handler import ExchangeHandler

# 日志配置
# 日志配置
if not os.path.exists('log'): os.makedirs('log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    # 删除了 logging.StreamHandler()，只保留 FileHandler
    handlers=[logging.FileHandler('log/trading.log')] 
)

async def sync_core_positions(core, handler):
    """同步核心持仓状态"""
    try:
        pos_data = await handler.fetch_all_positions(core.usdt_symbol, core.usdc_symbol)
        core.update_position_status(pos_data['usdt_size'], pos_data['usdc_size'])
        logging.info(f"🔄 {core.symbol} 同步: UP={core.up_position}, DN={core.down_position}, 可开={core.can_open_more}")
    except Exception as e:
        logging.error(f"❌ {core.symbol} 同步失败: {e}")

async def execute_trade_flow(core, handler, decision):
    """
    完整执行流：1.计算Ticks偏置 -> 2.执行USDC FOK -> 3.判定成交量 -> 4.USDT对冲
    """
    symbol_dc = core.usdc_symbol
    symbol_dt = core.usdt_symbol

    # 1. 计算 FOK 报单价 (保留你的 ticks 逻辑)
    # 买入 USDC 要往高处报单增加成交率，卖出 往低处报
    offset = core.slip_ticks * (core.tick_size or 0)
    target_price = (decision['exp_usdc'] + offset) if decision['side_dc'] == 'buy' else (decision['exp_usdc'] - offset)

    try:
        # 2. 第一步：执行 USDC FOK (核心端)
        usdc_order = await handler.place_fok_order(
            symbol_dc, 
            decision['side_dc'], 
            decision['amount'], 
            target_price, 
            decision['reduce']
        )

        # --- 核心判定：提取成交量 ---
        if not usdc_order:
            return False, 0
            
        filled_qty = float(usdc_order['filled'])
        logging.info(f"✅ {core.symbol} USDC端确认成交: {filled_qty}")

        # 第二步：执行 USDT 对冲
        try:
            usdt_order = await handler.place_market_order(
                symbol_dt, 
                decision['side_dt'], 
                filled_qty, 
                decision['reduce']
            )
            # 如果以后要记录 actual_bp，可以在这里提取 f_usdt = usdt_order.get('average')
            return True, filled_qty
        except Exception as e:
            logging.error(f"🚨 严重异常！USDC已成交但USDT对冲失败: {e}")
            return True, filled_qty

    except Exception as e:
        error_msg = str(e)
        # --- 自愈补丁：处理 110017 报错 ---
        if "110017" in error_msg:
            logging.warning(f"⚠️ {core.symbol} 仓位已在交易所清空，强制执行本地校准")
            # 返回 True 触发本地变量减去本次 decision 数量，直到归零
            return True, decision['amount']
        
        logging.error(f"🚨 下单逻辑执行异常: {error_msg}")
        return False, 0



async def monitor_single_coin(core, handler): # 修正参数 1
    cache_usdt, cache_usdc = None, None
    decision_lock = asyncio.Lock()
    is_finished = False
    current_loop = 0

    async def watch_ws(contract_symbol, is_usdt):
        nonlocal cache_usdt, cache_usdc, current_loop, is_finished
        while not is_finished:
            try:
                # 修正引用名：core.usdt_symbol / core.usdc_symbol
                ob = await core.exchange.watch_order_book(contract_symbol, 1)
                if is_usdt: cache_usdt = ob
                else: cache_usdc = ob
                
                if cache_usdt and cache_usdc:
                    # 修正风控检查位置
                    if current_loop >= core.max_loops:
                        is_finished = True
                        logging.info(f"🚀 {core.symbol}  {current_loop} | {core.max_loops} 已到max_loops ")
                        break
                    
                    # 只有在拿到锁的情况下才处理，防止订单并发
                    if not decision_lock.locked():
                        async with decision_lock:
                            decision = core.make_decision(cache_usdt, cache_usdc)
        
                            if decision['triggered']:
                                logging.info(f"🎯 [SIGNAL] {core.symbol} 触发 {decision['tag']}")
                                # 确保 handler 被正确闭包引用
                                is_success, filled_qty = await execute_trade_flow(core, handler, decision)
            
                                
                                if is_success:
                                    current_loop += 1  #成功+1，
                                    #current_loop += 1
                                    core.apply_trade_result(decision['tag'], filled_qty)
                                    logging.info(f"🚀 {core.symbol} 状态已瞬时刷新")
            except Exception as e:
                logging.error(f"WS 异常: {e}")
                await asyncio.sleep(5)

    # 修正启动参数名
    await asyncio.gather(
        watch_ws(core.usdt_symbol, True),
        watch_ws(core.usdc_symbol, False)
    )

async def main():
    # 1. 初始化配置加载器 (解析 config.ini 和 coins.json)
    loader = ConfigLoader().load_all()
    
    # 2. 初始化数据库配置
    db_manager.set_config(loader.db)
    db_manager.init_db()
    
    # 3. 初始化交易所对象
    exchange = ccxt.bybit({
        "apiKey": loader.auth.api_key,
        "secret": loader.auth.secret_key,
        "enableRateLimit": True,
        "options": {"defaultType": "linear"} # 确保 Bybit 走线性合约路径
    })
    
    # 4. 实例化新的执行处理器 (这是之前漏掉的 handler)
    handler = ExchangeHandler(exchange)
    await handler.init_market_data()

    cores = []
    # 使用 loader.coins 而不是 config["coins"]
    for coin_cfg in loader.coins:
        core = TradingCore(**coin_cfg)
        
        core.exchange = exchange
        
        # 获取精度并同步给 core
        info = await handler.get_symbol_info(core.usdc_symbol)
        if info:
            core.tick_size = float(info['tick_size'])
        
        # 初始化同步持仓
        await sync_core_positions(core, handler)
        cores.append(core)

    # 5. 启动监控任务，注意要把 handler 传进去
    tasks = [asyncio.create_task(monitor_single_coin(core, handler)) for core in cores]
    try:
        await asyncio.gather(*tasks)
    except Exception as e:
        logging.error(f"🚨 主循环异常退出: {e}")
    finally:
        # ====== 无论怎么退出，必须关闭连接，消除 CancelledError ======
        await exchange.close()
        logging.info("🔌 交易所连接已关闭")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass