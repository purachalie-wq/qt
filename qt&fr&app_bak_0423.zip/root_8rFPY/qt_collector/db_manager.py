# -*- coding: UTF-8 -*-
import pymysql
import time
import traceback
import re
from datetime import datetime

# 数据库配置
DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "tester",
    "password": "wLPrikjez8SKT3d8",
    "database": "testdb",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

def get_conn():
    return pymysql.connect(**DB_CONFIG)

def get_table_name(symbol):
    """规范化表名：arb_opp_ev_BTC_USDT"""
    safe_symbol = re.sub(r'[^a-zA-Z0-9]', '_', symbol).upper()
    return f"arb_opp_ev_{safe_symbol}"

def create_symbol_table(cursor, table_name):
    """动态创建分表"""
    sql = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        symbol VARCHAR(20),
        side VARCHAR(10) COMMENT 'OPEN:建仓, CLOSE:平仓',
        conf_threshold DOUBLE,
        start_time DATETIME(3),
        end_time DATETIME(3),
        duration_ms INT,
        max_diff_bps DOUBLE,
        max_bp_qty DOUBLE,
        avg_diff_bps DOUBLE,
        bottle_qty_avg DOUBLE,
        bottle_qty_min DOUBLE,
        tick_count INT,
        INDEX idx_side_time (side, start_time)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """
    cursor.execute(sql)

def sync_events_to_db(lock, event_queue):
    """异步将事件队列写入对应的分表"""
    while True:
        time.sleep(5) 
        if not event_queue:
            continue
            
        with lock:
            batch_data = list(event_queue)
            event_queue.clear()
            
        if not batch_data:
            continue

        # --- 核心修改：按 Symbol 分组数据 ---
        grouped_data = {}
        for item in batch_data:
            # 假设 item 格式为 (symbol, side, ...)
            symbol = item[0] 
            if symbol not in grouped_data:
                grouped_data[symbol] = []
            grouped_data[symbol].append(item)

        conn = get_conn()
        try:
            with conn.cursor() as cursor:
                for symbol, rows in grouped_data.items():
                    table_name = get_table_name(symbol)
                    
                    # 1. 尝试写入，如果表不存在则创建
                    try:
                        sql = f"""
                            INSERT INTO {table_name} 
                            (symbol, side, conf_threshold, start_time, end_time, duration_ms, 
                             max_diff_bps, max_bp_qty, avg_diff_bps, bottle_qty_avg, bottle_qty_min, tick_count)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """
                        cursor.executemany(sql, rows)
                    except pymysql.err.ProgrammingError as e:
                        # 错误代码 1146 表示表不存在
                        if e.args[0] == 1146:
                            print(f"⚠️ [DB] 表 {table_name} 不存在，正在创建...")
                            create_symbol_table(cursor, table_name)
                            cursor.executemany(sql, rows) # 创建后重试
                        else:
                            raise e
                            
                conn.commit()
                print(f"💾 [DB] 批量入库完成，涉及 {len(grouped_data)} 个交易对，共 {len(batch_data)} 条记录")
        except Exception as e:
            conn.rollback()
            print(f"❌ [DB] 事件入库失败: {e}")
            traceback.print_exc()
        finally:
            conn.close()

# arb_stats 逻辑保持不变，因为它是全局统计表，不需要分表
def sync_stats_to_db(lock, stats_dict):
    """定时更新概览统计表 (保持原样)"""
    while True:
        time.sleep(10)
        snap_stats = {}
        with lock:
            if stats_dict:
                snap_stats = {k: v.copy() for k, v in stats_dict.items()}
        
        if not snap_stats: continue
        
        conn = get_conn()
        try:
            with conn.cursor() as cursor:
                for symbol, s in snap_stats.items():
                    if s.get('count', 0) == 0: continue
                    
                    dt_avg = s['dt_sum'] / s['count']
                    efficiency = (s['max_entry'] + s['max_exit']) * 10000 / dt_avg if dt_avg > 0 else 0
                    
                    sql = """
                        INSERT INTO arb_stats (symbol, max_entry, max_exit, dt_avg, efficiency)
                        VALUES (%s, %s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE 
                        max_entry = VALUES(max_entry),
                        max_exit = VALUES(max_exit),
                        dt_avg = VALUES(dt_avg),
                        efficiency = VALUES(efficiency)
                    """
                    cursor.execute(sql, (symbol, s['max_entry'], s['max_exit'], dt_avg, efficiency))
            conn.commit()
        except Exception as e:
            print(f"❌ [DB] 统计同步失败: {e}")
        finally:
            conn.close()

def init_db():
    """初始化数据库：仅初始化统计表，分表在入库时按需创建"""
    conn = get_conn()
    try:
        with conn.cursor() as cursor:
            # 统计表是汇总性质的，保留单表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS arb_stats (
                    symbol VARCHAR(20) PRIMARY KEY,
                    max_entry DOUBLE DEFAULT -999,
                    max_exit DOUBLE DEFAULT -999,
                    dt_avg DOUBLE DEFAULT 0,
                    efficiency DOUBLE DEFAULT 0,
                    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
        conn.commit()
        print("✅ [DB] 统计表初始化成功")
        return True
    except Exception as e:
        print(f"❌ [DB] 初始化失败: {e}")
        return False
    finally:
        conn.close()