import pandas as pd
import pymysql
import numpy as np
import warnings

warnings.filterwarnings("ignore", category=UserWarning)

# --- 数据库配置 ---
ARB_DB_CONFIG = {
    "host": "127.0.0.1", "port": 3306, "user": "tester",
    "password": "wLPrikjez8SKT3d8", "database": "testdb",
    "charset": "utf8mb4", "cursorclass": pymysql.cursors.DictCursor
}

def analyze_high_value_opportunities():
    try:
        conn = pymysql.connect(**ARB_DB_CONFIG)
        with conn.cursor() as cursor:
            # --- 核心改进：直接在 SQL 层面过滤 30BP 以上的数据 ---
            query = """
            SELECT * FROM arb_opportunity_events 
            WHERE avg_diff_bps >= 30 
            AND start_time >= NOW() - INTERVAL 3 DAY
            """
            cursor.execute(query)
            data = cursor.fetchall()
        conn.close()
    except Exception as e:
        print(f"❌ 数据库读取失败: {e}"); return

    if not data:
        print("ℹ️ 最近 3 天内未发现 30BP 以上的有效机会。")
        return

    df = pd.DataFrame(data)

    # 类型转换
    cols = ['avg_diff_bps', 'max_diff_bps', 'bottle_qty_avg', 'duration_ms']
    for col in cols: 
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # 计算核心指标
    # 既然是 30BP 以上，我们可以更激进地观察“利润爆发力”
    df['spike_ratio'] = df['max_diff_bps'] / df['avg_diff_bps']
    
    # 质量分数：针对 30BP 以上的机会，深度和持续时间权重加大
    df['quality_score'] = df['avg_diff_bps'] * np.log10(df['bottle_qty_avg'] + 1) * (df['duration_ms'] / 1000)

    # 分组合计
    summary = df.groupby(['symbol', 'side']).agg({
        'avg_diff_bps': 'mean',
        'max_diff_bps': 'max',
        'duration_ms': 'mean',
        'bottle_qty_avg': 'mean',
        'spike_ratio': 'mean',
        'quality_score': 'sum',
        'id': 'count'
    }).rename(columns={'id': 'occ_count', 'bottle_qty_avg': 'avg_qty'}).reset_index()

    # --- 针对 30BP+ 的下单模式判定 ---
    def assign_mode_v2(row):
        # 如果深度连 500U 都没有，即使过 30BP 也很难成交大单
        if row['avg_qty'] < 500: return "微量机会 (忽略)"
        
        # 持续时间超过 3s 且深度过万，这是真正的“黄金坑”
        if row['duration_ms'] > 3000 and row['avg_qty'] > 10000:
            return "重仓/阶梯建仓"
        
        # 峰值远高于均值（如均值 35，峰值 100），说明适合追踪
        if row['spike_ratio'] > 1.8:
            return "追踪建仓 (博极值)"
            
        return "标准市价抢单"

    summary['suggested_mode'] = summary.apply(assign_mode_v2, axis=1)
    summary = summary.sort_values('quality_score', ascending=False)

    # --- 打印输出 ---
    print("\n" + "="*115)
    print(f"🚀 核心报告：基于 30BP 入场阈值的实战分析 (最近3天)")
    print("-" * 115)
    header = f"{'SYMBOL':<15} {'SIDE':<6} {'AVG_BP':<8} {'MAX_BP':<8} {'DUR_S':<8} {'AVG_QTY':<10} {'MODE':<18} {'COUNT'}"
    print(header)
    print("-" * 115)
    
    for _, row in summary.head(25).iterrows():
        # 重点：这里的 AVG_BP 是所有 >30BP 事件的平均值
        print(f"{row['symbol']:<15} {row['side']:<6} {row['avg_diff_bps']:<8.1f} "
              f"{row['max_diff_bps']:<8.1f} {row['duration_ms']/1000:<8.2f} "
              f"${row['avg_qty']:<9.0f} {row['suggested_mode']:<18} {int(row['occ_count'])}")
    print("="*115)

if __name__ == "__main__":
    analyze_high_value_opportunities()