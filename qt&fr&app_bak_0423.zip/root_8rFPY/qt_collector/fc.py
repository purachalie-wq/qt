import pymysql
import re

# 数据库配置
db_config = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "tester",
    "password": "wLPrikjez8SKT3d8",
    "database": "testdb",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

def clean_symbol(symbol):
    """规范化表名：去除特殊字符并大写"""
    return re.sub(r'[^a-zA-Z0-9]', '_', symbol).upper()

def migrate_and_shard():
    conn = pymysql.connect(**db_config)
    try:
        with conn.cursor() as cursor:
            # 1. 找出所有 symbol
            print("正在读取旧表 Symbol 列表...")
            cursor.execute("SELECT DISTINCT symbol FROM arb_opportunity_events")
            symbols = [row['symbol'] for row in cursor.fetchall()]

            # 定义需要迁移的字段（不含 id，让新表自动生成新 id，或者包含 id 保持一致）
            # 这里建议明确列出，排除掉可能导致冲突的列
            fields = (
                "symbol, side, conf_threshold, start_time, end_time, "
                "duration_ms, max_diff_bps, avg_diff_bps, bottle_qty_avg, "
                "bottle_qty_min, tick_count"
            )

            for symbol in symbols:
                table_name = f"arb_opp_ev_{clean_symbol(symbol)}"
                print(f"处理中: {symbol} -> {table_name}")

                # 2. 创建新表
                cursor.execute(f"""
                CREATE TABLE IF NOT EXISTS {table_name} (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    symbol VARCHAR(20),
                    side VARCHAR(10),
                    conf_threshold DOUBLE,
                    start_time DATETIME(3),
                    end_time DATETIME(3),
                    duration_ms INT,
                    max_diff_bps DOUBLE,
                    avg_diff_bps DOUBLE,
                    bottle_qty_avg DOUBLE,
                    bottle_qty_min DOUBLE,
                    tick_count INT,
                    INDEX idx_side_time (side, start_time)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """)

                # 3. 同步数据：明确指定字段名
                migrate_sql = f"""
                INSERT INTO {table_name} ({fields})
                SELECT {fields} FROM arb_opportunity_events WHERE symbol = %s
                """
                cursor.execute(migrate_sql, (symbol,))
                print(f"   成功同步 {cursor.rowcount} 条数据")

            conn.commit()
            print("\n[完成] 数据已全部分发到新表。")

    except Exception as e:
        conn.rollback()
        print(f"迁移失败: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    migrate_and_shard()
