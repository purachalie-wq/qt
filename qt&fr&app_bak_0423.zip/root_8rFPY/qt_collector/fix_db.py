import pymysql
import re

DB_CONFIG = {
    "host": "127.0.0.1", "port": 3306, "user": "tester",
    "password": "wLPrikjez8SKT3d8", "database": "testdb"
}

def fix_tables():
    conn = pymysql.connect(**DB_CONFIG)
    try:
        with conn.cursor() as cursor:
            # 获取所有分表
            cursor.execute("SHOW TABLES LIKE 'arb_opp_ev_%'")
            tables = [list(row.values())[0] if isinstance(row, dict) else row[0] for row in cursor.fetchall()]
            
            for table in tables:
                print(f"🔧 检查表 {table}...")
                # 检查是否存在 max_bp_qty 列
                cursor.execute(f"SHOW COLUMNS FROM {table} LIKE 'max_bp_qty'")
                if not cursor.fetchone():
                    print(f"➕ 正在为 {table} 添加 max_bp_qty 列...")
                    cursor.execute(f"ALTER TABLE {table} ADD COLUMN max_bp_qty DOUBLE AFTER max_diff_bps")
            
            conn.commit()
            print("✅ 所有表结构已修复！")
    finally:
        conn.close()

if __name__ == "__main__":
    fix_tables()
