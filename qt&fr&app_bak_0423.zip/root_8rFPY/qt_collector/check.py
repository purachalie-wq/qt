import pymysql
import re

# 数据库配置 (请保持与迁移脚本一致)
db_config = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "tester",
    "password": "wLPrikjez8SKT3d8",
    "database": "testdb",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

def clean_symbol(symbol):
    return re.sub(r'[^a-zA-Z0-9]', '_', symbol).upper()

def verify_migration():
    conn = pymysql.connect(**db_config)
    try:
        with conn.cursor() as cursor:
            print("--- 开始数据一致性校验 ---")

            # 1. 获取原表各 Symbol 的统计总数
            print("正在统计原表数据...")
            cursor.execute("SELECT symbol, COUNT(*) as cnt FROM arb_opportunity_events GROUP BY symbol")
            old_stats = {row['symbol']: row['cnt'] for row in cursor.fetchall()}
            
            total_old_count = sum(old_stats.values())
            total_new_count = 0
            mismatch_found = False

            print(f"原表总记录数: {total_old_count}")
            print(f"原表 Symbol 数量: {len(old_stats)}")
            print("-" * 50)
            print(f"{'Symbol':<20} | {'原表数量':<10} | {'新表数量':<10} | {'状态'}")

            # 2. 逐个校验分表
            for symbol, old_count in old_stats.items():
                table_name = f"arb_opp_ev_{clean_symbol(symbol)}"
                
                try:
                    # 检查新表是否存在并统计数量
                    cursor.execute(f"SELECT COUNT(*) as cnt FROM {table_name}")
                    new_count = cursor.fetchone()['cnt']
                    total_new_count += new_count
                    
                    status = "OK" if old_count == new_count else "!! 错误 !!"
                    if old_count != new_count:
                        mismatch_found = True
                    
                    print(f"{symbol:<20} | {old_count:<10} | {new_count:<10} | {status}")
                
                except pymysql.err.ProgrammingError:
                    print(f"{symbol:<20} | {old_count:<10} | {'不存在':<10} | !! 缺失表 !!")
                    mismatch_found = True

            # 3. 最终汇总报告
            print("-" * 50)
            print(f"校验结果汇总:")
            print(f"原表总数: {total_old_count}")
            print(f"分表总数: {total_new_count}")

            if total_old_count == total_new_count and not mismatch_found:
                print("\n[✔] 校验通过！所有数据一致。")
                print("现在你可以安全地删除或重命名原表了。")
            else:
                print("\n[✘] 校验失败！发现数据不一致，请检查迁移日志。")

    except Exception as e:
        print(f"校验过程中发生错误: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    verify_migration()
