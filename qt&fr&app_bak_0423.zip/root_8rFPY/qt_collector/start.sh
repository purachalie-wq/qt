#!/bin/bash
nohup python3 qt_collector_v1.py > qt_collector.log 2>&1 &
echo "🚀 采集器和API服务已在后台启动！"
